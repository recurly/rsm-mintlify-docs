---
title: Support
excerpt: >-
  Where to find technical help for Recurly.js: supported browsers, self-service
  resources, and how to contact the Recurly team.
deprecated: false
hidden: false
metadata:
  robots: index
---
Whether you’re debugging a checkout form or planning a new payment-method rollout, Recurly offers several ways to get Recurly.js support—from official browser-compatibility guarantees to community resources and direct help from our engineering & success teams.

## Prerequisites & limitations

Recurly.js guarantees functionality on **ever-green versions** of:

* Google Chrome
* Mozilla Firefox
* Apple Safari (macOS & iOS)
* Microsoft Edge
* Chrome for Android / Samsung Internet
* Older, end-of-life browsers (e.g., Internet Explorer 11) are **not supported**.
* Mobile WebViews inherit support from the underlying OS browser; ensure it is up to date. This includes WebViews embedded in apps like Facebook and Instagram.

## Key details

### **Supported environments**

Recurly.js is continuously tested against the latest stable browser releases listed above to ensure Element rendering, tokenization, and advanced payment flows (Apple Pay, Google Pay, 3-D Secure, etc.) work as expected.

### **Self-service resources**

* **GitHub repository** – review source, open issues, or submit pull requests at [https://github.com/recurly/recurly-js](https://github.com/recurly/recurly-js).
* **Developer Docs** – explore full API and integration guides at [https://docs.recurly.com](https://docs.recurly.com).
* **Release notes** – track new features and breaking changes from the repo’s “Releases” tab.

### **Direct assistance**

For account-specific or production-blocking questions, email **[support@recurly.com](mailto:support@recurly.com)**.

Please include:

* Site sub-domain (e.g., `yourcompany.recurly.com`)
* Reproduction steps or code snippets (omit sensitive keys)
* Console/network logs or error messages

### **Best-effort community help**

The engineering team monitors GitHub issues; response times vary by severity and complexity. For guaranteed SLAs, use the support email above and reference your plan’s support level.