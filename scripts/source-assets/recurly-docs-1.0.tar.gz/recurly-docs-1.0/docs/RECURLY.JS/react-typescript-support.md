---
title: React & TypeScript
excerpt: >-
  Official React wrappers and community-maintained TypeScript types make it
  painless to use Recurly.js in modern front-end stacks.
deprecated: false
hidden: false
metadata:
  robots: index
---
Building with React or compiling your codebase to TypeScript? Recurly has you covered:

* **`react-recurly`**  —  first-party React components, hooks, and helpers that wrap Recurly.js for a declarative integration experience.
* **TypeScript typings**  —  up-to-date `.d.ts` files published on DefinitelyTyped so you get autocompletion and compile-time safety out of the box.

## Prerequisites and limitations

* You’ll need an existing React project (React ≥ 16.8) or a TypeScript tool-chain configured with `npm` or `yarn`.
* For TypeScript, the definitions mirror the latest Recurly.js API; upgrading Recurly.js may require updating `@types/recurly__recurly-js` to keep versions in sync.

## React support

Recurly maintains a React component library to simplify use of Recurly.js for your React applications.

For details on getting started, see our [documentation on GitHub](https://github.com/recurly/react-recurly).

## TypeScript support

TypeScript types for Recurly.js can be found on [DefinitelyTyped](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/recurly__recurly-js)

To install with npm, run `npm install --save-dev @types/recurly__recurly-js` in your project's root directory.