---
title: Overview
deprecated: false
hidden: false
metadata:
  title: 'Overview: Recurly.js'
  description: Learn about our Recurly.js solution
  robots: index
---
![](https://recurly.com/developers/images/recurly-js-logo.png)

***

### Customize your checkout process and accept payments securely

Securely accept sensitive payment details within your checkout process with a fully customizable user experience. The Recurly.js JavaScript library secures your checkout forms, allowing you to create subscriptions, process one-time transactions, and update customer billing information worry-free.

### PCI Compliance with Recurly.js elements

Recurly.js provides Elements that inject transparent iframes, enabling you to deliver a customized customer checkout experience while meeting the latest PCI DSS SAQ A compliance requirements.

### How it works

When a customer submits your payment form, Recurly.js immediately encrypts and securely stores their payment information on our servers. It then returns an authorization key—commonly known as a _token_—that you use to complete the subscription process through our API.

With this token, you can perform any API operation that requires payment details. Because you never directly handle sensitive payment information, your PCI compliance scope is significantly reduced.

***

### Open source

Recurly.js is open source, and we welcome you to view and contribute to the code on GitHub. We're here to make Recurly.js the best possible tool for your needs.

<a href="https://github.com/recurly/recurly-js" target="_blank" rel="noopener noreferrer">
  <img src="https://recurly.com/developers/images/GitHub-Mark-120px-plus.png" title="View code on GitHub" width="24" style={{ verticalAlign: 'middle' }} />

  <span> View code on GitHub</span>
</a>

***

##### Previous versions

<Cards columns={2}>
  <Card title="Recurly.js v4.10.3" icon="fa-code">
    <a href="https://docs.recurly.com/recurly-subscriptions/v1.2.1/docs/overview-recurlyjs-4103#/" target="_blank" rel="noopener noreferrer">
      Open v4.10.3 docs
    </a>
  </Card>

  <Card title="Recurly.js v4.35.0" icon="fa-code-branch">
    <a href="https://docs.recurly.com/recurly-subscriptions/v1.2.2/docs/overview-recurlyjs-4350#/" target="_blank" rel="noopener noreferrer">
      Open v4.35.0 docs
    </a>
  </Card>
</Cards>

<br />
