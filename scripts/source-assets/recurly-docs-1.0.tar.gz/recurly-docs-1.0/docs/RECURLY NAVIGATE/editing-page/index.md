---
title: Editing Page
deprecated: false
hidden: true
metadata:
  robots: index
---
<HTMLBlock>{`
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700;800;900&display=swap">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body { background: #ffffff !important; }
.rc-guide h1 { border-bottom: none !important; padding-bottom: 0 !important; }
.rc-guide, .rc-guide * { font-family: "Figtree", "Helvetica Neue", Helvetica, arial, sans-serif !important; }
.rc-guide [class^="fa-"],
.rc-guide [class*=" fa-"] { font-family: "Font Awesome 6 Free" !important; }
.rc-guide .fa-brands,
.rc-guide [class*="fa-brands"] { font-family: "Font Awesome 6 Brands" !important; }
.rm-Markdown.markdown-body .rc-guide a:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a, .rc-guide a:link, .rc-guide a:visited, .rc-guide a:active {
  color: #008CFF !important; text-decoration: none !important; text-decoration-line: none !important;
  text-decoration-color: transparent !important; text-underline-offset: unset !important; border-bottom: 0 !important;
}
.rc-guide a:hover { color: #0067BE !important; text-decoration: underline !important; text-decoration-color: #008CFF !important; text-underline-offset: 2px !important; }
html { scroll-behavior: smooth; scroll-padding-top: 80px; }
.rc-guide {
  --yellow: #FFD706; --blue: #008CFF; --blue-tint1: #D5EAFF; --blue-tint2: #96C8FF;
  --offblack: #0D0D0B; --darkgray: #32312D; --gray: #807D75; --lightgray: #D1CFC4;
  --brightgray: #F2F1EA; --offwhite: #FCFBF7; --scale: #008CFF;
  --warning-fg: #FFD706; --warning-bg: #FFFECB; --error-fg: #FF5126; --error-bg: #FFEEE9;
  --success-fg: #5DC32E; --success-bg: #EFFAEA; --info-fg: #008CFF; --info-bg: #E5F3FF;
  font-family: "Figtree", "Helvetica Neue", Helvetica, arial, sans-serif !important;
  color: #32312D !important; background: #ffffff;
}
.rc-guide * { box-sizing: border-box; }
.rc-fa-section { color: #0D0D0B; font-size: 1rem; }
.rc-top-nav { padding: 20px 40px 16px; max-width: 1200px; margin: 0 auto; }
.rm-Markdown.markdown-body .rc-guide a.rc-back-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-back-link { color: #807D75 !important; font-weight: 700; font-size: .9rem; display: inline-flex; align-items: center; gap: 6px; transition: color .2s; border-bottom: 0 !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-back-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-back-link:hover { color: #008CFF !important; }
.rc-content-wrap { max-width: 1200px; margin: 0 auto; padding: 0 40px; }
.rc-announce-bar { display: none; background: #FFD706; color: #0D0D0B; align-items: center; justify-content: space-between; padding: 10px 20px; font-size: .88rem; font-weight: 600; border-radius: 10px; margin-bottom: 16px; gap: 12px; line-height: 1.4; }
.rc-announce-bar.rc-active { display: flex; }
.rc-announce-inner { display: flex; align-items: center; gap: 10px; flex: 1; flex-wrap: wrap; }
.rc-fa-announce { color: #0D0D0B; font-size: 1rem; flex-shrink: 0; }
.rm-Markdown.markdown-body .rc-guide a.rc-announce-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-announce-link { color: #0D0D0B !important; font-weight: 800; white-space: nowrap; padding: 4px 12px; background: rgba(0,0,0,0.10); border-radius: 6px; transition: background 0.2s; border-bottom: 0 !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-announce-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-announce-link:hover { background: rgba(0,0,0,0.20); color: #0D0D0B !important; }
.rc-hero { background: linear-gradient(rgba(13,13,11,0.82), rgba(13,13,11,0.82)), url('https://files.readme.io/7a74d62bff1d532ca5adc49ae3d1c7d39a9703386b62fa98835df5c47a5f84b1-Topo_for_Black_Background_2.png') no-repeat center center; background-color: var(--offblack); background-size: cover; color: #fff; padding: 48px 40px 44px; text-align: center; border-radius: 16px; margin-bottom: 0; }
.rc-lp-pillar-tag { display: inline-flex; align-items: center; gap: 7px; background: rgba(0,140,255,0.20); border: 1px solid rgba(0,140,255,0.45); color: #008CFF; font-size: .75rem; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; padding: 6px 14px; border-radius: 20px; margin-bottom: 20px; }
.rc-lp-pillar-tag img { width: 13px; height: 13px; object-fit: contain; }
.rc-lp-hero-title { text-align: center; margin: 0 0 14px; }
.rc-lp-hero-title h1 { font-size: 2.4rem; font-weight: 800; line-height: 1.15; color: var(--offwhite); margin: 0; }
.rc-hero > p { font-size: 1rem; opacity: .85; max-width: 640px; margin: 0 auto 32px; color: var(--lightgray); line-height: 1.6; }
@media(max-width:768px){ .rc-hero { padding: 36px 20px 36px; } .rc-lp-hero-title h1 { font-size: 1.8rem; } }
details.rc-sticky-nav-wrap { position: relative; z-index: 1; background-color: var(--scale); box-shadow: 0 4px 12px rgba(0,0,0,0.08); margin: 24px 0 48px 0; border-radius: 12px; border: 1px solid rgba(0,0,0,0.08); overflow: hidden; }
details.rc-sticky-nav-wrap > summary { list-style: none; display: flex; align-items: center; padding: 15px 24px; cursor: pointer; user-select: none; }
details.rc-sticky-nav-wrap > summary::-webkit-details-marker { display: none; }
details.rc-sticky-nav-wrap > summary::marker { display: none; }
.rc-nav-toggle-label { display: inline-flex; align-items: center; gap: 8px; font-weight: 800; font-size: .88rem; letter-spacing: 0.6px; text-transform: uppercase; color: var(--offblack); }
.rc-nav-chevron { font-size: .72rem; color: var(--offblack); opacity: 0.55; line-height: 1; transition: transform 0.25s ease; }
details.rc-sticky-nav-wrap[open] .rc-nav-chevron { transform: rotate(180deg); }
.rc-nav-drawer { display: grid; grid-template-rows: 0fr; transition: grid-template-rows 0.3s ease; }
details.rc-sticky-nav-wrap[open] .rc-nav-drawer { grid-template-rows: 1fr; }
.rc-nav-drawer-inner { overflow: hidden; border-top: 1px solid rgba(0,0,0,0.10); }
.rc-nav-links { display: flex; flex-wrap: wrap; gap: 6px 4px; padding: 12px 20px 18px; }
.rm-Markdown.markdown-body .rc-guide a.rc-sticky-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-sticky-link { color: #0D0D0B !important; font-weight: 700; font-size: .83rem; letter-spacing: 0.4px; text-transform: uppercase; padding: 7px 14px; border-radius: 7px; transition: all .18s; white-space: nowrap; display: inline-flex; align-items: center; gap: 6px; border-bottom: 0 !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-sticky-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-sticky-link:hover { background: rgba(0,0,0,0.10); color: #0D0D0B !important; }
.rc-sticky-link img { width: 15px; height: 15px; object-fit: contain; }
.rc-step-badge { display: inline-flex; align-items: center; justify-content: center; width: 20px; height: 20px; border-radius: 50%; background: var(--offblack); color: var(--yellow); font-size: .65rem; font-weight: 800; flex-shrink: 0; line-height: 1; }
.rm-Markdown.markdown-body .rc-guide a.rc-sticky-link-active:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-sticky-link-active { font-weight: 800; color: #0D0D0B !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-sticky-link-active:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-sticky-link-active:hover { background: rgba(0,0,0,0.10); color: #0D0D0B !important; }
.rc-lp-section { margin-bottom: 40px; }
.rc-lp-section h2 { font-size: 1.5rem; font-weight: 800; margin: 0 0 20px; color: var(--offblack); display: flex; align-items: center; gap: 12px; }
.rc-lp-section h2::after { content: ""; flex-grow: 1; height: 1px; background: var(--lightgray); }
.rc-lp-section p { font-size: .95rem; line-height: 1.65; color: var(--darkgray); margin: 0 0 16px; }
.rc-callout { border-radius: 10px; padding: 16px 20px; margin: 20px 0; display: flex; gap: 14px; align-items: flex-start; }
.rc-callout + .rc-callout { margin-top: 12px; }
.rc-callout-icon { font-size: 1.1rem; line-height: 1.4; flex-shrink: 0; }
.rc-callout-body { flex: 1; }
.rc-callout-body > strong { font-size: .88rem; font-weight: 800; display: block; margin-bottom: 4px; }
.rc-callout-body p { font-size: .9rem; line-height: 1.55; margin: 0; color: var(--darkgray); }
.rc-callout-tip { background: var(--brightgray); border-left: 4px solid var(--offblack); }
.rc-callout-tip .rc-callout-body > strong { color: var(--offblack); }
.rc-callout-caution { background: var(--warning-bg); border-left: 4px solid var(--warning-fg); }
.rc-callout-caution .rc-callout-body > strong { color: var(--darkgray); }
.rc-steps { display: flex; flex-direction: column; gap: 0; margin: 20px 0 0; }
.rc-step { display: grid; grid-template-columns: 40px 1fr; gap: 16px; align-items: flex-start; padding: 18px 0; border-bottom: 1px solid var(--brightgray); }
.rc-step:last-child { border-bottom: none; }
.rc-step-num { width: 36px; height: 36px; border-radius: 50%; background: var(--offblack); color: var(--yellow); display: flex; align-items: center; justify-content: center; font-size: .85rem; font-weight: 800; flex-shrink: 0; margin-top: 2px; }
.rc-step-content h4 { font-size: 1.02rem; font-weight: 800; color: var(--offblack); margin: 0 0 6px; line-height: 1.3; }
.rc-step-content p { font-size: .92rem; color: var(--gray); line-height: 1.6; margin: 0; }
.rc-step-content strong { color: var(--darkgray); }
.rc-lp-nav { display: flex; align-items: center; justify-content: space-between; gap: 16px; margin: 40px 0 16px; flex-wrap: wrap; }
.rc-lp-nav-indicator { font-size: .8rem; font-weight: 600; color: var(--lightgray); letter-spacing: .5px; white-space: nowrap !important; flex-shrink: 0; }
.rm-Markdown.markdown-body .rc-guide a.rc-btn-prev:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-btn-prev { background: transparent; color: #0D0D0B !important; text-decoration: none !important; padding: 13px 24px; border-radius: 10px; font-weight: 700; font-size: .9rem; display: inline-flex; align-items: center; gap: 8px; border: 2px solid #D1CFC4 !important; border-bottom: 2px solid #D1CFC4 !important; transition: all .2s; white-space: nowrap !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-btn-prev:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-btn-prev:hover { border: 2px solid #0D0D0B !important; border-bottom: 2px solid #0D0D0B !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-btn-path:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-btn-path { background: var(--yellow); color: var(--offblack) !important; text-decoration: none !important; padding: 13px 28px; border-radius: 10px; font-weight: 800; font-size: .95rem; display: inline-flex; align-items: center; gap: 8px; transition: all .2s; border: 2px solid var(--yellow) !important; border-bottom: 2px solid var(--yellow) !important; white-space: nowrap !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-btn-path:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-btn-path:hover { background: transparent !important; color: var(--offblack) !important; border: 2px solid var(--yellow) !important; border-bottom: 2px solid var(--yellow) !important; }
@media(max-width:1300px) { .rc-lp-nav { justify-content: center !important; gap: 12px; } .rc-lp-nav-indicator { width: 100% !important; text-align: center; } }
@media(max-width:768px) {
  .rm-Markdown.markdown-body .rc-guide a.rc-btn-prev:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
  .rc-guide a.rc-btn-prev,
  .rm-Markdown.markdown-body .rc-guide a.rc-btn-path:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
  .rc-guide a.rc-btn-path { padding: 10px 16px !important; font-size: 0.82rem !important; }
}
.rc-resources { background: var(--brightgray); border-left: 4px solid #008CFF; border-radius: 10px; padding: 20px 24px; margin: 32px 0 0; }
.rc-resources h3 { font-size: .75rem; font-weight: 700; text-transform: uppercase; letter-spacing: .9px; color: var(--gray); margin: 0 0 12px; display: flex; align-items: center; gap: 8px; }
.rc-resource-links { display: flex; flex-wrap: wrap; gap: 4px 20px; }
.rm-Markdown.markdown-body .rc-guide a.rc-resource-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-resource-link { color: #807D75 !important; text-decoration: underline !important; text-underline-offset: 3px; text-decoration-color: #D1CFC4 !important; font-weight: 500; font-size: .88rem; transition: all .18s; display: inline-flex; align-items: center; gap: 6px; border-bottom: 0 !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-resource-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-resource-link:hover { color: #0D0D0B !important; text-decoration: underline !important; text-underline-offset: 3px; text-decoration-color: #008CFF !important; }
.rc-footer-nav { border-top: 1px solid var(--lightgray); padding-top: 40px; margin-top: 48px; padding-bottom: 48px; }
.rc-footer-links { display: flex; flex-direction: column; gap: 16px; }
.rc-footer-section { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 24px; }
.rc-footer-label { font-weight: 800; font-size: .75rem; text-transform: uppercase; letter-spacing: .8px; color: var(--darkgray); background: var(--brightgray); padding: 4px 10px; border-radius: 6px; margin-right: 4px; }
.rm-Markdown.markdown-body .rc-guide a.rc-footer-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-footer-link { color: #807D75 !important; text-decoration: none !important; font-weight: 600; font-size: .88rem; transition: color .2s ease; display: inline-flex; align-items: center; gap: 6px; border-bottom: 0 !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-footer-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-footer-link:hover { color: #008CFF !important; }
.rc-footer-link img { width: 14px; height: 14px; object-fit: contain; opacity: 0.5; transition: opacity .2s ease; }
.rc-footer-link:hover img { opacity: 1; }
.rc-footer-utility { display: flex; flex-wrap: wrap; gap: 24px; margin-top: 16px; padding-top: 24px; border-top: 1px solid var(--brightgray); }

/* EU comparison table wrapper */
.rc-eu-table-wrap { 
  overflow-x: auto; 
  margin: 8px 0 24px; 
  border: 1px solid var(--lightgray); 
  border-radius: 10px; 
}

/* Force table expansion and remove bottom margin white space */
.rm-Markdown.markdown-body .rc-guide table.rc-eu-table,
.rc-eu-table { 
  width: 100% !important; 
  display: table !important; 
  border-collapse: collapse; 
  font-size: .84rem; 
  margin: 0 !important; 
  margin-bottom: 0 !important; 
}

.rc-eu-table thead tr { 
  background: #0D0D0B !important; 
}

/* Header high-specificity font color & background fix */
.rm-Markdown.markdown-body .rc-guide .rc-eu-table thead th,
.rc-eu-table thead th { 
  background-color: #0D0D0B !important; 
  color: #ffffff !important; 
  font-weight: 700; 
  text-align: left; 
  padding: 10px 12px; 
  white-space: normal; 
  vertical-align: bottom; 
}

/* Body rows & cell styles */
.rc-eu-table tbody tr { 
  background: var(--offwhite); 
}

.rc-eu-table tbody tr:nth-child(even) { 
  background: #ffffff; 
}

.rc-eu-table tbody td { 
  padding: 10px 12px; 
  color: var(--darkgray); 
  border-bottom: 1px solid var(--brightgray); 
}

.rc-eu-table tbody tr:last-child td { 
  border-bottom: none; 
}

/* Accordion styling */
.rc-country-accordion-header {
  margin: 32px 0 12px;
}
.rc-country-accordion-header h3 {
  font-size: 1.25rem;
  font-weight: 800;
  color: var(--offblack);
  margin: 0 0 6px;
}
.rc-country-accordion-header p {
  font-size: .92rem;
  color: var(--darkgray);
  margin: 0;
  line-height: 1.5;
}
.rc-country-accordions {
  margin: 16px 0 28px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
details.rc-accordion-item {
  background: var(--offwhite);
  border: 1px solid var(--lightgray);
  border-radius: 10px;
  overflow: hidden;
  transition: border-color 0.2s ease;
}
details.rc-accordion-item[open] {
  border-color: var(--gray);
}
details.rc-accordion-item > summary {
  list-style: none;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 20px;
  cursor: pointer;
  user-select: none;
  background: var(--brightgray);
  font-weight: 700;
  font-size: .95rem;
  color: var(--offblack);
}
details.rc-accordion-item > summary::-webkit-details-marker { display: none; }
details.rc-accordion-item > summary::marker { display: none; }
.rc-accordion-title {
  display: flex;
  align-items: center;
  gap: 10px;
}
.rc-accordion-chevron {
  font-size: .8rem;
  color: var(--gray);
  transition: transform 0.25s ease;
}
details.rc-accordion-item[open] .rc-accordion-chevron {
  transform: rotate(180deg);
}
.rc-accordion-content {
  padding: 20px 24px 24px;
  border-top: 1px solid var(--lightgray);
  background: #ffffff;
}
.rc-country-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
  margin-bottom: 20px;
}
@media (max-width: 860px) {
  .rc-country-grid {
    grid-template-columns: 1fr;
  }
}
.rc-country-col h4 {
  font-size: .95rem;
  font-weight: 800;
  color: var(--offblack);
  margin: 0 0 10px;
}
.rc-country-col ul {
  margin: 0;
  padding-left: 20px;
  font-size: .88rem;
  line-height: 1.6;
  color: var(--darkgray);
}
.rc-country-col ul li {
  margin-bottom: 6px;
}
.rc-country-col ul.checklist {
  list-style-type: none;
  padding-left: 0;
}
.rc-country-col ul.checklist li {
  position: relative;
  padding-left: 20px;
}
.rc-country-col ul.checklist li::before {
  content: "✓";
  position: absolute;
  left: 0;
  color: var(--offblack);
  font-weight: 800;
}

@media(max-width:768px){ .rc-content-wrap { padding: 0 20px; } .rc-top-nav { padding: 16px 20px; } }
</style>

<div class="rc-guide">
  <div class="rc-top-nav">
    <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale" class="rc-back-link">← Back to Scale</a>
  </div>

  <div class="rc-content-wrap">

    <div class="rc-announce-bar">
      <div class="rc-announce-inner">
        <i class="fa-regular fa-calendar-days rc-fa-announce"></i>
        <strong>Upcoming:</strong> Join our CSMs for a live session.
        <a href="https://navigate.recurly.com/global-office-hours/" target="_blank" rel="noopener noreferrer" class="rc-announce-link">Register now →</a>
      </div>
    </div>

    <div class="rc-hero">
      <div class="rc-lp-pillar-tag">
        <img src="https://files.readme.io/7038a0b3a299cfe800553d4c8a6721f92b1fc7e031ef697861d3603fb1bb5a05-Scale-icon-white.png" alt="Scale"> Scale · Payment methods by region
      </div>
      <div class="rc-lp-hero-title"><h1>EU</h1></div>
      <p>Why Belgium, France, Germany, Denmark, and the Netherlands each favor a different local method.</p>
    </div>

    <details class="rc-sticky-nav-wrap" open>
      <summary><span class="rc-nav-toggle-label">Navigation Menu <i class="fa-solid fa-chevron-up rc-nav-chevron"></i></span></summary>
      <div class="rc-nav-drawer"><div class="rc-nav-drawer-inner"><div class="rc-nav-links">
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-home" class="rc-sticky-link">
          <img src="https://files.readme.io/105d407afb9e682bd60fbc60587b3da1cfb3d09be95148d71529b20fb286aadf-Home_icon_2.png" alt=""> Navigate Home
        </a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region" class="rc-sticky-link">Path overview</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-UK" class="rc-sticky-link"><span class="rc-step-badge">1</span> UK</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-North-America" class="rc-sticky-link"><span class="rc-step-badge">2</span> North America</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-EU" class="rc-sticky-link rc-sticky-link-active">
          <img src="https://files.readme.io/070e914d23dead09604d5f96b8769c88b8aae704ebd4505415e5854011030110-Black_Navigate_Home_Pin_1.png" alt=""> EU
        </a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-APAC" class="rc-sticky-link"><span class="rc-step-badge">4</span> APAC</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-LATAM" class="rc-sticky-link"><span class="rc-step-badge">5</span> LATAM</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-review" class="rc-sticky-link"><span class="rc-step-badge">6</span> Review &amp; resources</a>
       
      </div></div></div>
    </details>

    <div class="rc-lp-section">
      <h2><i class="fa-solid fa-euro-sign rc-fa-section"></i> Why it matters</h2>
      <p>Shared currency and shared compliance rules mask sharp differences in how EU customers actually prefer to pay. Belgium looks to Bancontact, France to SEPA and Carte Bancaire, Germany to PayPal over cards, Denmark to Dankort, and the Netherlands to iDEAL. Treating "EU" as one payment strategy leaves conversion on the table in every one of these markets.</p>

      <div class="rc-eu-table-wrap">
        <table class="rc-eu-table">
          <thead><tr><th>Country</th><th>Dominant local method</th><th>Why it matters</th></tr></thead>
          <tbody>
            <tr><td>Belgium</td><td>Bancontact</td><td>Used by ~60% of Belgian online shoppers; co-badged card mandate applies</td></tr>
            <tr><td>France</td><td>SEPA Direct Debit / Carte Bancaire</td><td>Strong preference for SEPA and PayPal; Carte Bancaire required under co-badging rules</td></tr>
            <tr><td>Germany</td><td>PayPal</td><td>47% conversion lift for digital goods merchants offering PayPal; #1 method in the country</td></tr>
            <tr><td>Denmark</td><td>Dankort</td><td>Co-branded Visa card; effectively mandatory for Danish subscription conversion</td></tr>
            <tr><td>Netherlands</td><td>iDEAL</td><td>Over 70% of Dutch online purchases; 39% conversion lift when offered</td></tr>
          </tbody>
      </table>
      </div>

      <div class="rc-country-accordion-header">
        <h3>Country-Specific Performance &amp; Breakdown</h3>
        <p>Select a country below to view detailed payment method sign-up and renewal conversion metrics, volume shares, market considerations, and expansion checklists.</p>
      </div>

      <div class="rc-country-accordions">

        <!-- Belgium Accordion -->
        <details class="rc-accordion-item">
          <summary>
            <span class="rc-accordion-title">🇧🇪 Belgium — Euro (EUR)</span>
            <i class="fa-solid fa-chevron-down rc-accordion-chevron"></i>
          </summary>
          <div class="rc-accordion-content">
            <div class="rc-country-grid">
              <div class="rc-country-col">
                <h4>Considerations</h4>
                <ul>
                  <li>Bancontact is the primary local card scheme, used by nearly 60% of Belgian consumers for online purchases — absence has a direct impact on conversion.</li>
                  <li>SEPA Direct Debit increases conversion by 12% when used by EU customers.</li>
                  <li>Payconiq is the companion mobile app to Bancontact, growing especially among younger consumers.</li>
                  <li>Standard VAT rate is 21%. Register via EU OSS scheme once exceeding €10,000 cross-border digital services threshold.</li>
                  <li>Companies must notify customers at least 15 days in advance of a renewal. A 14-day right of withdrawal applies to most digital subscriptions.</li>
                  <li>Belgium has three official languages: French, Dutch (Flemish), and German.</li>
                </ul>
              </div>
              <div class="rc-country-col">
                <h4>Expansion Checklist</h4>
                <ul class="checklist">
                  <li>Enable EUR currency</li>
                  <li>Enable 3DS (PSD2 compliance)</li>
                  <li>Register for EU VAT via OSS scheme</li>
                  <li>Enable SEPA Direct Debit</li>
                  <li>Support Bancontact under Co-badged Card mandate</li>
                  <li>Offer invoice translations in French, Dutch, and German</li>
                </ul>
              </div>
            </div>
            <h4>Payment Method Performance</h4>
            <div class="rc-eu-table-wrap">
              <table class="rc-eu-table">
                <thead>
                  <tr>
                    <th>Payment Type</th>
                    <th>Sign-up %</th>
                    <th>Renewal %</th>
                    <th>% of Volume when Merchant is Offering Payment Type</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td>Apple Pay</td><td>68.86%</td><td>80.95%</td><td>6.1%</td></tr>
                  <tr><td>Credit Card</td><td>73.43%</td><td>87.76%</td><td>53.96%</td></tr>
                  <tr><td>Google Pay</td><td>54.59%</td><td>81.91%</td><td>1.7%</td></tr>
                  <tr><td>PayPal</td><td>92.28%</td><td>94.86%</td><td>29.21%</td></tr>
                  <tr><td>SEPA</td><td>99.40%</td><td>99.90%</td><td>46.92%</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </details>

        <!-- France Accordion -->
        <details class="rc-accordion-item">
          <summary>
            <span class="rc-accordion-title">🇫🇷 France — Euro (EUR)</span>
            <i class="fa-solid fa-chevron-down rc-accordion-chevron"></i>
          </summary>
          <div class="rc-accordion-content">
            <div class="rc-country-grid">
              <div class="rc-country-col">
                <h4>Considerations</h4>
                <ul>
                  <li>French law requires all commercial communications, contracts, and consumer-facing materials directed at French consumers be in French — this is a legal requirement.</li>
                  <li>French law requires B2C businesses to provide access to a consumer mediation service for dispute resolution.</li>
                  <li>Strong preference toward SEPA Direct Debit and PayPal.</li>
                  <li>VAT rate is 20%. Register via EU OSS scheme once exceeding €10,000 threshold.</li>
                  <li>Renewable contracts must notify consumers of their right to cancel between 1–3 months before renewal. Failure gives the consumer the right to cancel and receive a refund at any time.</li>
                  <li>Consumers can cancel most subscription contracts at any time after the first 12 months with just 1 month's notice.</li>
                </ul>
              </div>
              <div class="rc-country-col">
                <h4>Expansion Checklist</h4>
                <ul class="checklist">
                  <li>Enable EUR currency</li>
                  <li>Enable 3DS (PSD2 compliance)</li>
                  <li>Register for EU VAT via OSS scheme (20% rate)</li>
                  <li>Translate all customer-facing content into French</li>
                  <li>Enable SEPA Direct Debit and PayPal</li>
                  <li>Implement consumer mediation service reference in T&amp;Cs</li>
                </ul>
              </div>
            </div>
            <h4>Payment Method Performance</h4>
            <div class="rc-eu-table-wrap">
              <table class="rc-eu-table">
                <thead>
                  <tr>
                    <th>Payment Type</th>
                    <th>Sign-up %</th>
                    <th>Renewal %</th>
                    <th>% of Volume when Merchant is Offering Payment Type</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td>Apple Pay</td><td>87.05%</td><td>82.72%</td><td>10.20%</td></tr>
                  <tr><td>Credit Card</td><td>67.88%</td><td>89.34%</td><td>67.71%</td></tr>
                  <tr><td>Google Pay</td><td>70.13%</td><td>79.48%</td><td>1.64%</td></tr>
                  <tr><td>PayPal</td><td>92.29%</td><td>96.45%</td><td>27.41%</td></tr>
                  <tr><td>SEPA</td><td>92.85%</td><td>92.60%</td><td>14.69%</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </details>

        <!-- Germany Accordion -->
        <details class="rc-accordion-item">
          <summary>
            <span class="rc-accordion-title">🇩🇪 Germany — Euro (EUR)</span>
            <i class="fa-solid fa-chevron-down rc-accordion-chevron"></i>
          </summary>
          <div class="rc-accordion-content">
            <div class="rc-country-grid">
              <div class="rc-country-col">
                <h4>Considerations</h4>
                <ul>
                  <li>PayPal is the #1 payment method in Germany — 64% increase in conversion when offered. Many consumers do not use or prefer credit cards.</li>
                  <li>SEPA direct deposit and digital wallets are gaining popularity.</li>
                  <li>Businesses offering Revolut Pay via Stripe saw an average 3% increase in conversion and 13% increase in revenue.</li>
                  <li>B2C subscriptions must include a clearly labelled cancellation button: 'Jetzt kündigen' ('Cancel now').</li>
                  <li>Auto-renewal periods for consumer contracts are capped at one month at a time after the initial term.</li>
                  <li>VAT rate is 19%. Register via EU OSS scheme.</li>
                </ul>
              </div>
              <div class="rc-country-col">
                <h4>Expansion Checklist</h4>
                <ul class="checklist">
                  <li>Enable EUR currency</li>
                  <li>Enable 3DS (PSD2 compliance)</li>
                  <li>Register for EU VAT via OSS scheme (19% rate)</li>
                  <li>Enable PayPal as priority payment method</li>
                  <li>Enable SEPA Direct Debit</li>
                  <li>Implement 'Jetzt kündigen' cancellation button (legal requirement)</li>
                </ul>
              </div>
            </div>
            <h4>Payment Method Performance</h4>
            <div class="rc-eu-table-wrap">
              <table class="rc-eu-table">
                <thead>
                  <tr>
                    <th>Payment Type</th>
                    <th>Sign-up %</th>
                    <th>Renewal %</th>
                    <th>% of Volume when Merchant is Offering Payment Type</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td>Apple Pay</td><td>83.68%</td><td>87.95%</td><td>3.60%</td></tr>
                  <tr><td>Credit Card</td><td>71.13%</td><td>88.90%</td><td>24.58%</td></tr>
                  <tr><td>Google Pay</td><td>70.58%</td><td>84.32%</td><td>0.50%</td></tr>
                  <tr><td>PayPal</td><td>88.77%</td><td>97.40%</td><td>63.79%</td></tr>
                  <tr><td>SEPA</td><td>99.25%</td><td>99.89%</td><td>44.35%</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </details>

        <!-- Italy Accordion -->
        <details class="rc-accordion-item">
          <summary>
            <span class="rc-accordion-title">🇮🇹 Italy — Euro (EUR)</span>
            <i class="fa-solid fa-chevron-down rc-accordion-chevron"></i>
          </summary>
          <div class="rc-accordion-content">
            <div class="rc-country-grid">
              <div class="rc-country-col">
                <h4>Considerations</h4>
                <ul>
                  <li>PayPal is the #2 payment method in Italy — 40.64% increase in conversion when offered. Many consumers do not use or prefer credit cards.</li>
                  <li>SEPA direct deposit and digital wallets are gaining popularity.</li>
                  <li>Italy has one of the highest adoption rates of digital wallets.</li>
                  <li>Italy requires e-invoicing using the government's Sistema di Interscambio.</li>
                  <li>Article 54-bis goes into effect 19 June 2026 and requires an explicit, dedicated cancellation button on all websites offering subscription services.</li>
                  <li>VAT rate is 22%. Register via EU OSS scheme.</li>
                </ul>
              </div>
              <div class="rc-country-col">
                <h4>Expansion Checklist</h4>
                <ul class="checklist">
                  <li>Enable EUR currency</li>
                  <li>Enable 3DS (PSD2 compliance)</li>
                  <li>Register for EU VAT via OSS scheme (22% rate)</li>
                  <li>Enable PayPal as priority payment method</li>
                  <li>Enable SEPA Direct Debit</li>
                  <li>Implement e-invoicing and cancellation buttons (legal requirements)</li>
                </ul>
              </div>
            </div>
            <h4>Payment Method Performance</h4>
            <div class="rc-eu-table-wrap">
              <table class="rc-eu-table">
                <thead>
                  <tr>
                    <th>Payment Type</th>
                    <th>Sign-up %</th>
                    <th>Renewal %</th>
                    <th>% of Volume when Merchant is Offering Payment Type</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td>Apple Pay</td><td>88.06%</td><td>72.91%</td><td>10.07%</td></tr>
                  <tr><td>Credit Card</td><td>72.71%</td><td>80.52%</td><td>56.19%</td></tr>
                  <tr><td>Google Pay</td><td>76.46%</td><td>74.24%</td><td>4.13%</td></tr>
                  <tr><td>PayPal</td><td>85.44%</td><td>92.66%</td><td>40.64%</td></tr>
                  <tr><td>SEPA</td><td>93.67%</td><td>93.96%</td><td>8.11%</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </details>

        <!-- Denmark Accordion -->
        <details class="rc-accordion-item">
          <summary>
            <span class="rc-accordion-title">🇩🇰 Denmark — Danish Krone (DKK)</span>
            <i class="fa-solid fa-chevron-down rc-accordion-chevron"></i>
          </summary>
          <div class="rc-accordion-content">
            <div class="rc-country-grid">
              <div class="rc-country-col">
                <h4>Considerations</h4>
                <ul>
                  <li>Offering Dankort (co-branded Visa) is effectively mandatory — absence will materially impact conversion.</li>
                  <li>PayPal is an increasingly popular payment method, outperforming credit cards and Apple Pay.</li>
                  <li>Denmark's VAT rate is 25% and applies broadly to all sales.</li>
                  <li>Subscription auto-renewal terms must be clearly disclosed at the point of sign-up.</li>
                  <li>Despite exceptionally high English proficiency, customer-facing subscription terms and cancellation flows should be available in Danish.</li>
                  <li>Corporate income tax rate is 22%; 15% global minimum tax for large multinationals (Pillar Two).</li>
                </ul>
              </div>
              <div class="rc-country-col">
                <h4>Expansion Checklist</h4>
                <ul class="checklist">
                  <li>Enable DKK currency</li>
                  <li>Enable 3DS (PSD2 compliance)</li>
                  <li>Apply Danish VAT at 25%</li>
                  <li>Enable Dankort (co-branded Visa) — required for conversion</li>
                  <li>Enable PayPal</li>
                  <li>Ensure Danish-language cancellation flows</li>
                </ul>
              </div>
            </div>
            <h4>Payment Method Performance</h4>
            <div class="rc-eu-table-wrap">
              <table class="rc-eu-table">
                <thead>
                  <tr>
                    <th>Payment Type</th>
                    <th>Sign-up %</th>
                    <th>Renewal %</th>
                    <th>% of Volume when Merchant is Offering Payment Type</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td>Apple Pay</td><td>87.85%</td><td>79.25%</td><td>5.18%</td></tr>
                  <tr><td>Credit Card</td><td>75.65%</td><td>89.57%</td><td>78.62%</td></tr>
                  <tr><td>Google Pay</td><td>82.24%</td><td>83.21%</td><td>1.20%</td></tr>
                  <tr><td>PayPal</td><td>82.64%</td><td>93.16%</td><td>20.49%</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </details>

        <!-- Netherlands Accordion -->
        <details class="rc-accordion-item">
          <summary>
            <span class="rc-accordion-title">🇳🇱 Netherlands — Euro (EUR)</span>
            <i class="fa-solid fa-chevron-down rc-accordion-chevron"></i>
          </summary>
          <div class="rc-accordion-content">
            <div class="rc-country-grid">
              <div class="rc-country-col">
                <h4>Considerations</h4>
                <ul>
                  <li>iDEAL is the go-to method for over 70% of online purchases in the Netherlands — offering it drives a 39% increase in conversion.</li>
                  <li>PayPal outperforms credit cards and digital wallets, though Apple Pay and Google Pay are preferred by younger Dutch consumers.</li>
                  <li>Standard Dutch VAT rate is 21%.</li>
                  <li>Consumers must be able to cancel via the same channel they used to subscribe (e.g. if subscribed online, must be able to cancel online).</li>
                  <li>Dutch law prohibits automatically converting expired subscriptions into new fixed-term contracts.</li>
                  <li>Companies must clearly state when a free trial ends and send a reminder before paid billing begins.</li>
                </ul>
              </div>
              <div class="rc-country-col">
                <h4>Expansion Checklist</h4>
                <ul class="checklist">
                  <li>Enable EUR currency</li>
                  <li>Enable 3DS (PSD2 compliance)</li>
                  <li>Register for EU VAT via OSS scheme (21% rate)</li>
                  <li>Enable iDEAL (critical for conversion)</li>
                  <li>Enable SEPA Direct Debit and PayPal</li>
                  <li>Implement same-channel cancellation mechanism</li>
                </ul>
              </div>
            </div>
            <h4>Payment Method Performance</h4>
            <div class="rc-eu-table-wrap">
              <table class="rc-eu-table">
                <thead>
                  <tr>
                    <th>Payment Type</th>
                    <th>Sign-up %</th>
                    <th>Renewal %</th>
                    <th>% of Volume when Merchant is Offering Payment Type</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td>Apple Pay</td><td>84.21%</td><td>82.33%</td><td>6.37%</td></tr>
                  <tr><td>Credit Card</td><td>72.73%</td><td>87.17%</td><td>51.84%</td></tr>
                  <tr><td>Google Pay</td><td>75.19%</td><td>79.04%</td><td>2.09%</td></tr>
                  <tr><td>PayPal</td><td>90.85%</td><td>96.39%</td><td>32.78%</td></tr>
                  <tr><td>SEPA</td><td>99.32%</td><td>99.95%</td><td>60.60%</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </details>

      </div>

      <div class="rc-callout rc-callout-tip">
        <div class="rc-callout-icon"><i class="fa-solid fa-lightbulb"></i></div>
        <div class="rc-callout-body">
          <strong>SEPA Direct Debit is the EU-wide constant</strong>
          <p>Across Belgium, France, Germany, and the Netherlands, SEPA converts and renews above 91% — layer it in everywhere alongside whichever local method matters most in that specific market.</p>
        </div>
      </div>

      <div class="rc-callout rc-callout-caution">
        <div class="rc-callout-icon"><i class="fa-solid fa-triangle-exclamation"></i></div>
      0 <div class="rc-callout-body">
          <strong>Co-badged card compliance is an EU-wide requirement</strong>
          <p>Under EU IFR Regulation 2015/751, when a customer's card carries two brands (e.g. a local scheme plus Visa or Mastercard) and your checkout supports both, the customer must be able to choose which brand to pay with.</p>
        </div>
      </div>
    </div>

    <div class="rc-lp-section">
      <h2><i class="fa-solid fa-gears rc-fa-section"></i> How to enable it</h2>
      <div class="rc-steps">
        <div class="rc-step">
          <div class="rc-step-num">1</div>
          <div class="rc-step-content">
            <h4>Enable EUR and DKK as needed</h4>
            <p>In <strong>Configuration → Currencies</strong>, add Euro for Belgium, France, Germany, and the Netherlands, and Danish Krone for Denmark. Set localized pricing per plan.</p>
          </div>
        </div>
        <div class="rc-step">
          <div class="rc-step-num">2</div>
          <div class="rc-step-content">
            <h4>Confirm local method support on your gateway</h4>
            <p>iDEAL and SEPA are available through Adyen or Stripe. Bancontact and Dankort require Adyen specifically — confirm your configured gateway before enabling.</p>
          </div>
        </div>
        <div class="rc-step">
          <div class="rc-step-num">3</div>
          <div class="rc-step-content">
            <h4>Enable 3D Secure</h4>
            <p>3DS is required across the EU under PSD2. Confirm it's active in <strong>Configuration → Payment gateways</strong> for every card transaction.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="rc-lp-nav">
      <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-North-America" class="rc-btn-prev">← North America</a>
      <span class="rc-lp-nav-indicator">3 of 6</span>
      <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-APAC" class="rc-btn-path">Next: APAC →</a>
    </div>

    <div class="rc-resources">
      <h3><i class="fa-solid fa-book-open rc-fa-section"></i> Resources</h3>
      <div class="rc-resource-links">
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/ideal" target="_blank" rel="noopener noreferrer" class="rc-resource-link"><i class="fa-regular fa-file-lines"></i> Recurly Docs: iDEAL</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/sepa-direct-debit" target="_blank" rel="noopener noreferrer" class="rc-resource-link"><i class="fa-regular fa-file-lines"></i> Recurly Docs: SEPA</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/co-badged-cards-guide" target="_blank" rel="noopener noreferrer" class="rc-resource-link"><i class="fa-regular fa-file-lines"></i> Recurly Docs: Co-badged cards guide</a>
        <a href="mailto:support@recurly.com" class="rc-resource-link"><i class="fa-solid fa-headset"></i> Contact Recurly Support</a>
      </div>
    </div>

    <div class="rc-footer-nav">
      <div class="rc-footer-links">
        <div class="rc-footer-section">
          <span class="rc-footer-label">Payment methods by region</span>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region" class="rc-footer-link">Path overview</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-UK" class="rc-footer-link">1. UK</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-North-America" class="rc-footer-link">2. North America</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-EU" class="rc-footer-link">3. EU</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-APAC" class="rc-footer-link">4. APAC</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-LATAM" class="rc-footer-link">5. LATAM</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-payment-methods-region-review" class="rc-footer-link">6. Review &amp; resources</a>
        </div>
        <div class="rc-footer-utility">
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-home" class="rc-footer-link">
            <img src="https://files.readme.io/105d407afb9e682bd60fbc60587b3da1cfb3d09be95148d71529b20fb286aadf-Home_icon_2.png" alt="Home"> Navigate Home
          </a>
          <a href="mailto:support@recurly.com" class="rc-footer-link">Contact Support</a>
        </div>
      </div>
    </div>

  </div>
</div>
`}</HTMLBlock>
