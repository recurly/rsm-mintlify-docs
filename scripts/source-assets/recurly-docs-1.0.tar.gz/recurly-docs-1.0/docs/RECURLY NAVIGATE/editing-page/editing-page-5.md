---
title: Editing page 5
deprecated: false
hidden: true
metadata:
  robots: index
---
<HTMLBlock>{`
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" class="gs-rte gs-rte-eb-html"><head class="gs-rte gs-rte-eb-head" id="i28m" data-gjs-type="head">
  <style type="text/css">
@media only screen and (max-width: 620px) {
  table[class="container"] { width: 100% !important; }
  td[class="mobile-center"] { text-align: center !important; }
  td[class="img-less-padding"] { padding: 10px 20px !important; }
  img[class="responsive-img"] { width: 100% !important; height: auto !important; }
  td[class="stack-column"], td[class="stack-column-cell"] { display: block !important; width: 100% !important; box-sizing: border-box !important; }
  td[class="stack-column"] > span { font-size: 64px !important; }
  table[class="no-padding-mobile"], td[class="no-padding-mobile"] { padding: 0px !important; margin: 0px !important; }
  h1, h2, h3 { font-size: 20px !important; line-height: 1.4 !important; }
  p { font-size: 16px !important; }
}</style>

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recurly Navigate Monthly Snapshot</title>
<style gs-style-type="inline" data-type="inline" type="text/css" role="inline" rel="stylesheet">
.gs-text-transform.gs-text-transform-lowercase { text-transform: lowercase; }
.gs-text-transform.gs-text-transform-uppercase { text-transform: uppercase; }
.gs-text-transform.gs-text-transform-capitalize { text-transform: capitalize; }
.gs-container-descriptor { pointer-events: none; }
.gs-socials { border-collapse: separate !important; line-height: 100% !important; }
.gs-socials .gs-social-column { border-width: medium !important; border-style: none !important; border-color: currentcolor !important; border-image: initial !important; border-radius: 3px !important; cursor: auto !important; }
.gs-socials .gs-social-column a { display: inline-block !important; }
.gs-socials[data-rte-social-style="white"] { background-color: #008cff; }
.gs-socials.social-icons-sm a img { width: 32px; }
.gs-socials.social-icons-md a img { width: 48px; }
.gs-socials.social-icons-lg a img { width: 64px; }
[eb-block-container] { vertical-align: top; box-sizing: border-box; }
[gs-eb-block], [gs-eb-block] table { font-size: 13px; }
[gs-rte-indent] { margin: 0px 0px 0px 40px; }</style><link rel="stylesheet" type="text/css" id="mce-u234" crossorigin="anonymous" referrerpolicy="origin" href="https://cdn.tiny.cloud/1/orhttebj9nysf6w4jmz4x9bg4sa0m26m36ymzlew7arsv096/tinymce/8.3.0-113/skins/ui/oxide/skin.min.css"><link rel="stylesheet" type="text/css" id="mce-u235" crossorigin="anonymous" referrerpolicy="origin" href="https://cdn.tiny.cloud/1/orhttebj9nysf6w4jmz4x9bg4sa0m26m36ymzlew7arsv096/tinymce/8.3.0-113/skins/ui/oxide/content.inline.min.css"><link rel="stylesheet" type="text/css" id="mce-u90" crossorigin="anonymous" referrerpolicy="origin" href="https://cdn.tiny.cloud/1/orhttebj9nysf6w4jmz4x9bg4sa0m26m36ymzlew7arsv096/tinymce/8.3.0-113/skins/ui/oxide/skin.min.css"><link rel="stylesheet" type="text/css" id="mce-u91" crossorigin="anonymous" referrerpolicy="origin" href="https://cdn.tiny.cloud/1/orhttebj9nysf6w4jmz4x9bg4sa0m26m36ymzlew7arsv096/tinymce/8.3.0-113/skins/ui/oxide/content.inline.min.css"><!--[if mso]><style data-gs-oquirks="mso-arial">* { font-family: Arial, Helvetica, sans-serif !important; mso-line-height-rule: exactly; }</style><![endif]--><style gs-style-type="responsive" data-type="responsive" type="text/css" role="export" rel="stylesheet">@media screen and (max-width: 480px) {
  #email-container-main {
    width: 100% !important;
  }

  #email-container-table {
    width: 100% !important;
  }

  .report-img {
    width: 100% !important;
  }

  table.gs-responsive tbody td.gs-responsive {
    display: block !important;
    width: 100% !important;
    margin-top: 5px;
    margin-bottom: 5px;
  }

  .rte-img-container.gs-responsive {
    width: 100% !important;
  }

  img.gs-responsive {
    width: 100% !important;
  }

  [rte-inline-survey-placeholder] {
    width: 100% !important;
  }

  .rte-divider-container {
    width: 100% !important;
  }
  .rte-divider-container > * {
    width: 100% !important;
  }
}
/* These styles will only apply to Apple Mail and WebKit-based browsers */
@media screen and (-webkit-min-device-pixel-ratio: 0) {
  img {
    margin-left: 0;
  }
}</style><style gs-style-type="force" data-type="force" type="text/css" role="export" rel="stylesheet">table[gs-eb-block] {
  table-layout: fixed;
}

table[gs-eb-block] [eb-block-container] {
  overflow: hidden;
  word-wrap: break-word;
}

.mce-content-body audio[data-mce-selected],
.mce-content-body details[data-mce-selected],
.mce-content-body embed[data-mce-selected],
.mce-content-body img[data-mce-selected],
.mce-content-body object[data-mce-selected],
.mce-content-body table[data-mce-selected],
.mce-content-body video[data-mce-selected] {
  outline: 0 !important;
}

li {
  white-space: normal !important;
}</style><link rel="stylesheet" type="text/css" id="mce-u0" crossorigin="anonymous" referrerpolicy="origin" href="https://cdn.tiny.cloud/1/orhttebj9nysf6w4jmz4x9bg4sa0m26m36ymzlew7arsv096/tinymce/8.3.0-113/skins/ui/oxide/skin.min.css"><link rel="stylesheet" type="text/css" id="mce-u1" crossorigin="anonymous" referrerpolicy="origin" href="https://cdn.tiny.cloud/1/orhttebj9nysf6w4jmz4x9bg4sa0m26m36ymzlew7arsv096/tinymce/8.3.0-113/skins/ui/oxide/content.inline.min.css"><link rel="stylesheet" type="text/css" id="mce-u8" crossorigin="anonymous" referrerpolicy="origin" href="https://cdn.tiny.cloud/1/orhttebj9nysf6w4jmz4x9bg4sa0m26m36ymzlew7arsv096/tinymce/8.3.0-113/skins/ui/oxide/skin.min.css"><link rel="stylesheet" type="text/css" id="mce-u9" crossorigin="anonymous" referrerpolicy="origin" href="https://cdn.tiny.cloud/1/orhttebj9nysf6w4jmz4x9bg4sa0m26m36ymzlew7arsv096/tinymce/8.3.0-113/skins/ui/oxide/content.inline.min.css"><link rel="stylesheet" type="text/css" id="mce-u16" crossorigin="anonymous" referrerpolicy="origin" href="https://cdn.tiny.cloud/1/orhttebj9nysf6w4jmz4x9bg4sa0m26m36ymzlew7arsv096/tinymce/8.3.0-113/skins/ui/oxide/skin.min.css"><link rel="stylesheet" type="text/css" id="mce-u17" crossorigin="anonymous" referrerpolicy="origin" href="https://cdn.tiny.cloud/1/orhttebj9nysf6w4jmz4x9bg4sa0m26m36ymzlew7arsv096/tinymce/8.3.0-113/skins/ui/oxide/content.inline.min.css"></head><body style="margin: 0; padding: 0;  font-family: 'Polar', 'Helvetica Neue', Helvetica, Arial, sans-serif; color: #0D0D0B; background-color: #ffffff;" class="gs-rte gs-rte-eb-body gs-edit-mode"><table id="body-container-table" role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#ffffff" style="background-color:#ffffff;">
              <tbody>
                <tr>
                  <td id="body-container-td" style="padding-left:0px;padding-right:0px;padding-top:0px;padding-bottom:0px;">
        <table align="center" id="email-container-table" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" bgcolor="#ffffff" style="background-color:#ffffff;">
              <tbody>
                <tr>
                  <td id="email-container-td" valign="top" style="padding-left:0px; padding-right: 0px; padding-top: 0px;padding-bottom: 0px;font-family: Arial, sans-serif;color:  rgb(0, 0, 0);">
            <!-- Email Body : BEGIN -->
              <div id="email-body-main">
  <!-- Wrapper table to centre content and provide full width background -->
  <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" id="ianzi">
    <tbody><tr>
      <td align="center">
        <!-- Main container (max 600px wide) -->
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" id="ikkcf" class="no-padding-mobile">
          <!-- Logo row -->
          <tbody><tr>
            <td id="ib2zk" class="img-less-padding">
              <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                <tbody><tr>
                  <td align="left" id="i01vw">
                    <table role="presentation" cellpadding="0" cellspacing="0" border="0">
                      <tbody><tr>
                        <td><img src="https://recurly.com/img2/navigate/img-recurly-logo-black.png" id="i5n9j"></td>
                      </tr>
                    </tbody></table>
                  </td>
                </tr>
              </tbody></table>
            </td>
          </tr>

          <!-- Hero section with background image and headline -->
          <tr>
            <td id="icfte">
              <div data-text-merge><h1 id="im4f9">
                <span id="io9j8z1" data-token>${embd::gs-oOT939OlZVxoIwb8RUn2Do_P4nJrovWp5}</span></h1><div id="imvup">A quick performance snapshot of your last complete fiscal month in Recurly to help you monitor key performance
                metrics.
              </div></div>
              
            </td>
          </tr>

          <!-- Introduction heading and paragraph -->
          <tr>
            <td id="ird3a">
              <div data-text-merge><div data-text-merge><div data-text-merge><h2 id="i5jj1" style="line-height:1.5;"><span style="font-size:16px;"><span id="i7vyfqa">Hi </span><span id="im9flev" data-token>${embd::gs-oOhn7ZdUE97W5RAoi7xB-oQI8J08wmm8a}</span><span id="i0gk5a7">,</span></span></h2><div id="iin0g" style="line-height:1.5;"><div id="ifq1f7f"><div id="i8g0gng"><div data-text-merge><div style="line-height:1.5;"><div data-text-merge><span style="font-size:16px;"><span>It's July scorecard time! </span></span><span id="i0wxz-2" style="font-size:16px;"><span id="id8gu-2" data-text-merge><span id="iangx-2" data-path-to-node="6,0"><strong>You'll find your most important KPIs below. </strong>To understand how this scorecard works and why there is a two-month lookback, <!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><a contenteditable="false" id="iucqhnk" _ngcontent-ng-c2031058489 target="_blank" externallink _nghost-ng-c3831362998 jslog="197247;track:generic_click,impression,attention;BardVeMetadataKey:[[&quot;r_f168cc2c5d05f7a2&quot;,&quot;c_4adea96ae52cf021&quot;,null,&quot;rc_6737334c0eb4d329&quot;,null,null,&quot;und&quot;,null,1,null,null,1,0]]" href="https://share.synthesia.io/28ddb99c-c1fa-4aab-9641-d875c4842fc5" data-rte-link-token aria-label="watch this video" clicktracking="off" mc:disable-tracking data-rte-link-uuid="gs-6wKfLIf50CXO95cqhlBjFo5rcSQbSpfTX" rel="noopener" class>watch this video</a><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----></span><span id="i3f2s9" data-path-to-node="6,1"><var id="i3hk2fh"></var><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><sup id="i5e08y"><var id="ie3suzz"></var><!----></sup><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----></span><span id="igiwmt" data-path-to-node="6,2">.</span></span></span></div></div></div></div></div></div></div><div data-text-merge><div style="line-height:inherit;"></div><div style="line-height:inherit;"><div data-text-merge><div style="line-height:inherit;"><div data-text-merge style="line-height:inherit;"><strong><span style="font-size:16px;"></span></strong></div></div><div style="line-height:inherit;"></div></div></div></div></div><div data-text-merge style="position:relative;"><div style="line-height:1.5;"><span style="font-size:16px;"><span data-text-merge><span data-path-to-node="6,2">We've also got an important announcement below that you may appreciate, so be sure to scroll. </span></span></span></div></div></div>
              
              
            </td>
          </tr>

          <!-- Spacer between intro and cards -->
          <tr>
            <td id="iph4p"><div id="ibwt4x"><br></div></td>
          </tr>

          <!-- Begin scorecard cards -->
          <!-- Card template: repeat for each KPI -->
          <!-- Subscriber acquisition rate card -->
          <tr>
            <td id="ixqei">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="io247i">
      0         <tbody>
                  <tr>
                    <td id="ixtsk1">
                      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                        <tbody>
                          <tr>
                            <!-- Icon -->
                            <td width="50" valign="top" id="iwapgg">
                              <img src="https://recurly.com/img2/navigate/icon-aquisition-rate.png" width="40" height="40" alt="Acquisition icon" id="iunpv9" class="responsive-img">
                            </td>
      0                     <!-- Text content -->
                            <td valign="top" id="iyjuca">
                              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="ipr9hn">
                                <tbody>
                                  <tr>
                                    <td id="i7uyhi"><div>
                                      Subscriber acquisition rate
                                    </div></td>
                                  </tr>
                                  <tr>
                                    <td id="irhtni"><div>
                                      What percentage of your subscribers are new this month?
                                      Calculation: New subscribers / total subscribers = %
                                    </div></td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <!-- Metric row -->
                  <tr>
                    <td>
                      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                        <tbody>
                          <tr>
                            <td align="center" id="ifwyia" class="stack-column">
                              <div data-text-merge style="position:relative;"><div style="line-height:inherit;"><span id="in8v6j"><span id="igf9wyo" data-token>${embd::gs-whEpbBkP7D2MZxplr1cACpzMTLFZICh4A}</span>%</span></div><div id="ie6abw">June 2026</div></div>
                              
                            </td>
          0                 <td align="center" id="igsovw" class="stack-column">
            0                 <div data-text-merge style="position:relative;"><div style="line-height:inherit;"><span id="iag0h4"><span id="im8uipe" data-token>${embd::gs-Fm7KTIhIP2nOSENAmrmwdORukEl3lJjiP}</span>%</span></div><div id="ip3obr">June 2025</div></div>
                              
                0           </td>
                            <td align="center" id="i9f9je" class="stack-column">
                              <div data-text-merge><div style="line-height:inherit;"><span id="itvfb4"><span id="i2bbt71" data-token>${embd::gs-y-xH-wThAPb-amYQ6ZjCTy7fukZhplNHp}</span>%</span></div><div id="i1juij">Industry benchmark</div></div>
                              
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td id="ihf6zf">
                      <hr id="i9lbc1">
                    </td>
                  </tr>
                  <tr>
                    <td id="ipx3c8"><div data-text-merge id="ihjxq7" style="position:relative;"><div style="line-height:inherit;"><strong>Learn where</strong> to optimize your subscriber growth strategy with a CSM <!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><a contenteditable="false" _ngcontent-ng-c2031058489 target="_blank" externallink _nghost-ng-c3831362998 jslog="197247;track:generic_click,impression,attention;BardVeMetadataKey:[[&quot;r_028b2deafab4a311&quot;,&quot;c_4adea96ae52cf021&quot;,null,&quot;rc_c8706151f99debcf&quot;,null,null,&quot;und&quot;,null,1,null,null,1,0]]" href="https://navigate.recurly.com/global-office-hours/" id="iwb1i7h" data-rte-link-token data-rte-link-uuid="gs-AsRA77G3ytk7Du29e4Mg9-Wv3E_BHwghX" rel="noopener" class>here</a><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->.</div></div></td>
                  </tr>
                  <tr>
                    <td id="ivsblx"><div data-text-merge id="ip6kun" style="position:relative;"><div style="line-height:inherit;">How do you stack up?  <a contenteditable="false" href="http://vix.recurly.com/welcome" id="icpfwe" data-rte-link-token data-rte-link-uuid="gs-ipyf4Ja1JaTnobmiqHazKhDepKo1rQfDR" target="_blank" aria-label="View your insights" rel="noopener" class>View your insights</a><span id="igj4jf">→</span></div></div>
                      
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>

          <!-- Signup decline rate card -->
          <tr>
            <td id="i6r9sv">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="io6v8v">
                <tbody><tr>
                  <td id="ixl69p">
                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
      0               <tbody><tr>
                        <!-- Icon -->
                        <td width="50" valign="top" id="ih12rh">
                          <img src="https://recurly.com/img2/navigate/icon-sign-up.png" width="40" height="40" alt="Decline icon" id="i7jv9g" class="responsive-img">
                        </td>
                        <!-- Text content -->
                        <td valign="top" id="ibwv6h">
                          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="ih8ile">
                            <tbody><tr>
                              <td id="i12jvq"><div id="ivukvu">
                                Signup decline rate
                              </div></td>
                            </tr>
                            <tr>
                              <td id="ixb0vx"><div>
                                What percentage of initial sign up attempts were declines?
                                Calculation: Failed attempts / total sign ups = %
                              </div></td>
                            </tr>
                            
                          </tbody></table>
        0               </td>
                      </tr>
                      
                    </tbody></table>
                  </td>
                </tr>
                <!-- Metric row -->
                <tr>
                  <td>
                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="i9yvm1">
                      <tbody>
                        <tr>
                          <td align="center" id="io48c2" class="stack-column">
                            <div data-text-merge style="position:relative;"><div style="line-height:inherit;"><span id="i6msgx"><span id="ivtvx3d" data-token>${embd::gs-1dX0tl16Hs7ehac5db_UP-nD__sQ3FGe_}</span>%</span></div><div id="icv6le">June 2026</div></div>
                            
                          </td>
      0                   <td align="center" id="ipjfa2" class="stack-column">
                            <div data-text-merge style="position:relative;"><div style="line-height:inherit;"><span id="i3skaj"><span id="il2zixs" data-token>${embd::gs---Mn8XtW6bkDrEpGVUxArTW22icFP8W4Y}</span>%</span></div><div id="inuh0i">June 2025</div></div>
                            
          0               </td>
          0               <td align="center" id="ixe82c" class="stack-column">
                            <div data-text-merge><span id="ifoe3g"><span id="i1g4y1m" data-token>${embd::gs-Itp2HQ-ssoBX10yrzcADRJWsqYDRV64Lq}</span>%</span><div id="iwlx05">
                              Industry benchmark
                            </div></div>
                            
                  0       </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td id="is7yyi">
                    <hr id="ih2tx3">
                  </td>
                </tr>
                <tr>
                  <td id="iep70n"><div data-text-merge id="izzms6" style="position:relative;"><div style="line-height:inherit;"><span data-path-to-node="5,1,2,0"><strong>Troubleshoot checkout gateway</strong> failures one-to-one with our success team <!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><a contenteditable="false" _ngcontent-ng-c2031058489 target="_blank" externallink _nghost-ng-c3831362998 jslog="197247;track:generic_click,impression,attention;BardVeMetadataKey:[[&quot;r_028b2deafab4a311&quot;,&quot;c_4adea96ae52cf021&quot;,null,&quot;rc_c8706151f99debcf&quot;,null,null,&quot;und&quot;,null,1,null,null,1,0]]" href="https://navigate.recurly.com/global-office-hours/" id="inuuzam" data-rte-link-token data-rte-link-uuid="gs-Imp21v5Lxb5Z5mtH_ZqrHUV_oUI4z6Z-i" aria-label="here" rel="noopener" class>here</a>.</span></div></div></td>
                </tr>
                <tr>
                  <td id="iozftw"><div data-text-merge id="i67k09" style="position:relative;"><div style="line-height:inherit;">How do you stack up? <a contenteditable="false" href="http://vix.recurly.com/welcome" id="ii5yvg" data-rte-link-token data-rte-link-uuid="gs-FW9zWleJSPBVT6thj6thzL1p_MrScPCmc" target="_blank" aria-label="View your insights" rel="noopener" class>View your insights</a><span id="i51s64">→</span></div></div>
                    
                  </td>
                </tr>
                
              </tbody></table>
            </td>
          </tr>

          <!-- Involuntary churn rate card -->
          <tr>
            <td id="iqapat">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="iq6npg">
                <tbody><tr>
                  <td id="i9q4rf">
                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
      0               <tbody><tr>
                        <!-- Icon -->
                        <td width="50" valign="top" id="iojz06">
                          <img src="https://recurly.com/img2/navigate/icon-involuntary-churn.png" width="40" height="40" alt="Revenue recovery icon" id="i3godu" class="responsive-img">
                        </td>
                        <!-- Text content -->
                        <td valign="top" id="iomi6i">
                          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="itam5u">
                            <tbody><tr>
                              <td id="it8ga3"><div id="i8xzt9">
                                Involuntary churn rate
                              </div></td>
                            </tr>
      0                     <tr>
                              <td id="inu4kk"><div>
                                What percentage of subscribers were lost due to payment failure? Calculation: Churned subscribers (involuntary) / Total
                                subscribers = %
                              </div></td>
                            </tr>
                            
          0               </tbody></table>
                        </td>
                      </tr>
                      
                    </tbody></table>
                  </td>
                </tr>
  0             <!-- Metric row -->
                <tr>
                  <td>
                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                      <tbody>
                        <tr>
                          <td align="center" id="ihi38a" class="stack-column">
                            <div data-text-merge style="position:relative;"><div style="line-height:inherit;"><span id="iznod5"><span id="iq3mivm" data-token>${embd::gs-OFxUgUMxF3Je0WjLYjJQnsI6u8GP9ijn-}</span>%</span></div><div id="ik04c1">June 2026</div></div>
                            
                          </td>
      0                   <td align="center" id="i78t3b" class="stack-column">
                            <div data-text-merge style="position:relative;"><div style="line-height:inherit;"><span id="iszkny"><span id="itb3ze2" data-token>${embd::gs-mljbbJAsX3JVd648ggfXZXH5p1kehlmCr}</span>%</span></div><div id="itqoe8">June 2025</div></div>
                            
          0               </td>
          0     0         <td align="center" id="izgz44" class="stack-column">
          0     0           <div data-text-merge><span id="iafxsf"><span id="i6f2m1h" data-token>${embd::gs-3romvQ8y16OaoJRuxyWhciQ62tGMyr11y}</span>%</span><div id="ipknnk">
          0     0             Industry benchmark
          0     0           </div></div>
          0     0           
          0     0         </td>
          0     0       </tr>
          0     0     </tbody>
          0     0   </table>
          0     0   </td>
          0     </tr>
          0     <tr>
          0       <td id="i4d5q6">
          0         <hr id="i2b70o">
          0       </td>
          0     </tr>
          0     <tr>
          0       <td id="i1d93m"><div data-text-merge id="irvzsk" style="position:relative;"><div style="line-height:inherit;"><strong>Need help </strong>creating an optimal Dunning sequence for your plans? Chat with a CSM <!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><a contenteditable="false" _ngcontent-ng-c2031058489 target="_blank" externallink _nghost-ng-c3831362998 jslog="197247;track:generic_click,impression,attention;BardVeMetadataKey:[[&quot;r_028b2deafab4a311&quot;,&quot;c_4adea96ae52cf021&quot;,null,&quot;rc_c8706151f99debcf&quot;,null,null,&quot;und&quot;,null,1,null,null,1,0]]" href="https://navigate.recurly.com/global-office-hours/" id="ii1tigj" data-rte-link-token data-rte-link-uuid="gs-01-H9xtohXNniSnSNQLCZyTHLrptM1e1L" rel="noopener" class>here</a><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->.</div></div></td>
          0     </tr>
          0     <tr>
          0       <td id="iqmq4z"><div data-text-merge id="iennab" style="position:relative;"><div style="line-height:inherit;">How do you stack up?  <a contenteditable="false" href="http://vix.recurly.com/welcome" id="ianmmc" data-rte-link-token data-rte-link-uuid="gs-tjoDL2KGmkrS_RumAyKEQPmroOlmJka3E" target="_blank" aria-label="View your insights" rel="noopener" class>View your insights</a><span id="isdeji">→</span></div></div>
          0         
          0       </td>
          0     </tr>
          0     
      0       </tbody></table>
            </td>
          </tr>

          <!-- Voluntary churn rate card -->
          <tr>
            <td id="i0bs5l">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="i3dkii">
                <tbody><tr>
                  <td id="i1404d">
                    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
      0               <tbody><tr>
                        <!-- Icon -->
                        <td width="50" valign="top" id="ismv8b">
                          <img src="https://recurly.com/img2/navigate/icon-voluntary-churn.png" width="40" height="40" alt="Involuntary churn icon" id="imnwom" class="responsive-img">
      0                 </td>
      0                 <!-- Text content -->
      0                 <td valign="top" id="iviaiw">
      0                   <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="ick106">
      0       0             <tbody><tr>
      0       0               <td id="iasdnz"><div>
      0       0                 Voluntary churn rate
      0       0               </div></td>
      0       0             </tr>
      0       0             <tr>
      0       0               <td id="iw4qzk"><div>
      0       0                 What percentage of your subscribers unsubscribed? Calculation: Churned subscribers (voluntary) / Total subscribers = %
      0       0               </div></td>
      0       0             </tr>
      0       0             
      0       0           </tbody></table>
      0       0         </td>
      0       0       </tr>
      0       
      0     </tbody></table>
      0     </td>
      0   </tr>
  0             <!-- Metric row -->
  0             <tr>
  0               <td>
  0                 <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="i5o4ri">
  0                   <tbody>
  0                     <tr>
  0                       <td align="center" id="ii0pwp" class="stack-column">
  0                         <div data-text-merge style="position:relative;"><div style="line-height:inherit;"><span id="ia4t3k"> <span id="icyeb3l" data-token>${embd::gs-fmOVgFT1GYgMrrjWkcf5vbK2KY-EhCw3a}</span>%</span></div><div id="isyt74">June 2026</div></div>
  0                         
  0                       </td>
  0       0               <td align="center" id="i9ce8x" class="stack-column">
  0       0                 <div data-text-merge style="position:relative;"><div style="line-height:inherit;"><span id="iauu7i"> <span id="irswydi" data-token>${embd::gs-12h4Ftnas4XcAZeVlaGMxncRMJLxQkgJK}</span>%</span></div><div id="iw5cpj">June 2025</div></div>
  0       0                 
  0       0               </td>
  0       0               <td align="center" id="i4uvkl" class="stack-column">
  0       0                 <div data-text-merge><span id="i38j9j">
  0       0                   <span id="iny9c2w" data-token>${embd::gs-N-tozKGFNPpbdhtY4l-UEJwls8DQ7cwUD}</span>%</span><div id="ikpa2f">
  0   0   0                   Industry benchmark
  0   0   0                 </div></div>
  0   0   0                 
  0   0   0               </td>
  0   0   0             </tr>
  0   0   0           </tbody>
  0   0   0         </table>
  0   0   0       </td>
  0   0   0     </tr>
  0   0   0     <tr>
  0   0   0       <td id="ie2z4w">
  0   0   0         <hr id="i4p5z7">
  0   0   0       </td>
  0   0   0     </tr>
  0   0   0     <tr>
  0   0   0       <td id="iafrgv"><div data-text-merge id="i3etjh" style="position:relative;"><div style="line-height:inherit;"><strong>Have a question about your voluntary churn strategy? </strong>Speak with a Recurly Customer Success manager <!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><a contenteditable="false" _ngcontent-ng-c2031058489 target="_blank" externallink _nghost-ng-c3831362998 jslog="197247;track:generic_click,impression,attention;BardVeMetadataKey:[[&quot;r_028b2deafab4a311&quot;,&quot;c_4adea96ae52cf021&quot;,null,&quot;rc_c8706151f99debcf&quot;,null,null,&quot;und&quot;,null,1,null,null,1,0]]" href="https://navigate.recurly.com/global-office-hours/" id="i1zfpig" data-rte-link-token data-rte-link-uuid="gs-9Tg-jtw132VQgZRa4K8gf8DQ0Fwl9Y3AX" rel="noopener" class>here</a><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->.</div></div></td>
  0   0   0     </tr>
  0   0   0     <tr>
  0   0   0       <td id="ipa55h"><div data-text-merge style="position:relative;"><div style="line-height:inherit;">How do you stack up?  <a contenteditable="false" href="http://vix.recurly.com/welcome" id="ij7ji3" data-rte-link-token data-rte-link-uuid="gs-O-WfhO5wVAZZsgMgQoOVi7QI_nc05CL_d" target="_blank" aria-label="View your insights" rel="noopener" class>View your insights</a><span id="iffwf8">→</span></div></div>
  0   0   0         
  0   0   0       </td>
  0   0   0     </tr>
  0   0   0     
  0   0   0   </tbody></table>
  0   0   0   </td>
  0   0   </tr>

          <!-- Renewal invoice paid rate card -->
  0   0   <tr>
  0   0     <td id="id2lnh">
  0   0       <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="i64bqc">
  0   0         <tbody><tr>
  0   0           <td id="if59c3">
  0   0             <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
  0   0               <tbody><tr>
  0   0   0               <!-- Icon -->
  0   0   0               <td width="50" valign="top" id="igsj3l">
  0   0   0   0             <img src="https://recurly.com/img2/navigate/icon-renewal-invoice.png" width="40" height="40" alt="Renewal invoice paid icon" id="iff20k" class="responsive-img">
  0   0   0   0           </td>
  0   0   0   0           <!-- Text content -->
  0   0   0   0           <td valign="top" id="isyqlv">
  0   0   0   0             <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="ibcc6z">
  0   0   0   0               <tbody><tr>
  0   0   0   0                 <td id="i2mrcq"><div>
  0   0   0   0                   Renewal invoice paid rate
  0   0   0   0                 </div></td>
  0   0   0   0               </tr>
  0   0   0   0               <tr>
  0   0   0   0                 <td id="i1cm1z"><div>
  0   0   0   0                   What percentage of your invoices were paid this month? Calculation: Paid invoices / Total invoices = %
  0   0   0   0                 </div></td>
  0   0   0   0               </tr>
  0   0   0   0               
  0   0   0   0             </tbody></table>
  0   0   0   0           </td>
  0   0   0   0         </tr>
  0   0   0   0         
  0   0   0   0       </tbody></table>
  0   0   0         </td>
  0   0   0       </tr>
  0   0   0       <!-- Metric row -->
  0   0   0       <tr>
  0   0   0         <td>
  0   0   0           <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="iu24xa">
  0   0   0   0         <tbody>
  0   0   0   0           <tr>
  0   0   0   0             <td align="center" id="izimlq" class="stack-column">
  0   0   0   0               <div data-text-merge style="position:relative;"><div style="line-height:inherit;"><span id="ildd3r"> <span id="iwkf1hf" data-token>${embd::gs-uD7sLB4qVV0cDBwxUmAWj_YC418osNZJl}</span>%</span></div><div id="i8buaw">June 2026</div></div>
  0   0   0   0               
  0   0   0   0             </td>
  0   0   0   0             <td align="center" id="imthg9" class="stack-column">
  0   0   0   0               <div data-text-merge style="position:relative;"><div style="line-height:inherit;"><span id="ivkhl2"> <span id="icjgbng" data-token>${embd::gs-UaTF590a_GVh52JkFCANOzAWVsVyuhVfY}</span>%</span></div><div id="iemnwf">June 2025</div></div>
  0   0   0   0               
  0   0   0   0             </td>
  0   0   0   0             <td align="center" id="i2xzw1" class="stack-column">
  0   0   0   0               <div data-text-merge><span id="ij7wa3">
  0   0   0   0                 <span id="i29e52o" data-token>${embd::gs-n50hLhQV9KiqR37DAsShKy6ikg0m9ix6r}</span>%</span><div id="ihqsb1">
  0   0   0   0                   Industry benchmark
  0   0   0   0                 </div></div>
  0   0   0   0                 
  0   0   0   0               </td>
  0   0   0   0           </tr>
  0   0   0   0         </tbody>
  0   0   0   0       </table>
  0   0   0   0       </td>
  0   0   0       </tr>
  0   0   0       <tr>
  0   0   0         <td id="ifn7g9">
  0   0   0           <hr id="il8h0g">
  0   0   0         </td>
  0   0   0       </tr>
  0   0   0       <tr>
  0   0   0         <td id="ig3ck2"><div data-text-merge id="i4wi7e" style="position:relative;"><div style="line-height:inherit;"><strong>Learn which</strong> billing configurations maximize automated collection rates from an expert <!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><a contenteditable="false" _ngcontent-ng-c2031058489 target="_blank" externallink _nghost-ng-c3831362998 jslog="197247;track:generic_click,impression,attention;BardVeMetadataKey:[[&quot;r_028b2deafab4a311&quot;,&quot;c_4adea96ae52cf021&quot;,null,&quot;rc_c8706151f99debcf&quot;,null,null,&quot;und&quot;,null,1,null,null,1,0]]" href="https://navigate.recurly.com/global-office-hours/" id="iqmxl1a" data-rte-link-token data-rte-link-uuid="gs-u3WHLES3oFBIAUv-gQ1Fqeojb4q88MDR-" class>here</a>.</div></div></td>
  0   0   0       </tr>
  0   0   0       <tr>
  0   0   0         <td id="i94xd5"><div data-text-merge id="ijb6z4" style="position:relative;"><div style="line-height:inherit;">How do you stack up?  <a contenteditable="false" href="http://vix.recurly.com/welcome" id="idron4" data-rte-link-token data-rte-link-uuid="gs-AWmiDOwh9aaqDBIZ7OQZCsxbPoXCEyWDo" target="_blank" aria-label="View your insights" rel="noopener" class>View your insights</a><span id="izijwt">→</span></div></div>
  0   0   0           
  0   0   0         </td>
  0   0   0       </tr>
  0   0   0       
  0   0   0     </tbody></table>
  0   0   0   </td>
  0   0   </tr>

          <!-- Dunning recovery rate card -->
  0   0   <tr>
  0   0     <td id="it5qrj">
  0   0       <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="i65rn2">
  0   0         <tbody><tr>
  0   0   0           <td id="ixlo8r">
  0   0   0   0         <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
  0   0   0   0           <tbody><tr>
  0   0   0   0             <!-- Icon -->
  0   0   0   0             <td width="50" valign="top" id="iqes8e">
  0   0   0   0               <img src="https://recurly.com/img2/navigate/icon-dunning-recovery.png" width="40" height="40" alt="Dunning recovery rate icon" id="iu37cw" class="responsive-img">
  0   0   0   0             </td>
  0   0   0   0             <!-- Text content -->
  0   0   0   0             <td valign="top" id="iaaxek">
  0   0   0   0               <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" id="i9lef5">
  0   0   0   0                 <tbody><tr>
  0   0   0   0                   <td id="ig0mn5"><div id="i8xzt9">
  0   0   0   0      I'm having a hard time fulfilling your request. Can I help you with something else instead?
`}</HTMLBlock>
