---
title: Resource Library
excerpt: >-
  Explore the Recurly Navigate Resource Library for a centralized hub of
  subscription tools, expert assets, and support links. Access Global Office
  Hours, live webinars, product changelogs, technical FAQs, and Recurly Docs
  configuration guides.
deprecated: false
hidden: false
metadata:
  description: >-
    Explore the Recurly Navigate Resource Library for a centralized hub of
    subscription tools, expert assets, and support links. Access Global Office
    Hours, live webinars, product changelogs, technical FAQs, and Recurly Docs
    configuration guides.
  keywords:
    - Recurly Resource Library
    - subscription billing tools
    - customer success resources
    - Global Office Hours
    - billing product changelog
    - subscription management FAQs
    - Recurly technical documentation
    - customer support hub
  robots: index
---
<HTMLBlock>{`
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700;800;900&display=swap">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* ── HOST-THEME BACKGROUND OVERRIDE ── */
body { background: #ffffff !important; }

/* ── GLOBAL CSS IMMUNITY BLOCK ── */
.rc-guide h1 { border-bottom: none !important; padding-bottom: 0 !important; }
.rc-guide, .rc-guide * { font-family: "Figtree", "Helvetica Neue", Helvetica, arial, sans-serif !important; }
/* FA6 font restore — (0,0,2,0) beats wildcard (0,0,1,0) */
.rc-guide [class^="fa-"],
.rc-guide [class*=" fa-"] { font-family: "Font Awesome 6 Free" !important; }
.rc-guide .fa-brands,
.rc-guide [class*="fa-brands"] { font-family: "Font Awesome 6 Brands" !important; }

html { scroll-behavior: smooth; scroll-padding-top: 80px; }

.rc-guide {
  --yellow:     #FFD706;
  --orange:     #FF8200;
  --offblack:   #0D0D0B;
  --darkgray:   #32312D;
  --gray:       #807D73;
  --lightgray:  #D1CFC4;
  --brightgray: #F2F1EA;
  --offwhite:   #FCFBF7;
  font-family: "Figtree", "Helvetica Neue", Helvetica, arial, sans-serif !important;
  color: #0D0D0B !important;
  background: #ffffff;
}
.rc-guide * { box-sizing: border-box; }

/* ── NAVIGATE MASTER ARMOR ── */
.rm-Markdown.markdown-body .rc-guide a:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a,
.rc-guide a:link,
.rc-guide a:visited,
.rc-guide a:active {
  color: #008CFF !important;
  text-decoration: none !important;
  text-decoration-line: none !important;
  text-decoration-color: transparent !important;
  text-underline-offset: unset !important;
  border-bottom: 0 !important;
}
.rc-guide a:hover {
  color: #0067BE !important;
  text-decoration: underline !important;
  text-decoration-color: #008CFF !important;
  text-underline-offset: 2px !important;
}

/* ── FONT AWESOME ICON HELPERS ── */
.rc-fa-dark  { color: #FFD706 !important; font-size: 1.3rem; display: block; margin-bottom: 10px; }
.rc-fa-light { color: #0D0D0B; font-size: 1.3rem; display: block; margin-bottom: 10px; }
.rc-fa-section { color: #0D0D0B; font-size: 1rem; }

/* ── LAYOUT & TOP NAV ── */
.rc-top-nav { padding: 20px 40px 16px; max-width: 1200px; margin: 0 auto; }
.rm-Markdown.markdown-body .rc-guide a.rc-back-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-back-link { color: #807D73 !important; font-weight: 700; font-size: .9rem; display: inline-flex; align-items: center; gap: 6px; transition: color .2s; border-bottom: 0 !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-back-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-back-link:hover { color: #008CFF !important; text-decoration: none !important; }
.rc-content-wrap { max-width: 1200px; margin: 0 auto; padding: 0 40px; }

/* ── STICKY NAV ── */
details.rc-sticky-nav-wrap {
  position: sticky; top: 0; z-index: 100; background-color: #F2F1EA;
  box-shadow: 0 4px 12px rgba(0,0,0,0.08); margin: 24px 0 48px 0;
  border-radius: 12px; border: 1px solid rgba(0,0,0,0.08); overflow: hidden;
}
details.rc-sticky-nav-wrap > summary {
  list-style: none; display: flex; align-items: center;
  padding: 15px 24px; cursor: pointer; user-select: none;
}
details.rc-sticky-nav-wrap > summary::-webkit-details-marker { display: none; }
details.rc-sticky-nav-wrap > summary::marker { display: none; }
.rc-nav-toggle-label {
  display: inline-flex; align-items: center; gap: 8px;
  font-weight: 800; font-size: .88rem; letter-spacing: 0.6px; text-transform: uppercase;
  color: #0D0D0B;
}
.rc-nav-chevron { font-size: .72rem; color: #0D0D0B; opacity: 0.55; line-height: 1; transition: transform 0.25s ease; }
details.rc-sticky-nav-wrap[open] .rc-nav-chevron { transform: rotate(180deg); }
.rc-nav-drawer { display: grid; grid-template-rows: 0fr; transition: grid-template-rows 0.3s ease; }
details.rc-sticky-nav-wrap[open] .rc-nav-drawer { grid-template-rows: 1fr; }
.rc-nav-drawer-inner { overflow: hidden; border-top: 1px solid rgba(0,0,0,0.10); }
.rc-nav-links { display: flex; flex-wrap: wrap; gap: 6px 4px; padding: 12px 20px 18px; }
/* Nav links — (0,0,8,1) */
.rm-Markdown.markdown-body .rc-guide a.rc-sticky-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-sticky-link {
  color: #0D0D0B !important; font-weight: 700; font-size: .83rem;
  letter-spacing: 0.4px; text-transform: uppercase; padding: 7px 14px;
  border-radius: 7px; transition: all .18s; white-space: nowrap;
  display: inline-flex; align-items: center; gap: 6px; border-bottom: 0 !important;
}
.rm-Markdown.markdown-body .rc-guide a.rc-sticky-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-sticky-link:hover { background: rgba(0,0,0,0.10); color: #0D0D0B !important; text-decoration: none !important; }
.rc-sticky-link img { width: 15px; height: 15px; object-fit: contain; }
.rc-step-badge { display: inline-flex; align-items: center; justify-content: center; width: 20px; height: 20px; border-radius: 50%; background: #0D0D0B; color: #FFD706; font-size: .65rem; font-weight: 800; flex-shrink: 0; line-height: 1; }
.rc-guide a.rc-sticky-link:hover .rc-step-badge { background: #FFD706; color: #0D0D0B; }
.rc-guide a.rc-sticky-link-active { font-weight: 800; }
.rc-guide a.rc-sticky-link-active:hover { background: rgba(0,0,0,0.10); color: #0D0D0B !important; }

/* ── HERO ── */
.rc-hero {
  background: linear-gradient(rgba(13,13,11,0.82), rgba(13,13,11,0.82)),
              url('https://files.readme.io/7a74d62bff1d532ca5adc49ae3d1c7d39a9703386b62fa98835df5c47a5f84b1-Topo_for_Black_Background_2.png') no-repeat center center;
  background-color: var(--offblack); background-size: cover;
  color: #fff; padding: 48px 40px 44px; text-align: center; border-radius: 16px; margin-bottom: 0;
}
.rc-brand-header { display: flex; justify-content: center; margin-bottom: 0; }
.rc-logo-image { height: 28px; display: block; }
.rc-home-title-block { margin-top: 44px; }
.rc-home-title-block h1 { font-size: 2.4rem; font-weight: 800; line-height: 1.15; color: var(--offwhite); margin: 0 0 24px; }
.rc-hero p { font-size: 1rem; opacity: .85 !important; max-width: 640px; margin: 0 auto 32px; color: #D1CFC4 !important; line-height: 1.6; }

/* ── SECTION HEADINGS ── */
.rc-lp-section { margin-bottom: 48px; }
.rc-lp-section h2 { font-size: 1.5rem; font-weight: 800; margin: 0 0 20px; color: var(--offblack); display: flex; align-items: center; gap: 12px; }
.rc-lp-section h2::after { content: ""; flex-grow: 1; height: 1px; background: var(--lightgray); }
.rc-lp-section p { font-size: .95rem; line-height: 1.65; color: var(--darkgray); margin: 0 0 16px; }

/* ── CARD GRID (3 COL) ── */
.rc-card-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 0 0 32px; }
.rc-card-grid-3col { grid-template-columns: 1fr 1fr; }
.rc-feature-card { background: var(--offwhite); border: 1px solid var(--lightgray); border-radius: 12px; padding: 22px; display: flex; flex-direction: column; gap: 8px; transition: all .2s ease; }
/* Home/Neutral Hover State */
.rc-feature-card:hover { border-color: #0D0D0B; box-shadow: 0 4px 16px rgba(13,13,11,0.15); transform: translateY(-2px); } 
.rc-feature-icon { font-size: 1.4rem; line-height: 1; color: var(--offblack); }
.rc-feature-card h4 { font-size: .98rem; font-weight: 800; color: var(--offblack); margin: 0; }
.rc-feature-card p { font-size: .88rem; color: var(--gray); line-height: 1.55; margin: 0; flex-grow: 1; }

/* Feature Card Links */
.rm-Markdown.markdown-body .rc-guide .rc-feature-card a:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide .rc-feature-card a { color: #008CFF !important; font-weight: 600; border-bottom: 0 !important; transition: color .2s; }
.rm-Markdown.markdown-body .rc-guide .rc-feature-card a:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide .rc-feature-card a:hover { color: #0067BE !important; text-decoration: underline !important; text-decoration-color: #008CFF !important; text-underline-offset: 2px !important; }

/* ── FOOTER NAV ── */
.rc-footer-nav { border-top: 1px solid var(--lightgray); padding-top: 40px; margin-top: 48px; padding-bottom: 48px; }
.rc-footer-links { display: flex; flex-direction: column; gap: 16px; }
.rc-footer-section { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 24px; }
.rc-footer-label { font-weight: 800; font-size: .75rem; text-transform: uppercase; letter-spacing: .8px; color: var(--darkgray); background: var(--brightgray); padding: 4px 10px; border-radius: 6px; margin-right: 4px; }
.rc-footer-utility { display: flex; flex-wrap: wrap; gap: 24px; margin-top: 16px; padding-top: 24px; border-top: 1px solid var(--brightgray); }
.rm-Markdown.markdown-body .rc-guide a.rc-footer-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-footer-link {
  color: #807D73 !important; text-decoration: none !important; font-weight: 600; font-size: .88rem;
  transition: color .2s ease; display: inline-flex; align-items: center; gap: 6px; border-bottom: 0 !important;
}
.rm-Markdown.markdown-body .rc-guide a.rc-footer-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-footer-link:hover { color: #008CFF !important; text-decoration: none !important; }
.rc-footer-link img { width: 14px; height: 14px; object-fit: contain; opacity: 0.5; transition: opacity .2s ease; }
.rc-footer-link:hover img { opacity: 1; }

/* ── BREAKPOINTS ── */
@media(max-width:768px){
  .rc-content-wrap { padding: 0 20px; }
  .rc-top-nav { padding: 16px 20px; }
  .rc-hero { padding: 36px 20px 36px; }
  .rc-home-title-block h1 { font-size: 1.8rem; }
  .rc-card-grid, .rc-card-grid.rc-card-grid-3col { grid-template-columns: 1fr; }
}
</style>

<div class="rc-guide">
  <div class="rc-top-nav">
    <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-home" class="rc-back-link">← Back to Home</a>
  </div>

  <div class="rc-content-wrap">
    
    <div class="rc-hero">
      <div class="rc-brand-header">
        <img class="rc-logo-image" src="https://files.readme.io/3a81c518f47c7b9564898238f77cc4fcab026e99e7a7f09817e9815d89e0b297-Logo_for_Black_BG_V1.svg" alt="Recurly">
      </div>
      <div class="rc-home-title-block">
        <h1>Resource library</h1>
        <p>All your essential Recurly links, tools, and support resources. Right where you need them, when you need them.</p>
      </div>
    </div>

    <details class="rc-sticky-nav-wrap">
      <summary>
        <span class="rc-nav-toggle-label">Navigation Menu <i class="fa-solid fa-chevron-up rc-nav-chevron"></i></span>
      </summary>
      <div class="rc-nav-drawer">
        <div class="rc-nav-drawer-inner">
          <div class="rc-nav-links">
            <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-home" class="rc-sticky-link">
              <img src="https://files.readme.io/105d407afb9e682bd60fbc60587b3da1cfb3d09be95148d71529b20fb286aadf-Home_icon_2.png" alt="Home"> Navigate Home
            </a>
            <a href="#essential" class="rc-sticky-link">Essential Navigate resources</a>
            <a href="#recurly" class="rc-sticky-link">Recurly resources</a>
            <a href="#support" class="rc-sticky-link">Support resources</a>
          </div>
        </div>
      </div>
    </details>

    <div class="rc-lp-section" id="essential">
      <h2><i class="fa-solid fa-book-open rc-fa-section"></i> Essential Navigate resources</h2>
      <p>Browse our curated materials to help you build and scale.</p>
      
      <div class="rc-card-grid rc-card-grid-3col">
        <div class="rc-feature-card">
          <div class="rc-feature-icon"><i class="fa-regular fa-flag"></i></div>
          <h4>What is Navigate?</h4>
          <p>Official orientation of Recurly's Customer Success program, built for you.</p>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-intro" target="_blank" rel="noopener noreferrer">Explore program ↗</a>
        </div>
        
        <div class="rc-feature-card">
          <div class="rc-feature-icon"><i class="fa-solid fa-headphones"></i></div>
          <h4>Global Office Hours</h4>
          <p>Connect directly with our Customer Success Managers in small-group sessions built for practical, real-time problem-solving.</p>
          <a href="https://navigate.recurly.com/global-office-hours/" target="_blank" rel="noopener noreferrer">Book session ↗</a>
        </div>

        <div class="rc-feature-card">
          <div class="rc-feature-icon"><i class="fa-solid fa-video"></i></div>
          <h4>Upcoming & on-demand events</h4>
          <p>Browse upcoming Navigate webinars, book a live Customer Success Office Hours session, or view our library of educational on-demand events.</p>
          <a href="https://navigate.recurly.com/event-hub/" target="_blank" rel="noopener noreferrer">View events ↗</a>
        </div>

        <div class="rc-feature-card">
          <div class="rc-feature-icon"><i class="fa-solid fa-lightbulb"></i></div>
          <h4>Submit your Navigate ideas</h4>
          <p>Is there a topic you’d like to explore? A feature you want to better understand? A strategy you’d like help refining? Let us know!</p>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSeA32fji1c0ydgEVo0Ene8_XiJAg-YZvnZ49ThBLgOJPaVaIA/viewform" target="_blank" rel="noopener noreferrer">Submit your ideas ↗</a>
        </div>
      </div>
    </div>

    <div class="rc-lp-section" id="recurly">
      <h2><i class="fa-solid fa-cubes rc-fa-section"></i> Recurly resources</h2>
      <p>Explore tools and articles to optimize your business operations.</p>
      
      <div class="rc-card-grid rc-card-grid-3col">
        <div class="rc-feature-card">
          <div class="rc-feature-icon"><i class="fa-solid fa-book"></i></div>
          <h4>Resource center</h4>
          <p>Curated guides, case studies & benchmarks to help subscription businesses launch, grow, and retain smartly.</p>
          <a href="https://recurly.com/resources/" target="_blank" rel="noopener noreferrer">View assets ↗</a>
        </div>

        <div class="rc-feature-card">
          <div class="rc-feature-icon"><i class="fa-solid fa-triangle-exclamation"></i></div>
          <h4>Status page</h4>
          <p>Enroll for real-time incident reporting and status updates.</p>
          <a href="https://status.recurly.com/" target="_blank" rel="noopener noreferrer">Get updates ↗</a>
        </div>

        <div class="rc-feature-card">
          <div class="rc-feature-icon"><i class="fa-solid fa-code"></i></div>
          <h4>Recurly change log</h4>
          <p>Discover what's new in Recurly Subscriptions. Browse posts by year to see recent launches, enhancements, and improvements.</p>
          <a href="https://docs.recurly.com/recurly-subscriptions/changelog/2026" target="_blank" rel="noopener noreferrer">Get updates ↗</a>
        </div>
        
        <div class="rc-feature-card">
          <div class="rc-feature-icon"><i class="fa-solid fa-list-check"></i></div>
          <h4>Email preferences</h4>
          <p>Subscribe to Newsletters, event updates and product updates.</p>
          <a href="https://go.recurly.com/UnsubscribePage.html?mkt_unsubscribe=1" target="_blank" rel="noopener noreferrer">Select preferences ↗</a>
        </div>
      </div>
    </div>

    <div class="rc-lp-section" id="support">
      <h2><i class="fa-solid fa-headset rc-fa-section"></i> Support resources</h2>
      <p>Connect with our experts and get the direct assistance you need.</p>
      
      <div class="rc-card-grid rc-card-grid-3col">
        <div class="rc-feature-card">
          <div class="rc-feature-icon"><i class="fa-solid fa-globe"></i></div>
          <h4>Visit Recurly Global support</h4>
          <p>View knowledge base or "submit a ticket" to reach out directly to the Recurly Support team with specific technical inquiries.</p>
          <a href="https://support.recurly.com/hc/en-us" target="_blank" rel="noopener noreferrer">Submit ticket ↗</a>
        </div>
        
        <div class="rc-feature-card">
          <div class="rc-feature-icon"><i class="fa-solid fa-envelope"></i></div>
          <h4>Knowledge base</h4>
          <p>Explore how-to articles, FAQs and troubleshooting techniques.</p>
          <a href="https://support.recurly.com/hc/en-us/categories/36701490551956-Recurly-Subscriptions">View FAQs ↗</a>
        </div>

        <div class="rc-feature-card">
          <div class="rc-feature-icon"><i class="fa-regular fa-file-lines"></i></div>
          <h4>Recurly Docs</h4>
          <p>Access our complete documentation for detailed configuration steps and API references.</p>
          <a href="https://docs.recurly.com/" target="_blank" rel="noopener noreferrer">Visit docs ↗</a>
        </div>
      </div>
    </div>

    <div class="rc-footer-nav">
      <div class="rc-footer-links">
        
        <div class="rc-footer-section">
          <span class="rc-footer-label">Resource library</span>
          <a href="#essential" class="rc-footer-link">Essential Navigate resources</a>
          <a href="#recurly" class="rc-footer-link">Recurly resources</a>
          <a href="#support" class="rc-footer-link">Support resources</a>
        </div>

        <div class="rc-footer-utility">
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-home" class="rc-footer-link">
            <img src="https://files.readme.io/105d407afb9e682bd60fbc60587b3da1cfb3d09be95148d71529b20fb286aadf-Home_icon_2.png" alt="Home"> Navigate Home
          </a>
          <a href="mailto:support@recurly.com" class="rc-footer-link">Contact Support</a>
        </div>

      </div>
    </div>

  </div>
</div>
`}</HTMLBlock>

<br />
