---
title: Navigate monthly calendar
excerpt: >-
  Join Recurly's Customer Success Office Hours to master data dashboards,
  leverage churn tools, and optimize your subscription management strategy.
  Register for live, expert-led Navigate sessions and Recurly webinars.
deprecated: false
hidden: false
metadata:
  description: >-
    Join Recurly's Customer Success Office Hours this July to master data
    dashboards, leverage churn tools, and optimize your subscription management
    strategy. Register for live, expert-led Navigate sessions available across
    global time zones, including EMEA.
  keywords:
    - Recurly customer success office hours
    - SaaS subscription management support
    - Recurly Navigate training events
    - subscription data dashboard tutorials
    - Recurly churn management tools
    - EMEA customer success meetings
    - Recurly CSM consultation
    - optimizing recurring revenue strategies.
  robots: index
---
<HTMLBlock>{`
<style>
  @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&display=swap');
</style>

<div style="background-color: #FCFBF7; padding: 40px; font-family: 'Figtree', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #0D0D0B; max-width: 750px; margin: 0 auto; border-radius: 12px; border: 1px solid #D1CFC4;">

  <!-- Header Section -->
  <div style="margin: 0 0 24px 0;">
    <div style="color: #0D0D0B; font-size: 16px; font-weight: 700; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 1px;">September 2026</div>
    <h1 style="color: #0D0D0B; font-size: 40px; font-weight: 700; line-height: 1.1; margin: 0;">Upcoming events calendar</h1>
  </div>

  <p style="font-size: 15px; margin: 0 0 32px 0; line-height: 1.5; color: #32312D;">

    Join our live Customer Success Office Hours, Recurly webinars, and Navigate events below. We're here to answer questions, work through strategy, and drive your success.
  </p>

  <!-- September Calendar Section Header -->
  <div style="font-size: 14px; font-weight: 700; color: #0D0D0B; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <span style="background-color: #0D0D0B; color: #FFFFFF; font-size: 11px; padding: 3px 8px; border-radius: 4px; font-weight: 700;">SEPTEMBER 2026</span> Live Events & Support
  </div>

  <!-- September Chronological Event Stream -->
  <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 36px;">

    <!-- Entry 1: Sep 2 (Office Hours - Christian) -->
    <div style="background-color: #FFFFFF; border: 1px solid #D1CFC4; border-left: 4px solid #5DC32E; border-radius: 8px; padding: 16px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; flex: 1; min-width: 260px;">
        <div style="background-color: #EFFAEA; border: 1px solid #5DC32E; border-radius: 8px; width: 60px; text-align: center; padding: 6px 0; flex-shrink: 0;">
          <div style="font-size: 10px; font-weight: 700; color: #5DC32E; text-transform: uppercase;">SEP</div>
          <div style="font-size: 20px; font-weight: 700; color: #0D0D0B; line-height: 1.1;">02</div>
          <div style="font-size: 10px; font-weight: 600; color: #32312D;">WED</div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px; flex-wrap: wrap;">
            <span style="background-color: #5DC32E; color: #FFFFFF; font-size: 9px; padding: 2px 6px; border-radius: 3px; font-weight: 700; text-transform: uppercase;">Office Hours</span>
            <div style="font-size: 15px; font-weight: 700; color: #0D0D0B;">Christian Oldroyd <span style="font-size: 13px; font-weight: 400; color: #666666;">• EMEA Senior CSM</span></div>
          </div>
          <div style="font-size: 13px; color: #32312D; margin-top: 2px;">Area of expertise: Global Subscriptions & EMEA</div>
          <div style="font-size: 13px; font-weight: 700; color: #5DC32E; margin-top: 2px;">10:30 AM - 11:00 AM BST</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; flex-shrink: 0;">
        <div style="width: 40px; height: 40px; background-color: #FFD706; border-radius: 50%; overflow: hidden; display: flex; justify-content: center; align-items: center;">
          <img src="https://files.readme.io/556f786c283fc2468e4f543ddbf3e24579a692594fc68dbc8ad4f14877ece148-Christian_Oldroyd_Customer_Success_Manager_II_1.png" style="width: 100%; height: 100%; object-fit: cover;" alt="Christian Oldroyd">
        </div>
        <a href="https://recurly.registration.goldcast.io/webinar/a33ba6a5-0d07-4b12-84a7-f367d91bd018" target="_blank" style="background-color: #008CFF; color: #FFFFFF !important; text-decoration: none !important; font-weight: 600; font-size: 13px; padding: 8px 14px; border-radius: 6px; display: inline-block;">Sign up</a>
      </div>
    </div>

    <!-- Entry 2: Sep 4 (Office Hours - Santi) -->
    <div style="background-color: #FFFFFF; border: 1px solid #D1CFC4; border-left: 4px solid #5DC32E; border-radius: 8px; padding: 16px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; flex: 1; min-width: 260px;">
        <div style="background-color: #EFFAEA; border: 1px solid #5DC32E; border-radius: 8px; width: 60px; text-align: center; padding: 6px 0; flex-shrink: 0;">
          <div style="font-size: 10px; font-weight: 700; color: #5DC32E; text-transform: uppercase;">SEP</div>
          <div style="font-size: 20px; font-weight: 700; color: #0D0D0B; line-height: 1.1;">04</div>
          <div style="font-size: 10px; font-weight: 600; color: #32312D;">FRI</div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px; flex-wrap: wrap;">
            <span style="background-color: #5DC32E; color: #FFFFFF; font-size: 9px; padding: 2px 6px; border-radius: 3px; font-weight: 700; text-transform: uppercase;">Office Hours</span>
            <div style="font-size: 15px; font-weight: 700; color: #0D0D0B;">Santi Gomez <span style="font-size: 13px; font-weight: 400; color: #666666;">• CSM</span></div>
          </div>
          <div style="font-size: 13px; color: #32312D; margin-top: 2px;">Area of expertise: Strategy & Expert Guidance</div>
          <div style="font-size: 13px; font-weight: 700; color: #5DC32E; margin-top: 2px;">11:00 AM - 11:30 AM CDT</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; flex-shrink: 0;">
        <div style="width: 40px; height: 40px; background-color: #FFD706; border-radius: 50%; overflow: hidden; display: flex; justify-content: center; align-items: center;">
          <img src="https://files.readme.io/e431ac1dfee2a8602e2f687268fbab451030e009a7f0a459d4eef315f117f0bd-Santi.png" style="width: 100%; height: 100%; object-fit: cover;" alt="Santi Gomez">
        </div>
        <a href="https://recurly.registration.goldcast.io/webinar/7689ebc7-5e83-40a1-96dc-4b8919330496" target="_blank" style="background-color: #008CFF; color: #FFFFFF !important; text-decoration: none !important; font-weight: 600; font-size: 13px; padding: 8px 14px; border-radius: 6px; display: inline-block;">Sign up</a>
      </div>
    </div>

    <!-- Entry 3: Sep 9 (Office Hours - Christian) -->
    <div style="background-color: #FFFFFF; border: 1px solid #D1CFC4; border-left: 4px solid #5DC32E; border-radius: 8px; padding: 16px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; flex: 1; min-width: 260px;">
        <div style="background-color: #EFFAEA; border: 1px solid #5DC32E; border-radius: 8px; width: 60px; text-align: center; padding: 6px 0; flex-shrink: 0;">
          <div style="font-size: 10px; font-weight: 700; color: #5DC32E; text-transform: uppercase;">SEP</div>
          <div style="font-size: 20px; font-weight: 700; color: #0D0D0B; line-height: 1.1;">09</div>
          <div style="font-size: 10px; font-weight: 600; color: #32312D;">WED</div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px; flex-wrap: wrap;">
            <span style="background-color: #5DC32E; color: #FFFFFF; font-size: 9px; padding: 2px 6px; border-radius: 3px; font-weight: 700; text-transform: uppercase;">Office Hours</span>
            <div style="font-size: 15px; font-weight: 700; color: #0D0D0B;">Christian Oldroyd <span style="font-size: 13px; font-weight: 400; color: #666666;">• EMEA Senior CSM</span></div>
          </div>
          <div style="font-size: 13px; color: #32312D; margin-top: 2px;">Area of expertise: Global Subscriptions & EMEA</div>
          <div style="font-size: 13px; font-weight: 700; color: #5DC32E; margin-top: 2px;">10:30 AM - 11:00 AM BST</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; flex-shrink: 0;">
        <div style="width: 40px; height: 40px; background-color: #FFD706; border-radius: 50%; overflow: hidden; display: flex; justify-content: center; align-items: center;">
          <img src="https://files.readme.io/556f786c283fc2468e4f543ddbf3e24579a692594fc68dbc8ad4f14877ece148-Christian_Oldroyd_Customer_Success_Manager_II_1.png" style="width: 100%; height: 100%; object-fit: cover;" alt="Christian Oldroyd">
        </div>
        <a href="https://recurly.registration.goldcast.io/webinar/96b4cd79-c883-4b89-8ad1-895456db410b" target="_blank" style="background-color: #008CFF; color: #FFFFFF !important; text-decoration: none !important; font-weight: 600; font-size: 13px; padding: 8px 14px; border-radius: 6px; display: inline-block;">Sign up</a>
      </div>
    </div>

    <!-- Entry 4: Sep 9 (Office Hours - Patrick) -->
    <div style="background-color: #FFFFFF; border: 1px solid #D1CFC4; border-left: 4px solid #5DC32E; border-radius: 8px; padding: 16px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; flex: 1; min-width: 260px;">
        <div style="background-color: #EFFAEA; border: 1px solid #5DC32E; border-radius: 8px; width: 60px; text-align: center; padding: 6px 0; flex-shrink: 0;">
          <div style="font-size: 10px; font-weight: 700; color: #5DC32E; text-transform: uppercase;">SEP</div>
          <div style="font-size: 20px; font-weight: 700; color: #0D0D0B; line-height: 1.1;">09</div>
          <div style="font-size: 10px; font-weight: 600; color: #32312D;">WED</div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px; flex-wrap: wrap;">
            <span style="background-color: #5DC32E; color: #FFFFFF; font-size: 9px; padding: 2px 6px; border-radius: 3px; font-weight: 700; text-transform: uppercase;">Office Hours</span>
            <div style="font-size: 15px; font-weight: 700; color: #0D0D0B;">Patrick Rizzo <span style="font-size: 13px; font-weight: 400; color: #666666;">• Senior CSM</span></div>
          </div>
          <div style="font-size: 13px; color: #32312D; margin-top: 2px;">Area of expertise: Recurly Data Dashboards</div>
          <div style="font-size: 13px; font-weight: 700; color: #5DC32E; margin-top: 2px;">3:00 PM - 3:30 PM CDT</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; flex-shrink: 0;">
        <div style="width: 40px; height: 40px; background-color: #FFD706; border-radius: 50%; overflow: hidden; display: flex; justify-content: center; align-items: center;">
          <img src="https://files.readme.io/5e1a49513c3d043f66594df4828ece696bc096723cbcfcf6338ef772d432cb42-Patrick_Rizzo_Strategic_CSM__Recurly_1.png" style="width: 100%; height: 100%; object-fit: cover;" alt="Patrick Rizzo">
        </div>
        <a href="https://recurly.registration.goldcast.io/webinar/fdb10615-d56b-4993-a08d-16427b9dec6c" target="_blank" style="background-color: #008CFF; color: #FFFFFF !important; text-decoration: none !important; font-weight: 600; font-size: 13px; padding: 8px 14px; border-radius: 6px; display: inline-block;">Sign up</a>
      </div>
    </div>

    <!-- Entry 5: Sep 10 (Navigate Lunch & Learn) -->
    <div style="background-color: #FFF8F0; border: 1px solid #FF9900; border-radius: 12px; padding: 16px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; flex: 1; min-width: 260px;">
        <div style="background-color: #FFFFFF; border: 1px solid #FF9900; border-radius: 8px; width: 60px; text-align: center; padding: 6px 0; flex-shrink: 0;">
          <div style="font-size: 10px; font-weight: 700; color: #FF9900; text-transform: uppercase;">SEP</div>
          <div style="font-size: 20px; font-weight: 700; color: #0D0D0B; line-height: 1.1;">10</div>
          <div style="font-size: 10px; font-weight: 600; color: #32312D;">THU</div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px; flex-wrap: wrap;">
            <span style="background-color: #FF9900; color: #FFFFFF; font-size: 11px; padding: 3px 8px; border-radius: 4px; font-weight: 700;">NAVIGATE LUNCH + LEARN</span>
            <div style="font-size: 15px; font-weight: 700; color: #0D0D0B;">Get to know Recurly's agentic AI: Built for subscriptions</div>
          </div>
          <div style="font-size: 13px; color: #32312D; margin-top: 2px;">Discover how Recurly's agentic AI seamlessly automates and scales your subscription workflows.</div>
          <div style="font-size: 13px; font-weight: 700; color: #FF9900; margin-top: 2px;">1:00 PM - 2:00 PM CDT</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; flex-shrink: 0;">
        <a href="https://navigate.recurly.com/compass-assistant/" target="_blank" style="background-color: #008CFF; color: #FFFFFF !important; text-decoration: none !important; font-weight: 600; font-size: 13px; padding: 8px 14px; border-radius: 6px; display: inline-block;">Register</a>
      </div>
    </div>

    <!-- Entry 6: Sep 14 (Office Hours - Julia) -->
    <div style="background-color: #FFFFFF; border: 1px solid #D1CFC4; border-left: 4px solid #5DC32E; border-radius: 8px; padding: 16px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; flex: 1; min-width: 260px;">
        <div style="background-color: #EFFAEA; border: 1px solid #5DC32E; border-radius: 8px; width: 60px; text-align: center; padding: 6px 0; flex-shrink: 0;">
          <div style="font-size: 10px; font-weight: 700; color: #5DC32E; text-transform: uppercase;">SEP</div>
          <div style="font-size: 20px; font-weight: 700; color: #0D0D0B; line-height: 1.1;">14</div>
          <div style="font-size: 10px; font-weight: 600; color: #32312D;">MON</div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px; flex-wrap: wrap;">
            <span style="background-color: #5DC32E; color: #FFFFFF; font-size: 9px; padding: 2px 6px; border-radius: 3px; font-weight: 700; text-transform: uppercase;">Office Hours</span>
            <div style="font-size: 15px; font-weight: 700; color: #0D0D0B;">Julia Lackner <span style="font-size: 13px; font-weight: 400; color: #666666;">• CSM</span></div>
          </div>
          <div style="font-size: 13px; color: #32312D; margin-top: 2px;">Area of expertise: Recurly Churn Tools</div>
          <div style="font-size: 13px; font-weight: 700; color: #5DC32E; margin-top: 2px;">12:30 PM - 1:00 PM CDT</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; flex-shrink: 0;">
        <div style="width: 40px; height: 40px; background-color: #FFD706; border-radius: 50%; overflow: hidden; display: flex; justify-content: center; align-items: center;">
          <img src="https://files.readme.io/076d29f534bdfb425daa1ec188ee5fef0e3d1c5f04cae94571b61f758f51f8c4-Julia-Lackner.png" style="width: 100%; height: 100%; object-fit: cover;" alt="Julia Lackner">
        </div>
        <a href="https://recurly.registration.goldcast.io/webinar/376347a9-cc39-4099-a4fb-2dd8eba29c6f" target="_blank" style="background-color: #008CFF; color: #FFFFFF !important; text-decoration: none !important; font-weight: 600; font-size: 13px; padding: 8px 14px; border-radius: 6px; display: inline-block;">Sign up</a>
      </div>
    </div>

    <!-- Entry 7: Sep 16 (Office Hours - Christian) -->
    <div style="background-color: #FFFFFF; border: 1px solid #D1CFC4; border-left: 4px solid #5DC32E; border-radius: 8px; padding: 16px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; flex: 1; min-width: 260px;">
        <div style="background-color: #EFFAEA; border: 1px solid #5DC32E; border-radius: 8px; width: 60px; text-align: center; padding: 6px 0; flex-shrink: 0;">
          <div style="font-size: 10px; font-weight: 700; color: #5DC32E; text-transform: uppercase;">SEP</div>
          <div style="font-size: 20px; font-weight: 700; color: #0D0D0B; line-height: 1.1;">16</div>
          <div style="font-size: 10px; font-weight: 600; color: #32312D;">WED</div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px; flex-wrap: wrap;">
            <span style="background-color: #5DC32E; color: #FFFFFF; font-size: 9px; padding: 2px 6px; border-radius: 3px; font-weight: 700; text-transform: uppercase;">Office Hours</span>
            <div style="font-size: 15px; font-weight: 700; color: #0D0D0B;">Christian Oldroyd <span style="font-size: 13px; font-weight: 400; color: #666666;">• EMEA Senior CSM</span></div>
          </div>
          <div style="font-size: 13px; color: #32312D; margin-top: 2px;">Area of expertise: Global Subscriptions & EMEA</div>
          <div style="font-size: 13px; font-weight: 700; color: #5DC32E; margin-top: 2px;">10:30 AM - 11:00 AM BST</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; flex-shrink: 0;">
        <div style="width: 40px; height: 40px; background-color: #FFD706; border-radius: 50%; overflow: hidden; display: flex; justify-content: center; align-items: center;">
          <img src="https://files.readme.io/556f786c283fc2468e4f543ddbf3e24579a692594fc68dbc8ad4f14877ece148-Christian_Oldroyd_Customer_Success_Manager_II_1.png" style="width: 100%; height: 100%; object-fit: cover;" alt="Christian Oldroyd">
        </div>
        <a href="https://recurly.registration.goldcast.io/webinar/62dcf450-1553-4b0c-a900-baeb0b9b91a2" target="_blank" style="background-color: #008CFF; color: #FFFFFF !important; text-decoration: none !important; font-weight: 600; font-size: 13px; padding: 8px 14px; border-radius: 6px; display: inline-block;">Sign up</a>
      </div>
    </div>

    <!-- Entry 8: Sep 23 (Office Hours - Christian) -->
    <div style="background-color: #FFFFFF; border: 1px solid #D1CFC4; border-left: 4px solid #5DC32E; border-radius: 8px; padding: 16px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; flex: 1; min-width: 260px;">
        <div style="background-color: #EFFAEA; border: 1px solid #5DC32E; border-radius: 8px; width: 60px; text-align: center; padding: 6px 0; flex-shrink: 0;">
          <div style="font-size: 10px; font-weight: 700; color: #5DC32E; text-transform: uppercase;">SEP</div>
          <div style="font-size: 20px; font-weight: 700; color: #0D0D0B; line-height: 1.1;">23</div>
          <div style="font-size: 10px; font-weight: 600; color: #32312D;">WED</div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px; flex-wrap: wrap;">
            <span style="background-color: #5DC32E; color: #FFFFFF; font-size: 9px; padding: 2px 6px; border-radius: 3px; font-weight: 700; text-transform: uppercase;">Office Hours</span>
            <div style="font-size: 15px; font-weight: 700; color: #0D0D0B;">Christian Oldroyd <span style="font-size: 13px; font-weight: 400; color: #666666;">• EMEA Senior CSM</span></div>
          </div>
          <div style="font-size: 13px; color: #32312D; margin-top: 2px;">Area of expertise: Global Subscriptions & EMEA</div>
          <div style="font-size: 13px; font-weight: 700; color: #5DC32E; margin-top: 2px;">10:30 AM - 11:00 AM BST</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; flex-shrink: 0;">
        <div style="width: 40px; height: 40px; background-color: #FFD706; border-radius: 50%; overflow: hidden; display: flex; justify-content: center; align-items: center;">
          <img src="https://files.readme.io/556f786c283fc2468e4f543ddbf3e24579a692594fc68dbc8ad4f14877ece148-Christian_Oldroyd_Customer_Success_Manager_II_1.png" style="width: 100%; height: 100%; object-fit: cover;" alt="Christian Oldroyd">
        </div>
        <a href="https://recurly.registration.goldcast.io/webinar/a9d5c6b6-8556-4968-95d6-b40bd1f26cb1" target="_blank" style="background-color: #008CFF; color: #FFFFFF !important; text-decoration: none !important; font-weight: 600; font-size: 13px; padding: 8px 14px; border-radius: 6px; display: inline-block;">Sign up</a>
      </div>
    </div>

    <!-- Entry 9: Sep 23 (Office Hours - Patrick) -->
    <div style="background-color: #FFFFFF; border: 1px solid #D1CFC4; border-left: 4px solid #5DC32E; border-radius: 8px; padding: 16px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; flex: 1; min-width: 260px;">
        <div style="background-color: #EFFAEA; border: 1px solid #5DC32E; border-radius: 8px; width: 60px; text-align: center; padding: 6px 0; flex-shrink: 0;">
          <div style="font-size: 10px; font-weight: 700; color: #5DC32E; text-transform: uppercase;">SEP</div>
          <div style="font-size: 20px; font-weight: 700; color: #0D0D0B; line-height: 1.1;">23</div>
          <div style="font-size: 10px; font-weight: 600; color: #32312D;">WED</div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px; flex-wrap: wrap;">
            <span style="background-color: #5DC32E; color: #FFFFFF; font-size: 9px; padding: 2px 6px; border-radius: 3px; font-weight: 700; text-transform: uppercase;">Office Hours</span>
            <div style="font-size: 15px; font-weight: 700; color: #0D0D0B;">Patrick Rizzo <span style="font-size: 13px; font-weight: 400; color: #666666;">• Senior CSM</span></div>
          </div>
          <div style="font-size: 13px; color: #32312D; margin-top: 2px;">Area of expertise: Recurly Data Dashboards</div>
          <div style="font-size: 13px; font-weight: 700; color: #5DC32E; margin-top: 2px;">3:00 PM - 3:30 PM CDT</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; flex-shrink: 0;">
        <div style="width: 40px; height: 40px; background-color: #FFD706; border-radius: 50%; overflow: hidden; display: flex; justify-content: center; align-items: center;">
          <img src="https://files.readme.io/5e1a49513c3d043f66594df4828ece696bc096723cbcfcf6338ef772d432cb42-Patrick_Rizzo_Strategic_CSM__Recurly_1.png" style="width: 100%; height: 100%; object-fit: cover;" alt="Patrick Rizzo">
        </div>
        <a href="https://recurly.registration.goldcast.io/webinar/d2b38dd1-b05a-479e-9b68-a91becc49068" target="_blank" style="background-color: #008CFF; color: #FFFFFF !important; text-decoration: none !important; font-weight: 600; font-size: 13px; padding: 8px 14px; border-radius: 6px; display: inline-block;">Sign up</a>
      </div>
    </div>

    <!-- Entry 10: Sep 25 (Office Hours - Santi) -->
    <div style="background-color: #FFFFFF; border: 1px solid #D1CFC4; border-left: 4px solid #5DC32E; border-radius: 8px; padding: 16px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; flex: 1; min-width: 260px;">
        <div style="background-color: #EFFAEA; border: 1px solid #5DC32E; border-radius: 8px; width: 60px; text-align: center; padding: 6px 0; flex-shrink: 0;">
          <div style="font-size: 10px; font-weight: 700; color: #5DC32E; text-transform: uppercase;">SEP</div>
          <div style="font-size: 20px; font-weight: 700; color: #0D0D0B; line-height: 1.1;">25</div>
          <div style="font-size: 10px; font-weight: 600; color: #32312D;">FRI</div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px; flex-wrap: wrap;">
            <span style="background-color: #5DC32E; color: #FFFFFF; font-size: 9px; padding: 2px 6px; border-radius: 3px; font-weight: 700; text-transform: uppercase;">Office Hours</span>
            <div style="font-size: 15px; font-weight: 700; color: #0D0D0B;">Santi Gomez <span style="font-size: 13px; font-weight: 400; color: #666666;">• CSM</span></div>
          </div>
          <div style="font-size: 13px; color: #32312D; margin-top: 2px;">Area of expertise: Strategy & Expert Guidance</div>
          <div style="font-size: 13px; font-weight: 700; color: #5DC32E; margin-top: 2px;">11:00 AM - 11:30 AM CDT</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; flex-shrink: 0;">
        <div style="width: 40px; height: 40px; background-color: #FFD706; border-radius: 50%; overflow: hidden; display: flex; justify-content: center; align-items: center;">
          <img src="https://files.readme.io/e431ac1dfee2a8602e2f687268fbab451030e009a7f0a459d4eef315f117f0bd-Santi.png" style="width: 100%; height: 100%; object-fit: cover;" alt="Santi Gomez">
        </div>
        <a href="https://recurly.registration.goldcast.io/webinar/906be6bd-f018-4d3b-80ec-10479dbe27b7" target="_blank" style="background-color: #008CFF; color: #FFFFFF !important; text-decoration: none !important; font-weight: 600; font-size: 13px; padding: 8px 14px; border-radius: 6px; display: inline-block;">Sign up</a>
      </div>
    </div>

    <!-- Entry 11: Sep 30 (Office Hours - Christian) -->
    <div style="background-color: #FFFFFF; border: 1px solid #D1CFC4; border-left: 4px solid #5DC32E; border-radius: 8px; padding: 16px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 16px; flex: 1; min-width: 260px;">
        <div style="background-color: #EFFAEA; border: 1px solid #5DC32E; border-radius: 8px; width: 60px; text-align: center; padding: 6px 0; flex-shrink: 0;">
          <div style="font-size: 10px; font-weight: 700; color: #5DC32E; text-transform: uppercase;">SEP</div>
          <div style="font-size: 20px; font-weight: 700; color: #0D0D0B; line-height: 1.1;">30</div>
          <div style="font-size: 10px; font-weight: 600; color: #32312D;">WED</div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px; flex-wrap: wrap;">
            <span style="background-color: #5DC32E; color: #FFFFFF; font-size: 9px; padding: 2px 6px; border-radius: 3px; font-weight: 700; text-transform: uppercase;">Office Hours</span>
            <div style="font-size: 15px; font-weight: 700; color: #0D0D0B;">Christian Oldroyd <span style="font-size: 13px; font-weight: 400; color: #666666;">• EMEA Senior CSM</span></div>
          </div>
          <div style="font-size: 13px; color: #32312D; margin-top: 2px;">Area of expertise: Global Subscriptions & EMEA</div>
          <div style="font-size: 13px; font-weight: 700; color: #5DC32E; margin-top: 2px;">10:30 AM - 11:00 AM BST</div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; flex-shrink: 0;">
        <div style="width: 40px; height: 40px; background-color: #FFD706; border-radius: 50%; overflow: hidden; display: flex; justify-content: center; align-items: center;">
          <img src="https://files.readme.io/556f786c283fc2468e4f543ddbf3e24579a692594fc68dbc8ad4f14877ece148-Christian_Oldroyd_Customer_Success_Manager_II_1.png" style="width: 100%; height: 100%; object-fit: cover;" alt="Christian Oldroyd">
        </div>
        <a href="https://recurly.registration.goldcast.io/webinar/e7bc5828-a963-48e1-9687-1d5b2ba2d0dd" target="_blank" style="background-color: #008CFF; color: #FFFFFF !important; text-decoration: none !important; font-weight: 600; font-size: 13px; padding: 8px 14px; border-radius: 6px; display: inline-block;">Sign up</a>
      </div>
    </div>

  </div>

  <!-- Footer Section -->
  <p style="margin: 0 0 8px 0; font-size: 14px; line-height: 1.5; color: #32312D;">
    <strong style="font-weight: 700; color: #0D0D0B;">This calendar is updated monthly.</strong> If you have a dedicated CSM or are subscribed to Navigate, you'll receive an updated calendar each month. Feel free to bookmark this page and check in on your own time!
  </p>
  <p style="margin: 16px 0 0 0; font-size: 14px; color: #0D0D0B;">
    <strong>Happy Navigating,</strong><br>
    Recurly Customer Success
  </p>

</div>
`}</HTMLBlock>
