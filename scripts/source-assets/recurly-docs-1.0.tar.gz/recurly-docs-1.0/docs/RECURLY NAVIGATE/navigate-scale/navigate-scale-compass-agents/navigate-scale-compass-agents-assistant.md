---
title: 'Compass agents & skills: Compass Assistant'
excerpt: >-
  Discover how the Recurly Compass Assistant unifies agentic AI skills into a
  single conversational chat, enabling you to build plans, write code, run
  exports, and optimize dunning using plain language.
deprecated: false
hidden: false
link:
  new_tab: false
metadata:
  description: >-
    Discover how the Recurly Compass Assistant unifies agentic AI skills into a
    single conversational chat, enabling you to build plans, write code, run
    exports, and optimize dunning using plain language.
  keywords:
    - >-
      The target focus terms for search visibility include recurly compass
      assistant
    - agentic ai chat widget
    - natural language subscription management
    - automated dunning prompt
    - direct plan add-on creation
    - persistent ai chat history
    - in-app ai advisor.
  robots: index
---
<HTMLBlock>{`
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700;800;900&display=swap">

<style>
/* ── HOST-THEME BACKGROUND OVERRIDE — must be first ── */
body { background: #ffffff !important; }

/* ── GLOBAL CSS IMMUNITY BLOCK ── */
.rc-guide h1 { border-bottom: none !important; padding-bottom: 0 !important; }
.rc-guide, .rc-guide * { font-family: "Figtree", "Helvetica Neue", Helvetica, arial, sans-serif !important; }
.rc-guide [class^="fa-"],
.rc-guide [class*=" fa-"] { font-family: "Font Awesome 6 Free" !important; }
.rc-guide .fa-brands,
.rc-guide [class*="fa-brands"] { font-family: "Font Awesome 6 Brands" !important; }

/* ── NAVIGATE MASTER ARMOR — (0,0,7,1) beats global section 1.1 rule (0,0,6,2) ── */
.rm-Markdown.markdown-body .rc-guide a:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a,
.rc-guide a:link,
.rc-guide a:visited,
.rc-guide a:active {
  color: #008CFF !important;
  text-decoration: none !important;
  text-decoration-line: none !important;
  text-decoration-color: transparent !important;
  text-underline-offset: unset !important;
  border-bottom: 0 !important;
}
.rc-guide a:hover {
  color: #0067BE !important;
  text-decoration: underline !important;
  text-decoration-color: #008CFF !important;
  text-underline-offset: 2px !important;
}

html { scroll-behavior: smooth; scroll-padding-top: 80px; }

/* ── TOKEN BLOCK ── */
.rc-guide {
  --yellow:     #FFD706;
  --blue:       #008CFF;
  --blue-tint1: #D5EAFF;
  --blue-tint2: #96C8FF;
  --scale:      #008CFF;
  --offblack:   #0D0D0B;
  --darkgray:   #32312D;
  --gray:       #807D75;
  --lightgray:  #D1CFC4;
  --brightgray: #F2F1EA;
  --offwhite:   #FCFBF7;
  --warning-fg: #FFD706;
  --warning-bg: #FFFECB;
  --error-fg:   #FF5126;
  --error-bg:   #FFEEE9;
  --success-fg: #5DC32E;
  --success-bg: #EFFAEA;
  --info-fg:    #008CFF;
  --info-bg:    #E5F3FF;
  color: #32312D !important;
  background: #ffffff;
}
.rc-guide * { box-sizing: border-box; }

/* ── FA ICON HELPERS ── */
.rc-fa-announce { color: #0D0D0B; font-size: 1rem; flex-shrink: 0; }
.rc-fa-section { color: #0D0D0B; font-size: 1rem; }

/* ── TOP NAV / BACK LINK ── */
.rc-top-nav { padding: 20px 40px 16px; max-width: 1200px; margin: 0 auto; }
.rm-Markdown.markdown-body .rc-guide a.rc-back-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-back-link { color: #807D75 !important; font-weight: 700; font-size: .9rem; display: inline-flex; align-items: center; gap: 6px; transition: color .2s; border-bottom: 0 !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-back-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-back-link:hover { color: #008CFF !important; }
.rc-content-wrap { max-width: 1200px; margin: 0 auto; padding: 0 40px; }

/* ── ANNOUNCEMENT BAR (hidden until rc-active added) ── */
.rc-announce-bar { display: none; background: #FFD706; color: #0D0D0B; align-items: center; justify-content: space-between; padding: 10px 20px; font-size: .88rem; font-weight: 600; border-radius: 10px; margin-bottom: 16px; gap: 12px; line-height: 1.4; }
.rc-announce-bar.rc-active { display: flex; }
.rc-announce-inner { display: flex; align-items: center; gap: 10px; flex: 1; flex-wrap: wrap; }
.rm-Markdown.markdown-body .rc-guide a.rc-announce-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-announce-link { color: #0D0D0B !important; font-weight: 800; white-space: nowrap; padding: 4px 12px; background: rgba(0,0,0,0.10); border-radius: 6px; transition: background 0.2s; border-bottom: 0 !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-announce-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-announce-link:hover { background: rgba(0,0,0,0.20); color: #0D0D0B !important; }

/* ── HERO (learning path — pillar pill, no stats) ── */
.rc-hero { background: linear-gradient(rgba(13,13,11,0.82), rgba(13,13,11,0.82)), url('https://files.readme.io/7a74d62bff1d532ca5adc49ae3d1c7d39a9703386b62fa98835df5c47a5f84b1-Topo_for_Black_Background_2.png') no-repeat center center; background-color: #0D0D0B; background-size: cover; color: #fff; padding: 48px 40px 44px; text-align: center; border-radius: 16px; margin-bottom: 0; }
.rc-lp-pillar-tag { display: inline-flex; align-items: center; gap: 7px; background: rgba(0,140,255,0.20); border: 1px solid rgba(0,140,255,0.45); color: #008CFF; font-size: .75rem; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; padding: 6px 14px; border-radius: 20px; margin-bottom: 20px; }
.rc-lp-pillar-tag img { width: 13px; height: 13px; object-fit: contain; }
.rc-lp-hero-title { text-align: center; margin: 0 0 14px; }
.rc-lp-hero-title h1 { font-size: 2.4rem; font-weight: 800; line-height: 1.15; color: #FCFBF7; margin: 0; }
.rc-hero > p { font-size: 1rem; opacity: .85; max-width: 660px; margin: 0 auto 8px; color: #D1CFC4; line-height: 1.6; }

/* ── NAVIGATION MENU (non-sticky, expanded — Scale) ── */
details.rc-sticky-nav-wrap { position: relative; z-index: 1; background-color: #008CFF; box-shadow: 0 4px 12px rgba(0,0,0,0.08); margin: 24px 0 48px 0; border-radius: 12px; border: 1px solid rgba(0,0,0,0.08); overflow: hidden; }
details.rc-sticky-nav-wrap > summary { list-style: none; display: flex; align-items: center; padding: 15px 24px; cursor: pointer; user-select: none; }
details.rc-sticky-nav-wrap > summary::-webkit-details-marker { display: none; }
details.rc-sticky-nav-wrap > summary::marker { display: none; }
.rc-nav-toggle-label { display: inline-flex; align-items: center; gap: 8px; font-weight: 800; font-size: .88rem; letter-spacing: 0.6px; text-transform: uppercase; color: #0D0D0B; }
.rc-nav-chevron { font-size: .72rem; color: #0D0D0B; opacity: 0.55; line-height: 1; transition: transform 0.25s ease; }
details.rc-sticky-nav-wrap[open] .rc-nav-chevron { transform: rotate(180deg); }
.rc-nav-drawer { display: grid; grid-template-rows: 0fr; transition: grid-template-rows 0.3s ease; }
details.rc-sticky-nav-wrap[open] .rc-nav-drawer { grid-template-rows: 1fr; }
.rc-nav-drawer-inner { overflow: hidden; border-top: 1px solid rgba(0,0,0,0.10); }
.rc-nav-links { display: flex; flex-wrap: wrap; gap: 6px 4px; padding: 12px 20px 18px; }
.rm-Markdown.markdown-body .rc-guide a.rc-sticky-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-sticky-link { color: #0D0D0B !important; font-weight: 700; font-size: .83rem; letter-spacing: 0.4px; text-transform: uppercase; padding: 7px 14px; border-radius: 7px; transition: all .18s; white-space: nowrap; display: inline-flex; align-items: center; gap: 6px; border-bottom: 0 !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-sticky-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-sticky-link:hover { background: rgba(0,0,0,0.10); color: #0D0D0B !important; }
.rc-sticky-link img { width: 15px; height: 15px; object-fit: contain; }
.rc-step-badge { display: inline-flex; align-items: center; justify-content: center; width: 20px; height: 20px; border-radius: 50%; background: #0D0D0B; color: #FFD706; font-size: .65rem; font-weight: 800; flex-shrink: 0; line-height: 1; }
.rm-Markdown.markdown-body .rc-guide a.rc-sticky-link-active:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-sticky-link-active { font-weight: 800; color: #0D0D0B !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-sticky-link-active:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-sticky-link-active:hover { background: rgba(0,0,0,0.10); color: #0D0D0B !important; }

/* ── CONTENT SECTION HEADING ── */
.rc-lp-section { margin-bottom: 48px; }
.rc-lp-section h2 { font-size: 1.5rem; font-weight: 800; margin: 0 0 20px; color: #0D0D0B; display: flex; align-items: center; gap: 12px; }
.rc-lp-section h2::after { content: ""; flex-grow: 1; height: 1px; background: #D1CFC4; }
.rc-lp-section p { font-size: .95rem; line-height: 1.65; color: #32312D; margin: 0 0 16px; }

/* ── ACCENT CARD (Scale) + TRY-IT PROMPT ── */
.rc-accent-card { background: #FCFBF7; border: 1px solid #D1CFC4; border-radius: 12px; padding: 24px 28px; margin: 20px 0 0; }
.rc-accent-card.rc-accent-scale { border-left: 4px solid #008CFF; }
.rc-accent-card h4 { font-size: 1rem; font-weight: 800; color: #0D0D0B; margin: 0 0 10px; }
.rc-accent-card p { font-size: .92rem; color: #32312D; line-height: 1.6; margin: 0; }
.rc-accent-card p.rc-tryit-note { font-size: .85rem; color: #807D75; margin-top: 14px; }
.rc-accent-card ul { font-size: .92rem; color: #807D75; line-height: 1.75; padding-left: 20px; margin: 6px 0 0; }
.rc-accent-card ul li { margin-bottom: 8px; }
.rc-accent-card ul li:last-child { margin-bottom: 0; }
.rc-accent-card ul li strong { color: #32312D; }
.rc-callout { display: flex; gap: 12px; padding: 16px 18px; border-radius: 10px; margin: 22px 0 0; border: 1px solid #96C8FF; background: #E5F3FF; }
.rc-callout-icon { font-size: 1rem; color: #008CFF; flex-shrink: 0; margin-top: 2px; }
.rc-callout-body { font-size: .9rem; line-height: 1.6; color: #32312D; }
.rc-callout-body > strong { color: #0D0D0B; }
.rc-callout-body em { color: #32312D; }

/* ── INLINE SPARKLES BUTTON ── */
.rm-Markdown.markdown-body .rc-guide img.rc-sparkle-inline,
.rc-guide img.rc-sparkle-inline { height: 36px !important; width: auto !important; vertical-align: middle; margin: 0 5px; display: inline-block; border: 0; border-radius: 8px; }

/* ── ASSISTANT INTRO (larger framed screenshot) ── */
.rc-assistant-intro { display: grid; grid-template-columns: 380px 1fr; gap: 40px; align-items: start; margin: 16px 0 0; }
.rc-assistant-frame { background: #FCFBF7; border: 1px solid #D1CFC4; border-radius: 14px; padding: 14px; box-shadow: 0 4px 14px rgba(13,13,11,0.05); }
.rm-Markdown.markdown-body .rc-guide img.rc-assistant-shot,
.rc-guide img.rc-assistant-shot { display: block; width: 100% !important; height: auto !important; margin: 0 !important; border-radius: 8px; }

/* ── DEPLOY PROMPT LIST ── */
.rc-deploy-item { margin-top: 15px; }
.rc-deploy-label { display: block; font-size: .72rem; font-weight: 800; text-transform: uppercase; letter-spacing: .5px; color: #008CFF; margin-bottom: 5px; }
.rc-deploy-item .rc-prompt-text { margin-top: 0 !important; }
.rc-accent-card p.rc-deploy-note { margin-top: 24px; font-weight: 700; color: #32312D; }
.rc-prompt-text { font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace !important; font-size: .92rem; color: #0D0D0B; background: #ffffff; border: 1px solid #D1CFC4; border-radius: 8px; padding: 12px 16px; margin: 12px 0 0 !important; line-height: 1.5; }

/* ── VIDEO CARD (featured) + HIDDEN STATE ── */
.rc-hidden { display: none !important; }
.rc-video-card { border: 1px solid #D1CFC4; border-radius: 14px; overflow: hidden; margin: 24px 0 20px; }
.rc-video-header { background: #0D0D0B; padding: 16px 22px; display: flex; align-items: center; gap: 10px; }
.rc-video-header h4 { font-size: .88rem; font-weight: 700; text-transform: uppercase; letter-spacing: .7px; color: #FFD706; margin: 0; }
.rc-video-embed { background: #0D0D0B; }
.rc-video-embed iframe { display: block; width: 100%; aspect-ratio: 16/9; border: none; }
.rc-video-caption { padding: 12px 22px; font-size: .83rem; color: #807D75; background: #F2F1EA; border-top: 1px solid #D1CFC4; line-height: 1.5; }

/* ── SKILL ACCORDION (new component) ── */
.rc-skill-list { display: flex; flex-direction: column; gap: 14px; margin: 8px 0 0; }
.rc-skill { border: 1px solid #D1CFC4; border-radius: 14px; overflow: hidden; background: #ffffff; }
.rc-skill > summary { list-style: none; display: flex; align-items: center; gap: 12px; padding: 18px 22px; cursor: pointer; user-select: none; transition: background .18s; }
.rc-skill > summary::-webkit-details-marker { display: none; }
.rc-skill > summary::marker { display: none; }
.rc-skill > summary:hover { background: rgba(0,140,255,0.05); }
.rc-skill-icon { font-size: 1rem; color: #008CFF; flex-shrink: 0; }
.rc-skill-name { font-size: 1.05rem; font-weight: 800; color: #0D0D0B; }
.rc-skill-chevron { font-size: .72rem; color: #807D75; margin-left: auto; transition: transform .25s ease; }
.rc-skill[open] .rc-skill-chevron { transform: rotate(180deg); }
.rc-skill-body { padding: 8px 22px 24px; border-top: 1px solid #F2F1EA; }
.rm-Markdown.markdown-body .rc-guide img.rc-skill-image,
.rc-guide img.rc-skill-image { display: block; width: 100% !important; max-width: 200px !important; height: auto !important; margin: 0 !important; }
.rc-skill-intro { display: grid; grid-template-columns: 200px 1fr; gap: 24px; align-items: start; margin: 16px 0 0; }
.rc-skill-intro-text p { font-size: .92rem; line-height: 1.65; color: #32312D; margin: 0 0 12px; }
.rc-skill-intro-text p:last-child { margin-bottom: 0; }
.rc-skill-intro-text strong { color: #32312D; }
.rc-skill-body > p { font-size: .92rem; line-height: 1.65; color: #32312D; margin: 14px 0 0; }
.rc-skill-body > p:first-child { margin-top: 16px; }
.rc-skill-body strong { color: #32312D; }

/* ── PATH NAV BUTTONS ── */
.rc-lp-nav { display: flex; align-items: center; justify-content: space-between; gap: 16px; margin: 40px 0 16px; flex-wrap: wrap; }
.rc-lp-nav-indicator { font-size: .8rem; font-weight: 600; color: #807D75; letter-spacing: .5px; white-space: nowrap !important; flex-shrink: 0; }
.rm-Markdown.markdown-body .rc-guide a.rc-btn-prev:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-btn-prev { background: transparent; color: #0D0D0B !important; text-decoration: none !important; padding: 13px 24px; border-radius: 10px; font-weight: 700; font-size: .9rem; display: inline-flex; align-items: center; gap: 8px; border: 2px solid #D1CFC4 !important; border-bottom: 2px solid #D1CFC4 !important; transition: all .2s; white-space: nowrap !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-btn-prev:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-btn-prev:hover { border: 2px solid #0D0D0B !important; border-bottom: 2px solid #0D0D0B !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-btn-path:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-btn-path { background: #FFD706; color: #0D0D0B !important; text-decoration: none !important; padding: 13px 28px; border-radius: 10px; font-weight: 800; font-size: .95rem; display: inline-flex; align-items: center; gap: 8px; transition: all .2s; border: 2px solid #FFD706 !important; border-bottom: 2px solid #FFD706 !important; white-space: nowrap !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-btn-path:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-btn-path:hover { background: transparent !important; color: #0D0D0B !important; border: 2px solid #FFD706 !important; border-bottom: 2px solid #FFD706 !important; }

/* ── RESOURCES ── */
.rc-resources { background: #F2F1EA; border-left: 4px solid #008CFF; border-radius: 10px; padding: 20px 24px; margin: 32px 0 0; }
.rc-resources h3 { font-size: .75rem; font-weight: 700; text-transform: uppercase; letter-spacing: .9px; color: #807D75; margin: 0 0 12px; display: flex; align-items: center; gap: 8px; }
.rc-resource-links { display: flex; flex-wrap: wrap; gap: 4px 20px; }
.rm-Markdown.markdown-body .rc-guide a.rc-resource-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-resource-link { color: #807D75 !important; text-decoration: underline !important; text-underline-offset: 3px; text-decoration-color: #D1CFC4 !important; font-weight: 500; font-size: .88rem; transition: all .18s; display: inline-flex; align-items: center; gap: 6px; border-bottom: 0 !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-resource-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-resource-link:hover { color: #0D0D0B !important; text-decoration: underline !important; text-underline-offset: 3px; text-decoration-color: #008CFF !important; }

/* ── FOOTER NAV ── */
.rc-footer-nav { border-top: 1px solid #D1CFC4; padding-top: 40px; margin-top: 48px; padding-bottom: 48px; }
.rc-footer-links { display: flex; flex-direction: column; gap: 16px; }
.rc-footer-section { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 24px; }
.rc-footer-label { font-weight: 800; font-size: .75rem; text-transform: uppercase; letter-spacing: .8px; color: #32312D; background: #F2F1EA; padding: 4px 10px; border-radius: 6px; margin-right: 4px; }
.rm-Markdown.markdown-body .rc-guide a.rc-footer-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
.rc-guide a.rc-footer-link { color: #807D75 !important; font-weight: 600; font-size: .82rem; display: inline-flex; align-items: center; gap: 6px; border-bottom: 0 !important; }
.rm-Markdown.markdown-body .rc-guide a.rc-footer-link:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn):hover,
.rc-guide a.rc-footer-link:hover { color: #008CFF !important; }
.rc-footer-link img { width: 14px; height: 14px; object-fit: contain; opacity: 0.5; transition: opacity .2s ease; }
.rc-footer-link:hover img { opacity: 1; }
.rc-footer-utility { display: flex; flex-wrap: wrap; gap: 24px; margin-top: 16px; padding-top: 24px; border-top: 1px solid #F2F1EA; }

/* ── CONSOLIDATED RESPONSIVE ── */
@media(max-width:1300px){
  .rc-lp-nav { justify-content: center !important; gap: 12px; }
  .rc-lp-nav-indicator { width: 100% !important; text-align: center; }
}
@media(max-width:768px){
  .rc-content-wrap { padding: 0 20px; }
  .rc-skill-intro { grid-template-columns: 1fr; gap: 14px; }
  .rc-assistant-intro { grid-template-columns: 1fr; gap: 20px; }
  .rc-assistant-frame { max-width: 440px; }
  .rc-top-nav { padding: 16px 20px; }
  .rc-hero { padding: 36px 20px 36px; }
  .rc-lp-hero-title h1 { font-size: 1.8rem; }
  .rm-Markdown.markdown-body .rc-guide a.rc-btn-prev:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
  .rc-guide a.rc-btn-prev,
  .rm-Markdown.markdown-body .rc-guide a.rc-btn-path:not([class*="Button"]):not(.rp-anchor):not(.rp-toc-pill):not(.rp-btn),
  .rc-guide a.rc-btn-path { padding: 10px 16px !important; font-size: 0.82rem !important; }
}
</style>

<div class="rc-guide">

  <div class="rc-top-nav">
    <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale" class="rc-back-link">← Back to Scale</a>
  </div>

  <div class="rc-content-wrap">

    <!-- ANNOUNCEMENT BAR — hidden by default. Add class "rc-active" to show before the webinar. -->
    <div class="rc-announce-bar rc-active">
      <div class="rc-announce-inner">
        <i class="fa-regular fa-bell rc-fa-announce"></i>
        <strong>Customer training:</strong> Get to know Recurly's agentic AI — get the on-demand customer training with live Q&A and commentary here.
        <a href="https://navigate.recurly.com/compass-assistant/" target="_blank" rel="noopener noreferrer" class="rc-announce-link">Watch it now →</a>
      </div>
    </div>

    <!-- HERO -->
    <div class="rc-hero">
      <div class="rc-lp-pillar-tag">
        <img src="https://files.readme.io/7038a0b3a299cfe800553d4c8a6721f92b1fc7e031ef697861d3603fb1bb5a05-Scale-icon-white.png" alt="Scale"> Scale · Compass Agents &amp; Skills
      </div>
      <div class="rc-lp-hero-title"><h1>Compass Assistant</h1></div>
      <p>The sparkles chat on every page in your Recurly app — run any agent's skill and get best-practice guidance, all just by asking.</p>
    </div>

    <!-- NAV (content page — expanded) -->
    <details class="rc-sticky-nav-wrap" open>
      <summary><span class="rc-nav-toggle-label">Navigation Menu <i class="fa-solid fa-chevron-up rc-nav-chevron"></i></span></summary>
      <div class="rc-nav-drawer"><div class="rc-nav-drawer-inner"><div class="rc-nav-links">
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-home" class="rc-sticky-link">
          <img src="https://files.readme.io/105d407afb9e682bd60fbc60587b3da1cfb3d09be95148d71529b20fb286aadf-Home_icon_2.png" alt=""> Navigate Home
        </a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents" class="rc-sticky-link">Path overview</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-knowledge" class="rc-sticky-link"><span class="rc-step-badge">1</span> Knowledge Agent</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-code" class="rc-sticky-link"><span class="rc-step-badge">2</span> Code Agent</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-configuration" class="rc-sticky-link"><span class="rc-step-badge">3</span> Configuration Agent</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-data" class="rc-sticky-link"><span class="rc-step-badge">4</span> Data Agent</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-retention" class="rc-sticky-link"><span class="rc-step-badge">5</span> Retention Agent</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-assistant" class="rc-sticky-link rc-sticky-link-active">
          <img src="https://files.readme.io/070e914d23dead09604d5f96b8769c88b8aae704ebd4505415e5854011030110-Black_Navigate_Home_Pin_1.png" alt=""> Compass Assistant
        </a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-review" class="rc-sticky-link"><span class="rc-step-badge">7</span> Review &amp; resources</a>
      </div></div></div>
    </details>

    <!-- SECTION: WHAT IT DOES -->
    <div class="rc-lp-section">
      <h2><i class="fa-solid fa-wand-magic-sparkles rc-fa-section"></i> What Compass Assistant does</h2>

      <div class="rc-assistant-intro">
        <div class="rc-assistant-frame">
          <img src="https://files.readme.io/44fc2aefb950e62f521c57fdd6606d68c32a5ae70440687459b40e3fb628c0c6-Compass_Assistant.png" alt="Compass Assistant chat" class="rc-assistant-shot">
        </div>
        <div class="rc-skill-intro-text">
          <p><strong>What it is:</strong>Compass Assistant is the chat behind the sparkles button <img src="https://files.readme.io/b437353dd0ddce1cbbd116ec09bf2fd1192e51351764184a60e67dc2406af827-Sparkle_Button.png" alt="Compass Assistant sparkles button" class="rc-sparkle-inline"> in the corner of Recurly. It's the single place where every agent comes together — ask for anything the five agents can do, and the Assistant runs the right skill for you.</p>
          <p><strong>How to use it:</strong> No special commands. Ask in plain language, the way you'd ask a colleague, and follow up to refine. It also answers best-practice questions, so it's often faster than logging a support ticket.</p>
        </div>
      </div>

      <!-- HIDDEN DEMO: after the webinar, delete the "rc-hidden" class from the div below to reveal this video. -->
      <div class="rc-video-card">
        <div class="rc-video-header">
          <h4>Compass Assistant overview</h4>
        </div>
        <div class="rc-video-embed">
          <iframe src="https://share.synthesia.io/embeds/videos/f4f48b7b-be7b-40eb-a8a0-57280d37aca2" loading="lazy" title="Compass Assistant Overview" allowfullscreen allow="encrypted-media; fullscreen; microphone; screen-wake-lock;"></iframe>
        </div>
        <div class="rc-video-caption">Watch Compass Assistant field a best-practices question about launching a Dunning campaign.</div>
      </div>
    </div>

    <!-- SECTION: DEPLOY ANY SKILL -->
    <div class="rc-lp-section">
      <h2><i class="fa-solid fa-bolt rc-fa-section"></i> Deploy any skill, right from the chat</h2>
      <p>Every skill in this path runs straight from the Assistant. Ask in plain language — search the docs, write code, create a plan, run an export, optimize your Dunning, or build a churn prompt — and it deploys the matching skill for you, with no trip to the Skills page.</p>
      <p>It goes beyond the skill cards, too: create add-ons and items on request, get best-practice guidance, or ask it to analyze your data and recommend what to do next — the kind of help you'd get from a Customer Success rep.</p>

      <div class="rc-accent-card rc-accent-scale">
        <h4>Deploy a skill from chat</h4>
        <p>Ask in plain language and the Assistant runs the matching skill — one prompt to try for each:</p>
        <div class="rc-deploy-item">
          <span class="rc-deploy-label">Documentation search</span>
          <p class="rc-prompt-text">How does dunning work in Recurly?</p>
        </div>
        <div class="rc-deploy-item">
          <span class="rc-deploy-label">Write code</span>
          <p class="rc-prompt-text">Generate a Python snippet to create a subscription via the Recurly API.</p>
        </div>
        <div class="rc-deploy-item">
          <span class="rc-deploy-label">Create a plan</span>
          <p class="rc-prompt-text">Create a monthly plan for $9.99/month with a 14-day free trial.</p>
        </div>
        <div class="rc-deploy-item">
          <span class="rc-deploy-label">Generate an export</span>
          <p class="rc-prompt-text">Show me all past-due invoices from the last 30 days.</p>
        </div>
        <div class="rc-deploy-item">
          <span class="rc-deploy-label">Optimize default Dunning</span>
          <p class="rc-prompt-text">Optimize my default dunning campaign to the recommended length.</p>
        </div>
        <div class="rc-deploy-item">
          <span class="rc-deploy-label">Involuntary churn remediation</span>
          <p class="rc-prompt-text">Set up an in-app prompt to recover past-due payments.</p>
        </div>
        <p class="rc-deploy-note">No skill card needed — Compass Assistant can also create add-ons and items on request:</p>
        <div class="rc-deploy-item">
          <span class="rc-deploy-label">Add-on</span>
          <p class="rc-prompt-text">Add a $5/month priority-support add-on to my Pro plan.</p>
        </div>
        <div class="rc-deploy-item">
          <span class="rc-deploy-label">Item</span>
          <p class="rc-prompt-text">Create a new item for a one-time onboarding fee.</p>
        </div>
      </div>

      <div class="rc-accent-card rc-accent-scale">
        <h4>Or just ask</h4>
        <p>The Assistant is also an advisor — ask for guidance or analysis, no skill required:</p>
        <p class="rc-prompt-text">I want to launch a new Dunning campaign — what best practices should I follow?</p>
        <p class="rc-prompt-text">Analyze my churn over the past 90 days and recommend a playbook to optimize retention.</p>
      </div>
    </div>

    <!-- SECTION: HOW TO OPEN IT -->
    <div class="rc-lp-section">
      <h2><i class="fa-solid fa-comment-dots rc-fa-section"></i> How to open it</h2>
      <p>Compass Assistant lives in the sparkles button <img src="https://files.readme.io/b437353dd0ddce1cbbd116ec09bf2fd1192e51351764184a60e67dc2406af827-Sparkle_Button.png" alt="Compass Assistant sparkles button" class="rc-sparkle-inline"> in the bottom-right of any Recurly page, or use the full-screen Assistant view under <strong>Compass</strong> in the left navigation, which keeps your chat history.</p>

      <div class="rc-accent-card rc-accent-scale">
        <h4>Pro tips</h4>
        <ul>
          <li><strong>Ask follow-ups</strong> to refine an answer — you don't need to start over.</li>
          <li><strong>Use the thumbs up/down</strong> buttons to help improve accuracy over time.</li>
          <li><strong>It's on every page</strong> — Compass Assistant is available anywhere in Recurly.</li>
        </ul>
      </div>
    </div>

    <!-- PATH NAV -->
    <div class="rc-lp-nav">
      <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-retention" class="rc-btn-prev">← Retention agent</a>
      <span class="rc-lp-nav-indicator">6 of 7</span>
      <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-review" class="rc-btn-path">Next: Review &amp; resources →</a>
    </div>

    <!-- RESOURCES -->
    <div class="rc-resources">
      <h3><i class="fa-solid fa-book-open rc-fa-section"></i> Resources</h3>
      <div class="rc-resource-links">
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/compass-skills" target="_blank" rel="noopener noreferrer" class="rc-resource-link"><i class="fa-regular fa-file-lines"></i> Recurly Docs: Compass Skills</a>
        <a href="https://docs.recurly.com/recurly-subscriptions/docs/compass-assistant" target="_blank" rel="noopener noreferrer" class="rc-resource-link"><i class="fa-regular fa-file-lines"></i> Recurly Docs: Compass Assistant</a>
      </div>
    </div>

    <!-- FOOTER -->
    <div class="rc-footer-nav">
      <div class="rc-footer-links">
        <        <div class="rc-footer-section">
          <span class="rc-footer-label">Compass agents &amp; skills</span>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents" class="rc-footer-link">Path overview</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-knowledge" class="rc-footer-link">1. Knowledge agent</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-code" class="rc-footer-link">2. Code agent</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-configuration" class="rc-footer-link">3. Configuration agent</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-data" class="rc-footer-link">4. Data agent</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-retention" class="rc-footer-link">5. Retention agent</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-assistant" class="rc-footer-link">6. Compass Assistant</a>
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-scale-compass-agents-review" class="rc-footer-link">7. Review &amp; resources</a>
        </div>
        <div class="rc-footer-utility">
          <a href="https://docs.recurly.com/recurly-subscriptions/docs/navigate-home" class="rc-footer-link">
            <img src="https://files.readme.io/105d407afb9e682bd60fbc60587b3da1cfb3d09be95148d71529b20fb286aadf-Home_icon_2.png" alt=""> Navigate Home
          </a>
          <a href="mailto:support@recurly.com" class="rc-footer-link">Contact Support</a>
        </div>
      </div>
    </div>

  </div>
</div>
`}</HTMLBlock>
