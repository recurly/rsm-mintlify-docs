---
title: Stripe Payment Elements
excerpt: >-
  Build a fully branded checkout UI with Stripe Payment Elements, then pass a
  confirmation token to Recurly's v3 API to process payments and store reusable
  billing details.
deprecated: false
hidden: false
metadata:
  robots: index
---
<div class="rp-page">
  <div class="rp-overview">Stripe Payment Elements and Express Checkout Elements let you build a fully branded checkout experience using Stripe's components. Pass the resulting confirmation token to Recurly's v3 API to process payments, store reusable billing details, and support both one-time and recurring charges.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-benefits"><span class="rp-toc-num">2</span>Key benefits</a>
    <a class="rp-toc-pill" href="#key-details"><span class="rp-toc-num">3</span>Key details</a>
  </div>
</div>

### Prerequisites and limitations

<ul class="rp-list">
  <li>Requires a working Recurly v3 API integration and Recurly.js setup</li>
  <li>Some Stripe payment methods and APMs are restricted by merchant country — if a method doesn't appear in your Stripe Dashboard, your account's country may not qualify (e.g., Revolut is available in the UK and EU only)</li>
  <li>Stripe Payment Links, Stripe Checkout, and Radar are not supported through this integration</li>
  <li>100% coupons and account credits: because gateway communication is required during initial setup, free trials are recommended in these cases to avoid future payment failures</li>
</ul>

# Definition

<div class="rp-definition">Stripe Payment Elements lets you build a fully branded checkout UI using Stripe's components, then pass a confirmation token to Recurly's v3 API to process payments and store reusable payment details. Upon approval, Recurly returns a gateway token for processing renewals and future charges — for both one-time and recurring billing.</div>

# Key benefits

<div class="rp-benefits">
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-paintbrush" aria-hidden="true"></i></div>
    <strong>Customizable checkout</strong>
    <span>Design your own checkout UI with Stripe Payment Elements. Use Stripe's pre-built themes or build a fully custom experience with the Stripe customization APIs.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i></div>
    <strong>Secure tokenization</strong>
    <span>Pass Stripe confirmation tokens to Recurly for PCI-compliant payment processing — a gateway token is returned for renewals and future charges.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-credit-card" aria-hidden="true"></i></div>
    <strong>Wide payment support</strong>
    <span>Accept cards, wallets, direct debit options, and select APMs — all within your custom checkout flow.</span>
  </div>
</div>

# Key details

## Supported features

Build a checkout solution with Stripe Payment Elements or Express Checkout Elements and pass the resulting confirmation token to Recurly via the v3 API. Customers can also update their billing information through Stripe Elements or existing Recurly solutions — Checkout, Hosted Payment Pages, or Recurly.js.


<Image src="https://files.readme.io/bd6ee4314c74650eada8d5e8a62c0318b14857d22b69644925b570645a5a4e61-Stripe_Payment_element.png" align="center" width="40%" border={true} />


Preview Stripe Elements capabilities on <a href="https://checkout.stripe.dev/elements" target="_blank">Stripe's demo site</a>. For full implementation details, see the <a href="https://docs.recurly.com/recurly-subscriptions/docs/third-party-checkout#/" target="_blank">Developer Hub guide</a>.

***

## Supported payment methods

<table class="rp-gw-table">
  <tr class="rp-thead-row"><td>Category</td><td>Payment methods</td></tr>
  <tr><td>Cards and wallets</td><td>Cards, Link by Stripe, Apple Pay, Google Pay, Cash App Pay</td></tr>
  <tr><td>Direct debit</td><td>ACH, SEPA, BACS, iDEAL, BECS. ACH requires <a href="https://stripe.com/financial-connections" target="_blank">Financial Connections</a> for NACHA compliance.</td></tr>
  <tr><td>APMs</td><td>Klarna Recurring (Pay Now, Pay Later, BNPL), Revolut (UK/EU only)</td></tr>
</table>

<br />
