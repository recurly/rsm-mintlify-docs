---
title: PayPay
excerpt: >-
  Learn how PayPay wallet payments work with Recurly subscriptions through
  Adyen, including setup requirements, limitations, and integration details.
deprecated: false
hidden: false
metadata:
  robots: index
---
<div class="rp-page">
  <div class="rp-overview">PayPay wallet enables recurring subscription payments in Japan. Customers authorize their payment after redirecting to a modal, and Recurly manages transaction and token status updates through webhooks from the gateway.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-details"><span class="rp-toc-num">2</span>Key details</a>
    <a class="rp-toc-pill" href="#integration-guide"><span class="rp-toc-num">3</span>Integration guide</a>
    <a class="rp-toc-pill" href="#checkout-flow"><span class="rp-toc-num">4</span>Checkout flow</a>
    <a class="rp-toc-pill" href="#faqs"><span class="rp-toc-num">5</span>FAQs</a>
  </div>
</div>

### Supported gateways

<ul class="rp-list">
  <li><a href="https://docs.recurly.com/recurly-subscriptions/docs/adyen" target="_blank">Adyen</a></li>
</ul>

# Definition

<div class="rp-definition">PayPay is a digital wallet in Japan, where approximately half of the population are registered users. Launched in 2018 as a joint venture between SoftBank and Yahoo Japan, the app lets users pay at restaurants, convenience stores, taxis, and online shops by scanning a QR code or showing a barcode. It has over 70 million users nationwide.

With Recurly, customers can sign up for subscriptions using their PayPay wallet, authorizing and authenticating directly through a modal. Recurly integrates PayPay through Adyen. See the <a href="paypay-integration-guide" target="_blank">PayPay integration guide</a> to get started.</div>

# Key details

<div class="rp-card">

### Use cases

**Subscription plans** — Combine Recurly's subscription management with Adyen to offer PayPay for recurring billing in Japan.

</div>

## PayPay limitations

PayPay is designed specifically for subscriptions and doesn't support many standard Recurly features available with credit cards.

<ul class="rp-list">
  <li>Creating subscriptions through the Recurly admin UI isn't supported — the PayPay wallet requires the customer to be in session to confirm the subscription by authenticating to their account.</li>
  <li>Recurly Checkout and Hosted Payment Pages aren't currently supported.</li>
  <li>100% coupons at signup aren't supported, since token creation is required — use a free trial instead. Standard coupons are supported.</li>
</ul>

<div class="rp-callout rp-callout-important">
  <div><strong><i class="fa-solid fa-circle-exclamation" aria-hidden="true"></i> Important</strong>Request a <code>SALE</code> acquirer setup. Recurly renewals process as <code>SALE</code> transactions and can't run on a separate Auth-and-Capture flow. An <code>AUTH</code> acquirer setup only supports one-time transactions — not renewals or subscriptions.</div>
</div>

# Checkout flow

Customers will select PayPay at checkout, and they are redirected to the PayPay app (on mobile) or shown a QR code (on desktop) to authorize the payment. Payment is completed after customer approval and the final status is confirmed via webhooks from the gateway. You will also receive Recurly webhooks in order to handle transaction, invoice, and subscription status in your environment.

## Customer actions in the PayPay wallet

Customers interact with their account during signup:

- **Customer wallet authentication** — Required for every new subscription.

<div class="rp-callout rp-callout-warning">
  <div><strong><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Warning</strong>If the customer doesn't authenticate their wallet credentials, the token isn't set up correctly and the subscription fails.</div>
</div>

## Required fields

Always send the following with PayPay transactions:

- **Currency** — JPY
- **Locale** — Japanese, unless the consumer's device locale dictates otherwise
- **Customer name and billing address** — as with any standard transaction

# Integration guide

PayPay isn't supported on Recurly Checkout or Hosted Payment Pages. See the <a href="paypay-integration-guide" target="_blank">PayPay integration guide</a> for full implementation details.

## Billing information updates

PayPay doesn't support direct billing info updates in Recurly. Customers must update payment details in their PayPay app. If a customer's wallet account changes, they'll need to resubscribe.

## Testing

Set up a test account with Adyen and follow their sandbox instructions. You don't need to download the PayPay app to test — Adyen provides a sandbox simulator for the redirect flow.

# FAQs

<Accordion title="Do you support Auth and Capture with PayPay?">
  Yes, but only if your business use case doesn't include subscriptions. Recurly's subscription model doesn't support automated Auth and Capture on renewals — only merchants using a <code>SALE</code> acquirer setup can run subscriptions with PayPay.
</Accordion>

***

<br />

<br />