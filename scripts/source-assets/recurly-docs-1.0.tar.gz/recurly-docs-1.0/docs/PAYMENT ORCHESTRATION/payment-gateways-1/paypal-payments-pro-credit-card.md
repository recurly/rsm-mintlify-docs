---
title: PayPal Payments Pro (credit card)
excerpt: >-
  Empower your business with PayPal Payments Pro, an integrated solution for
  credit card processing through Recurly. Designed to streamline your
  transactions while ensuring security and compliance with a globally recognized
  payment gateway.
deprecated: false
hidden: true
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
> ❗️ Deprecated. Do not use.

# Overview

### Required plan

This feature or setting is available to all customers on any Recurly subscription plan.

### Prerequisites

* Merchant location in the US, Canada, or the UK due to PayPal's restrictions.
* PayPal Payments Pro base account (Recurring Payments feature from PayPal is not needed as Recurly handles this).
* PayPal API credentials: API Username, API Password, and Signature or PEM Certificate.
* Ensure your PayPal account is configured to not require Card Security Code (CSC) for recurring transactions.

### Limitations

* Limited to merchants located in the US, Canada, and UK.
* In Canada, American Express is not supported.
* Full address details are mandatory for every transaction.
* The Recurring Payments feature of PayPal is not required as Recurly takes care of recurring transactions.

# Definition

PayPal Payments Pro, supported through Recurly, acts as both a payment gateway and a merchant account, providing an integrated solution to process credit card transactions seamlessly. Merchants in the US, UK, and Canada can sign up for a base account to avail of this service, bypassing the need for PayPal's Recurring Payments feature since Recurly handles recurring transactions adeptly.

> **Note**: Visit our guide on testing your gateway configurations in Recurly to ensure your payment processes are set up correctly.

# Key details

| Feature                         | Description                                           |
| ------------------------------- | ----------------------------------------------------- |
| Services that work with Recurly | Credit card processing                                |
| Supported operations            | N/A                                                   |
| Supported payment types         | Credit card payments                                  |
| Supported card brands           | All major brands excluding American Express in Canada |
| Gateway Specific 3DS2 Supported | N/A                                                   |
| Populate MIT GSF Support        | N/A                                                   |
| Regions                         | US, UK, Canada                                        |
| Currencies                      | N/A                                                   |

#### **Getting Started with PayPal Payments Pro**

Kickstart your journey with [PayPal Payments Pro](https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content\&content_ID=merchant/wp_pro) and Recurly to streamline your credit card processing. Simply sign up for the base account with PayPal Payments Pro, without the necessity for their Recurring Payments feature, and you are set to sail. This service is confined to merchants operating from the US, Canada, and the UK due to PayPal's regional restrictions.

#### **Card Security Code (CSC) Considerations**

A pivotal element is the Card Security Code (CSC), also referred to as CVV, which, by default, is mandated by Recurly for initiating any new transaction or subscription. Post the setup of your PayPal credentials in Recurly, it validates the necessity for CSC in every transaction based on your PayPal account configurations.\
To harmonize with Recurly's operation, which doesn't store CSC owing to PCI stipulations, ensure to contact PayPal and deactivate the compulsory CSC specification for every transaction, facilitating the smooth progression of recurring transactions without CSC inputs.

#### **PEM versus Signature**

While Recurly backs both PEM and signature methods for transactions, it is advisable to opt for signature API credentials especially if you envisage incorporating PayPal payments alongside credit card transactions in future. In case a PEM certificate exists, it necessitates deletion to initiate the procurement of signature credentials.

#### **Transactional Specifics**

* **American Express in Canada**: Merchants should note the non-compatibility of American Express with PayPal Website Payments Pro in Canada.
* **Address Details**: An essential requirement is the provision of complete address particulars for every transaction to maintain accord with PayPal Payment Pro's prerequisites, thus, configure Recurly to demand full billing information encompassing name, contact number, and address details including city, state/province, postal/zip code, and country.

#### **Integration Essentials**

While delving into the integration, it’s crucial to pay heed to some fundamental aspects to ensure a hassle-free operation. Always ensure your PayPal account is duly configured not to necessitate CSC for recurring transactions, upholding a smooth functioning with Recurly's framework. Moreover, be ready with the imperative API credentials—Username, Password, and Signature or PEM certificate for a successful integration process.

# **Guidelines for Configuring Recurly with PayPal**

To bridge your Recurly account with the [PayPal Payments Pro](https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content\&content_ID=merchant/wp_pro) facility, follow the enlisted steps to fetch your PayPal API credentials:

1. **Access PayPal**: Visit [paypal.com](https://www.paypal.com/) and log in to your account.
2. **Profile Sub-Tab**: Locate and click on the “Profile” sub-tab under the “My Account” segment.
3. **API Access**: Click on either "API access" or "Request API credentials", contingent on your account type.
4. **Request API Credentials**: Choose the second option presented for requesting API credentials and follow through to access your API details.
5. **API Credentials**: Here, you would find your indispensable API credentials inclusive of username, password, and signature.
