---
title: Amazon Pay V1
excerpt: >-
  Connect Amazon Pay to Recurly so customers can subscribe using payment details
  already stored in their Amazon account — no redirect required.
deprecated: false
hidden: true
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
<div class="rp-page">
  <div class="rp-overview">Amazon Pay lets your customers subscribe using the payment and address details already saved in their Amazon account — without ever leaving your site. This guide covers everything from initial account setup and Recurly configuration to integration, subscription management, and EU/UK regional specifics.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-details"><span class="rp-toc-num">2</span>Key details</a>
    <a class="rp-toc-pill" href="#integration"><span class="rp-toc-num">3</span>Integration</a>
    <a class="rp-toc-pill" href="#subscription-management"><span class="rp-toc-num">4</span>Subscription management</a>
    <a class="rp-toc-pill" href="#recurly-settings"><span class="rp-toc-num">5</span>Recurly settings</a>
    <a class="rp-toc-pill" href="#gateway-settings"><span class="rp-toc-num">6</span>Gateway settings</a>
  </div>
</div>

### Prerequisites

<ul class="rp-list">
  <li>Sign up for an <a href="https://payments.amazon.com/register?registration_source=SPPD&spId=A35095BGBGQR66" target="_blank">Amazon Pay account</a>.</li>
  <li>Set up an Amazon application to authenticate users on your site.</li>
  <li>Enable Amazon Pay on your Recurly site.</li>
</ul>

### Limitations

<ul class="rp-list">
  <li>Amazon Pay does not currently support 3DS or PSD2.</li>
  <li>Amazon Pay is available only in specific regions: the US, Europe, and the UK.</li>
</ul>

# Definition

<div class="rp-definition">Amazon Pay is a payment method that lets customers subscribe to your plans using payment and address details already stored in their Amazon account. After a one-time Amazon login, customers confirm their details directly on your site using Amazon's inline widgets — no redirect required for subsequent transactions. Recurly retains the resulting billing agreement for automatic renewals.</div>

# Key details

<table class="rp-gw-table">
  <tr class="rp-thead-row"><td>Feature</td><td>Details</td></tr>
  <tr><td>Services that work with Recurly</td><td>Amazon</td></tr>
  <tr><td>Supported operations</td><td>Authorize and Capture, Purchase, Refund, Verify, Void</td></tr>
  <tr><td>Supported payment types</td><td>Amazon</td></tr>
  <tr><td>Supported card brands</td><td>Visa, Mastercard</td></tr>
  <tr><td>Gateway-specific 3DS2 supported</td><td>Yes</td></tr>
  <tr><td>Card on file supported</td><td>Yes</td></tr>
  <tr><td>Regions</td><td>US, EU, and the UK</td></tr>
  <tr><td>Currencies</td><td>AUD, GBP, DKK, EUR, HKD, JPY, NZD, NOK, ZAR, SEK, CHF, and USD</td></tr>
</table>

<div class="rp-card">

### Use cases

- Subscription checkout for Amazon customers without leaving your site
- Allowing subscribers to manage payment and billing details through Amazon Pay

</div>


<Image src="https://files.readme.io/bpZ0MwSZTmdQROvA5ikl_amzn-mocks.png" align="center" width="75%" border={true} />


# Integration

After configuring your Recurly site and Amazon Pay account, you can integrate the Amazon Pay library into your subscription checkout flow.


<Image src="https://files.readme.io/3lOrtM3jSyypS3EE8Kxw_amzn-overview.png" align="center" width="75%" border={true} />


Recurly provides a free <a href="https://github.com/recurly/pay-with-amazon" target="_blank">JavaScript plug-in library</a> to embed Amazon Pay directly in your site. The library handles inline widget interactions and is configurable through simple parameters. The only step that takes customers off your site is the initial Amazon login — after that, they're redirected back to confirm their address and payment details using the Amazon widgets.


<Image src="https://files.readme.io/Ant1pFYMSMizM7oZvKUR_amzn-widgets.png" align="center" width="75%" border={true} />


Add the following JavaScript to your document's `<head>` section:

```html
<script src="pay-with-amazon.min.js"></script>
```

Still in the `<head>`, initialize `PayWithAmazon` with your configuration:

```javascript
var payWithAmazon = new PayWithAmazon({
    sellerId: 'ABC',
    clientId: 'XYZ',
    button: { id: 'pay-with-amazon', [type], [color] },
    addressBook: { id: 'address-book', [width], [height] },
    wallet: { id: 'wallet', [width], [height] },
    consent: { id: 'consent', [width], [height] },
    region: 'eu' // Options are 'eu' or 'uk'
});
```

<div class="rp-callout rp-callout-important">
  <div><strong><i class="fa-solid fa-circle-exclamation" aria-hidden="true"></i> Important</strong> If your customers are not in the US, you must specify the <code>region</code> parameter. EU and UK regions must include the region in every transaction request.</div>
</div>

Once a customer confirms their Amazon payment details, an Amazon Billing Agreement ID (`id`) is generated. Pass this ID to Recurly's <a href="https://docs.recurly.com/api/subscriptions#create-subscription" target="_blank">create subscription API</a> to set up billing for the account:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<subscription>
    <plan_code>gold</plan_code>
    <currency>USD</currency>
    <account>
        <account_code>customer</account_code>
        <billing_info>
            <amazon_billing_agreement_id>abc-xyz</amazon_billing_agreement_id>
            <first_name>John</first_name>
            <last_name>Doe</last_name>
        </billing_info>
    </account>
</subscription>
```

While optional, using <a href="https://js.recurly.com/" target="_blank">Recurly.js</a> alongside Amazon Pay gives you access to plan and add-on details and a pricing preview module. **Recurly.js v4 is recommended** for Amazon Pay integrations.

## Configuration examples

### Standard subscription

The default configuration renders address, payment, and consent widgets:

```javascript
var payWithAmazon = new PayWithAmazon({
    sellerId: 'ABC',
    clientId: 'XYZ',
    button: { id: 'pay-with-amazon', type: 'large', color: 'DarkGray' },
    addressBook: { id: 'address-book', width: 400, height: 260 },
    wallet: { id: 'wallet', width: 400, height: 260 },
    consent: { id: 'consent', width: 400, height: 140 }
});
```

### No address widget

For digital goods where a shipping address isn't needed, omit the `addressBook` widget to simplify checkout:

```javascript
var payWithAmazon = new PayWithAmazon({
    sellerId: 'ABC',
    clientId: 'XYZ',
    button: { id: 'pay-with-amazon', type: 'large', color: 'DarkGray' },
    wallet: { id: 'wallet', width: 400, height: 260 },
    consent: { id: 'consent', width: 400, height: 140 }
});
```

For full usage and customization options, see the <a href="https://github.com/recurly/pay-with-amazon" target="_blank">GitHub repository</a>.

# Subscription management

When a customer initiates checkout with Amazon Pay, they log in with their Amazon credentials and confirm their stored address and payment details — establishing a billing agreement for their subscription plan.

Once the subscription is active, Recurly retains the billing agreement and relevant Amazon details. This agreement is used automatically for subsequent renewals.


<Image src="https://files.readme.io/AkKPBQK6TJapjcMRCJgW_amzn-flow.png" align="center" width="50%" />


Customers can update or cancel their billing agreement through either platform:

- **Amazon interface** — Customers can update their payment method or cancel the billing agreement directly from their Amazon account.
- **Recurly interface** — You can refresh billing information using a newly obtained Amazon Billing Agreement ID via the JavaScript library or an alternate payment method such as a credit card. Use the <a href="https://docs.recurly.com/api/billing-info" target="_blank">update billing info API</a> for this. Recurly also integrates with Amazon's CloseBillingAgreement API (see <a href="https://pay.amazon.com/us/developer/documentation/apireference/201752870" target="_blank">Amazon documentation</a>) to handle billing agreement termination notifications — contact Recurly Support to enable this.

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong> All customer-initiated activities are logged in the account's activity feed.</div>
</div>

# Recurly settings

## Sign up for Amazon Pay

To get started, create an <a href="https://payments.amazon.com/register?registration_source=SPPD&spId=A35095BGBGQR66" target="_blank">Amazon Pay account</a> (free to register). If you already have one, <a href="https://sellercentral.amazon.com/" target="_blank">log in here</a>.

## Set up Amazon Pay in Recurly

Once your Amazon Pay account is ready, configure your Recurly site to accept it for recurring subscriptions.

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Open Payment Gateways</h4><p>In Recurly, navigate to <a href="https://app.recurly.com/go/configuration/payment_gateways/new" target="_blank">Configuration → Payment Gateways</a> and select Amazon Pay from the available providers. Note that Amazon Pay is currently available in the US, UK, and EU only.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Enter your Amazon credentials</h4><p>Input your Amazon MWS Access Key, Secret Access Key, and Merchant ID (Seller ID) into the designated fields.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Configure address settings</h4><p>Choose whether to set the Amazon address as the default in your customer's Account Info. You can also opt to replace any pre-existing address when this feature is enabled.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">4</div>
    <div><h4>Save your changes</h4><p>Click <strong>Save Changes</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">5</div>
    <div><h4>Test the connection</h4><p>Click <strong>Test Configuration</strong> to verify Recurly can communicate with your Amazon Pay account. For Hosted Payment Pages, an Amazon Client ID is required, and your Recurly subdomain must be listed in <a href="https://developer.amazon.com/docs/login-with-amazon/web-docs.html" target="_blank">Amazon's Security Profile</a>.</p></div>
  </div>
</div>

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong> Transactions are not processed in Recurly's sandbox environment. However, Amazon Pay credentials are valid in both development and production Recurly accounts. To process live transactions, both your Amazon Pay account and your Recurly account must be in production mode.</div>
</div>

## Amazon Instant Payment Notifications (IPN)

Recurly supports Amazon Pay's Instant Payment Notification (IPN) feature, which sends notifications for successful payment refunds. To enable IPN and start receiving refund updates, follow <a href="https://pay.amazon.com/us/developer/documentation/lpwa/201909440" target="_blank">these instructions</a>.

When activated, Recurly retrieves the data needed to update refund transaction statuses in your account. Enter your Merchant URL in Amazon using the following format:

`https://callbacks.recurly.com/amazon/YOUR_MERCHANT_SUBDOMAIN`

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong> For Recurly sites hosted in EU data centers, use <code>https://callbacks.eu.recurly.com/amazon/YOUR_MERCHANT_SUBDOMAIN</code> instead.</div>
</div>

## Amazon shipping address

During Amazon Pay checkout, customers can enter a shipping address. Recurly can save this as either a **Recurly Account Address** or a **Recurly Shipping Address**, depending on your gateway configuration.


<Image src="https://files.readme.io/a088525-Screen_Shot_2016-09-08_at_5.19.29_PM.png" align="center" width="75%" border={true} />


Saving as a Recurly Shipping Address ensures accurate tax calculations based on the shipping location and includes shipping details on the invoice. Learn more about managing <a href="https://docs.recurly.com/docs/shipping-addresses" target="_blank">shipping addresses</a>.

To prevent duplicates, addresses that match existing records in Recurly are automatically linked to the new subscription rather than created again.

### Handling customer names

Recurly requires both a first and last name to store a shipping address or process a transaction. Amazon, however, only requires a single name field. If Amazon doesn't return a last name, an API error will occur. To avoid this, encourage customers to enter their full name. If a full name isn't available, Recurly will attempt to retrieve it from Amazon via API — but providing it upfront is recommended.

## Amazon references in Recurly admin

In the Recurly Admin panel, under the **Billing Info** section of an Account Details page, you can view Amazon Pay engagement details including the Amazon Billing Agreement ID — useful for customer service interactions.


<Image src="https://files.readme.io/fdc8297-amzn-billing-info.png" align="center" width="40%" border={true} />


# Gateway settings

## Amazon Pay support in Europe and the United Kingdom

Recurly supports Amazon Pay transactions in the following regions:

- **Europe** — transactions in Euros (€)
- **United Kingdom** — transactions in Pounds Sterling (£)

### Credentials

EU and UK integrations use a delegated authentication model for transaction request signatures. Unlike the US integration (which requires an MWS Access Key, Secret Key, and Seller/Merchant ID), EU/UK integrations use the Seller/Merchant ID together with an MWS Auth token.

## Sign up for an EU or UK Amazon Pay account

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Register or log in</h4><p>Create an <a href="https://sellercentral-europe.amazon.com/" target="_blank">EU or UK Amazon Pay account</a>, or log in if you already have one.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Open User Permissions</h4><p>Navigate to <strong>Settings → User Permissions</strong>, then click <strong>Visit Manage Your Apps</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Authorize a new developer</h4><p>Select <strong>Authorize new developer</strong> and provide the Developer's Name (any value) and Developer ID (obtain this from your Amazon representative).</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">4</div>
    <div><h4>Accept the MWS terms of service</h4><p>Consent to the MWS terms of service to complete the authorization.</p></div>
  </div>
</div>

## Add the EU/UK gateway in Recurly

EU and UK Amazon Pay integrations are separate gateways, each requiring its own setup. Follow the <a href="#set-up-amazon-pay-in-recurly">Recurly setup steps above</a> for each gateway, using your new MWS Auth token in place of the standard credentials.

## Specify the Amazon Pay region

Always include the correct region code in EU/UK Amazon Pay transaction requests. Omitting it causes Recurly to default to USD, which can result in declines for one-off transactions, initial subscription transactions, and renewals — because the transaction won't route to the intended Amazon Pay region. See the <a href="https://dev.recurly.com/docs/create-an-accounts-billing-info-using-external-token" target="_blank">developer documentation</a> for implementation details.

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong> Amazon Pay billing agreements are region-specific and cannot be transferred. If a customer moves to a different region, a new billing agreement must be created in that region.</div>
</div>

<br />
