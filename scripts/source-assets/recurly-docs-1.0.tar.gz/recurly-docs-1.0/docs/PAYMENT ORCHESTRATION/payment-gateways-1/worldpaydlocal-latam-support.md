---
title: Worldpay - Global e-commerce
excerpt: >-
  Connect WorldPay WPG to Recurly for global payment processing — including
  LATAM via Ebanx, SEPA, ACH, Tarjeta Naranja, and multi-currency support across
  50+ currencies.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
<div class="rp-callout rp-callout-warning">
  <div><strong><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Wrong guide?</strong> If you have a Vantiv/Litle Merchant ID, use the <a href="https://docs.recurly.com/docs/vantiv" target="_blank">WorldPay US eCommerce (Vantiv) directions</a> instead.</div>
</div>

<div class="rp-page">
  <div class="rp-overview">WorldPay WPG integrates with Recurly for global payment processing — covering credit cards, Apple Pay, Google Pay, SEPA, ACH, and local LATAM card brands including Tarjeta Naranja. LATAM processing is handled via Ebanx (or dLocal for existing merchants). This guide covers WorldPay account configuration, Recurly setup, and regional configuration for Argentina, SEPA, and ACH.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-details"><span class="rp-toc-num">2</span>Key details</a>
    <a class="rp-toc-pill" href="#credentials"><span class="rp-toc-num">3</span>Credentials</a>
    <a class="rp-toc-pill" href="#configuring-worldpay-with-recurly"><span class="rp-toc-num">4</span>Configuration</a>
    <a class="rp-toc-pill" href="#faqs"><span class="rp-toc-num">5</span>FAQs</a>
  </div>
</div>

### Prerequisites

<ul class="rp-list">
  <li>Established commercial agreements with WorldPay and Ebanx to facilitate local transactions. WorldPay supports dLocal for existing merchants only — new merchants should work with WorldPay on an Ebanx solution. Contact <a href="mailto:partnerships@recurly.com">partnerships@recurly.com</a> for introductions if needed.</li>
  <li><strong>For Argentinian processing</strong> — An active Recurly account with ARS currency enabled, a WorldPay gateway configured for ARS, and a WorldPay merchant account capable of Zero Dollar Authorizations (ZDA).</li>
  <li><strong>For TLID storage</strong> — WorldPay does not return TLIDs by default. Contact WorldPay to enable TLID return for Mastercard transactions before using this feature.</li>
  <li><strong>For SEPA (Direct Debit)</strong> — An active Recurly account with EUR currency enabled, a WorldPay gateway configured for SEPA/EUR with mandate tokenization support.</li>
  <li><strong>For ACH (Direct Debit)</strong> — An active Recurly account with USD currency enabled and WorldPay NACHA pre-verification enabled for ACH/USD compliance.</li>
</ul>

### Limitations

<ul class="rp-list">
  <li><strong>Tarjeta Naranja does not support ZDA</strong> — Verifications for this card brand are processed with a $1.00 charge instead.</li>
  <li><strong>WorldPay SEPA does not support free-trial subscriptions or verification transactions</strong> — SEPA billing info updates must occur within the context of processing a transaction.</li>
  <li><strong>Tax ID required for many LATAM transactions</strong> — Submit a tax ID (e.g., CUIT) with each transaction. If using CUIT, CPF, or CNPJ, specify the type via API using <code>tax_identifier_type</code>. For all other tax ID types, send the value without a type.</li>
  <li><strong>Sales tax may be required</strong> — Certain regions require sales tax on transactions. Confirm requirements with WorldPay and configure sales tax in your Recurly site. See <a href="https://docs.recurly.com/docs/tax#/" target="_blank">sales tax documentation</a>.</li>
  <li><strong>Prohibited businesses</strong> — Check <a href="http://support.worldpay.com/support/kb/gg/billdesk/content/prohibitedmerchantcategories.htm" target="_blank">WorldPay's prohibited business types</a> to confirm your business qualifies.</li>
</ul>

# Definition

<div class="rp-definition">WorldPay WPG is a global payment gateway that processes credit cards, Apple Pay, Google Pay, SEPA direct debit, ACH, and local LATAM card brands through Recurly. It supports 50+ currencies and regional specialization in the UK/EU and Latin America via partnerships with Ebanx and dLocal. WorldPay processes voids and refunds asynchronously — there is a small chance WorldPay may reject a void or refund request 5 to 45 minutes after submission.</div>

# Key details

<table class="rp-gw-table">
  <tr class="rp-thead-row"><td>Feature</td><td>Details</td></tr>
  <tr><td>Services that work with Recurly</td><td>Payment processing, recurring subscriptions, <a href="https://docs.recurly.com/recurly-subscriptions/docs/moto-transactions#/" target="_blank">MOTO</a> processing. LATAM support via Ebanx and dLocal (existing merchants only).</td></tr>
  <tr><td>Supported operations</td><td>Verify, Purchase, Void, Refund (online and offline)</td></tr>
  <tr><td>Supported payment types</td><td>Credit cards, local card brands (Tarjeta Naranja), Apple Pay, Google Pay, Direct Debit: ACH and SEPA</td></tr>
  <tr><td>Supported card brands</td><td>Visa, Mastercard, Discover, Union Pay, JCB, Diners Club, American Express (most currencies). Tarjeta Naranja on ARS only.</td></tr>
  <tr><td>Gateway-specific 3DS2 supported</td><td>Yes — depends on WorldPay configuration. Recurly.js required in certain cases.</td></tr>
  <tr><td>Card on file supported</td><td>Yes</td></tr>
  <tr><td>Regions</td><td>Global, with focus on UK/EU, Argentina, Brazil, Chile, Colombia, Costa Rica, El Salvador, Guatemala, Mexico, Ecuador, Panama, Paraguay, Uruguay, Honduras, and Peru.</td></tr>
  <tr><td>Currencies</td><td><strong>ARS</strong> (Visa, MC, Amex, Discover, JCB, Diners Club, Tarjeta Naranja) · <strong>USD</strong> (ACH) · <strong>EUR</strong> (SEPA) · <strong>All others</strong>: ANG, AUD, BRL, CAD, CHF, CLP, CNY, COP, CZK, DKK, GBP, HKD, HRK, HUF, ILS, INR, ISK, JPY, KRW, KES, MXN, MYR, NOK, NZD, PHP, PLN, PYG, RUB, SAR, SEK, SGD, THB, TRY, TWD, UYU, VEF, ZAR, and more.</td></tr>
</table>

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Online refunds</strong> WorldPay has enabled Online Refund Authorization, which allows banks to decline refund attempts in real time. If a refund is declined, resubmit it or resolve it with your customer directly. Review your Refund Invoice settings to avoid unintended behavior. See <a href="https://docs.recurly.com/docs/credit-invoices#/4-handling-failed-refunds" target="_blank">handling failed refunds</a> for details.</div>
</div>

<div class="rp-callout rp-callout-tip">
  <div><strong><i class="fa-solid fa-lightbulb" aria-hidden="true"></i> Tip</strong> Before going live, see Recurly's <a href="https://docs.recurly.com/docs/how-to-test-your-gateway" target="_blank">guide to testing gateway configurations</a> to verify your payment setup is working correctly.</div>
</div>

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> New MasterCard and ELO Customer Authentication Compliance</strong>MasterCard is implementing additional customer authentication requirements that will require merchants to enforce supplying customer data including:

<ul class="rp-list">
<li>At least one contact detail: cardholder name, email address or phone number</li>
<li>At least one address: billing address or shipping address</li>
<li>The customer’s IP address</li>
</ul>

Additionally, ELO in Brazil is implementing requirements to pass along the following:

<ul class="rp-list">
<li>Customer Email address, Telephone number, and Address information</li>
<li>Browser/device information</li>
</ul>

For both card brand requirements, Recurly supports sending the required customer data via several integration paths, and Recurly.js is specifically built to capture customer IP and browser data by design. Consider a move to Recurly.js if you are under the jurisdiction of the above card brand compliance mandates.</div>

</div>

# Credentials

WorldPay WPG requires XML credentials from WorldPay. For SEPA, you'll also need additional information for mandate creation.

**Billing address** — Recurly submits billing address data to WorldPay whenever available. WorldPay requires four fields: Address line 1, City, Postal code, and Country. If any are missing, Recurly uses defaults: city = "city," address line 1 = "address," and country derived from the customer's IP address. If country can't be determined, no billing address is submitted.

**Voids and refunds** — WorldPay processes void ("cancel") and refund order modifications asynchronously. There is a small chance WorldPay may reject a void or refund request between 5 and 45 minutes after receiving it.

<div class="rp-callout rp-callout-tip">
  <div><strong><i class="fa-solid fa-lightbulb" aria-hidden="true"></i> Tax ID reference</strong> For technical details on sending tax IDs such as CUIT, CPF, or CNPJ in your billing info block, see the <a href="https://developers.recurly.com/" target="_blank">Recurly developer documentation</a>.</div>
</div>

# Configuring WorldPay with Recurly

## Step 1: Configure your WorldPay merchant account

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Contact WorldPay to configure your account</h4><p>Reach out to the WorldPay integration team to set up your merchant account for processing and transaction updates.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Allow-list Recurly's IP addresses</h4><p>In the WorldPay portal, authorize Recurly's IP addresses. See the <a href="https://docs.recurly.com/docs/ip-allowlist" target="_blank">IP allowlist documentation</a> for the full list.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Set Capture delay to 1-Day</h4><p>In the WorldPay platform, set the Capture delay setting to <strong>1-Day</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">4</div>
    <div><h4>Configure callback URLs</h4><p>Add your Recurly callback URL in WorldPay for event notifications. Enable all event types — Recurly will use what it needs for asynchronous actions such as invoice updates and Direct Debit status updates.</p>
    <p><strong>Standard:</strong> <code>https://callbacks.recurly.com/worldpay/YOUR_SUBDOMAIN</code><br /><strong>EU data centers:</strong> <code>https://callbacks.eu.recurly.com/worldpay/YOUR_SUBDOMAIN</code></p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">5</div>
    <div><h4>Enable MOTO permissions (if applicable)</h4><p>If you're processing MOTO transactions, contact your WorldPay representative to enable the <code>dynamicInteractionType</code> parameter on your account. Without this, MOTO transactions will fail.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">6</div>
    <div><h4>Enable local currencies and Zero Dollar Authorizations</h4><p>Confirm your WorldPay account supports the local currencies you plan to accept and that ZDA is enabled where needed. Note: Tarjeta Naranja does not support ZDA — verifications for this card brand use a $1.00 charge instead.</p></div>
  </div>
</div>

## Step 2: Configure WorldPay in Recurly

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Add the gateway</h4><p>In Recurly, go to <strong>Payment Gateways → Add Payment Gateway</strong> and select <strong>WorldPay</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Enter your credentials</h4><p>Input your WorldPay <strong>Merchant Code</strong>, XML <strong>Username</strong>, and XML <strong>Password</strong>. These are not your WorldPay account login credentials.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Configure SEPA (if applicable)</h4><p>Enter your WorldPay <strong>Mandate Prefix</strong> and <strong>Merchant ID</strong> for SEPA and ensure EUR is enabled as an accepted currency.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">4</div>
    <div><h4>Configure 3DS (if applicable)</h4><p>If using 3D Secure, enter your <strong>Issuer ID</strong>, <strong>Unit ID</strong>, <strong>HMAC Key</strong>, and <strong>Challenge URL</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">5</div>
    <div><h4>Set currencies and card types</h4><p>Select the currencies and card brands you plan to accept. Optionally, designate which card types should use Zero Dollar Authorizations.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">6</div>
    <div><h4>Save and test</h4><p>Click <strong>Add Payment Gateway</strong>, then use the <strong>Test Configuration</strong> option to confirm Recurly can communicate with WorldPay successfully.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">7</div>
    <div><h4>Enable Direct Debit retries (SEPA/ACH)</h4><p>In Recurly, go to <strong>Configuration → Payment Settings</strong> and enable <a href="https://docs.recurly.com/recurly-subscriptions/docs/sepa-retries#/" target="_blank">Direct Debit retries</a> so failed SEPA and ACH payments due to insufficient funds are retried automatically.</p></div>
  </div>
</div>

## Step 3: Enable global and regional currencies

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Enable currencies in Recurly</h4><p>In Recurly, go to <strong>Configuration → Currencies</strong> and enable the currencies relevant to your markets — ARS for Argentina, EUR for SEPA, USD for ACH, and any other applicable currencies.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Enable Tarjeta Naranja (ARS/Argentina)</h4><p>In your WorldPay gateway settings in Recurly, toggle on Tarjeta Naranja as an accepted card brand. This card is available on ARS currency only.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Enable ACH (if applicable)</h4><p>Confirm USD is enabled in Recurly, at WorldPay, and in your gateway configuration. Verify that NACHA pre-verification and fraud flows are enabled at WorldPay.</p></div>
  </div>
</div>

## Step 4: Configure tax ID collection (LATAM)

For Argentine and other LATAM transactions, collect the customer's tax ID (e.g., CUIT) during the initial transaction. Include the <code>tax_identifier</code> and <code>tax_identifier_type</code> fields in your transaction payload. If using a tax ID type other than CUIT, CPF, or CNPJ, send the value without a type definition.

## Step 5: Test and go live

Test the full setup rigorously — including regional payment methods, tax ID submission, and any Direct Debit flows — before switching to production.

# FAQs

<Accordion title="Why is my WorldPay refund failing?">
  WorldPay supports Online Refund Authorization, which allows banks to decline refund attempts in real time. This became standard across all WorldPay accounts in May 2025. A refund can be declined if the customer's account is closed or the bank doesn't approve the refund. If this happens, coordinate with your customer to return funds through another method.
</Accordion>

<Accordion title="Why is my ACH transaction failing?">
  ACH bank accounts go through a NACHA-required fraud and accuracy check before being added to Recurly. If a customer is updating a bank account on file or signing up for a subscription and the transaction fails, a fraud check at WorldPay likely didn't pass — contact WorldPay for details and have the customer provide a different payment method.

  ACH transactions that have been scheduled or approved can also fail later due to bank processing times. For failures due to insufficient funds or closed accounts, Recurly can retry automatically when you enable <a href="https://docs.recurly.com/recurly-subscriptions/docs/sepa-retries#/" target="_blank">Direct Debit retries in Payment Settings</a>. Recurly retries ACH and SEPA payments only when the failure reason is insufficient funds.
</Accordion>
