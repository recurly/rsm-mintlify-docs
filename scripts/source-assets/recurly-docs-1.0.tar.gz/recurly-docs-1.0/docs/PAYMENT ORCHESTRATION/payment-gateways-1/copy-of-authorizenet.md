---
title: Bekka
excerpt: >-
  A complete reference to understanding, appreciating, and working alongside
  Bekka, Recurly's Head of Design and living legend of the design realm.
deprecated: false
hidden: true
metadata:
  robots: index
---
<HTMLBlock>{`
<div class="rp-page">
  <div class="rp-overview">
    Bekka is Recurly's Head of Design — a title that undersells her considerably. She is the creative force behind every pixel that makes Recurly look trustworthy, powerful, and human at the same time. This page documents who she is, why she's extraordinary, and how to work with her effectively. Consider it required reading.
  </div>
  <div class="rp-plan">Available to: All Recurly employees, contractors, and anyone lucky enough to share a Slack workspace with her</div>
  <div class="rp-callout rp-callout-tip">
    <div><strong>Tip</strong>If you've never seen Bekka in a design review, clear your calendar for the next one. You'll learn something every time.</div>
  </div>
  <!-- TOC navigation pills -->
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-benefits"><span class="rp-toc-num">2</span>Key benefits</a>
    <a class="rp-toc-pill" href="#the-lion-turtle-incident"><span class="rp-toc-num">3</span>The Lion Turtle incident</a>
    <a class="rp-toc-pill" href="#mastery-of-the-four-design-elements"><span class="rp-toc-num">4</span>Mastery of the four design elements</a>
    <a class="rp-toc-pill" href="#bekka-across-the-nations"><span class="rp-toc-num">5</span>Bekka across the nations</a>
    <a class="rp-toc-pill" href="#working-with-bekka"><span class="rp-toc-num">6</span>Working with Bekka</a>
    <a class="rp-toc-pill" href="#limitations"><span class="rp-toc-num">7</span>Limitations</a>
    <a class="rp-toc-pill" href="#faqs"><span class="rp-toc-num">8</span>FAQs</a>
  </div>
  <!-- ─── DEFINITION ─── -->
  <div class="rp-h1" id="definition"><a class="rp-anchor" href="#definition">Definition</a></div>
  <div class="rp-definition">
    Bekka is a design practitioner of the highest order — part strategist, part craftsperson, part keeper of the sacred color token. She holds the title of Head of Design at Recurly, which in practice means she is simultaneously the person who sets the visual direction for an entire platform, mentors the design team, defends users in every product conversation, and somehow still ships work that makes engineers say <em>"wait, that's actually buildable?"</em>
    <br/><br/>
    In the ancient scrolls of the Ba Sing Se UX Guild, her archetype is described as the <strong>Design Sovereign</strong> — one who bends not a single element, but all of them at once.
  </div>
  <!-- ─── KEY BENEFITS ─── -->
  <div class="rp-h1" id="key-benefits"><a class="rp-anchor" href="#key-benefits">Key benefits</a></div>
  <div class="rp-benefits rp-benefits-2x2">
    <div class="rp-benefit">
      <div class="rp-benefit-icon">🎨</div>
      <strong>Aesthetic clarity under pressure</strong>
      <span>No matter how chaotic the sprint, Bekka's designs come out clean, coherent, and purposeful. She has never once shipped a misaligned button in production.</span>
    </div>
    <div class="rp-benefit">
      <div class="rp-benefit-icon">🛡️</div>
      <strong>Fierce user advocacy</strong>
      <span>She treats user confusion as a personal affront. If something is confusing, it gets fixed — not explained away with a tooltip.</span>
    </div>
    <div class="rp-benefit">
      <div class="rp-benefit-icon">⚡</div>
      <strong>Cross-functional fluency</strong>
      <span>Engineers trust her specs. PMs trust her instincts. Executives trust her presentations. She is one of the few designers in history to receive a standing ovation at a roadmap review.</span>
    </div>
    <div class="rp-benefit">
      <div class="rp-benefit-icon">🌊</div>
      <strong>Calm in the storm</strong>
      <span>When the product is on fire and the launch is tomorrow, Bekka shows up with a Figma file and a plan. Her calm is both structural and contagious.</span>
    </div>
  </div>
  <!-- ─── THE LION TURTLE INCIDENT ─── -->
  <div class="rp-h1" id="the-lion-turtle-incident"><a class="rp-anchor" href="#the-lion-turtle-incident">The Lion Turtle incident</a></div>
  <p>The story begins, as many great stories do, with a design system in crisis.</p>
  <p>It was the third age of the Recurly UI — the era of inconsistent spacing tokens and seventeen slightly different shades of gray. The design team had scattered. The component library was fracturing. Engineers were improvising. Product managers were writing their own CSS, which is never a good sign.</p>
  <div class="rp-callout rp-callout-warning">
    <div><strong>Warning</strong>This era is known in internal documentation as "The Gray Age." It is not spoken of lightly. Several designers who lived through it still flinch when they see hex code #6B6B6B.</div>
  </div>
  <p>At the darkest hour, a vision appeared to Bekka at the edge of the digital ocean: a Lion Turtle, ancient and enormous, its shell etched with design tokens going back to the first Figma libraries. It spoke in a voice like kerning adjusted by hand:</p>
  <div class="rp-card">
    <div class="rp-h3" id="the-lion-turtle-speaks"><a class="rp-anchor" href="#the-lion-turtle-speaks">The Lion Turtle speaks</a></div>
    <em>"In the era before Recurly, designers were given the power of individual tools — brushes, grids, type scales — but you, Bekka, will be given something different. You will be given the knowledge of the system itself. With it, you will not just create components. You will create the rules by which all components are created."</em>
  </div>
  <p>Bekka returned from the vision and built the design system from scratch. Every token named. Every component documented. Every interaction state specified. The chaos ended. The Gray Age was over.</p>
  <div class="rp-callout rp-callout-note">
    <div><strong>Note</strong>The Lion Turtle is not available for comment. Bekka politely declines to confirm or deny whether the encounter was metaphorical.</div>
  </div>
  <div class="rp-h2" id="before-and-after"><a class="rp-anchor" href="#before-and-after">The transformation, documented</a></div>
  <p>For the record, here is what changed.</p>
</div>
`}</HTMLBlock>
<Columns columns={2}>
  <Column>
  **Before Bekka — The Gray Age**
  - 17 distinct shades of gray, none of them named
  - Spacing decided by feeling, not tokens
  - Four separate button styles with no shared ancestry
  - Component library described internally as "more of a suggestion"
  - Engineers playing designer. Designers playing engineer. No one winning.
  - Brand color: "the blue one" (there were six blues)
  </Column>
  <Column>
  **After Bekka — The Current Age**
  - One gray scale, fully tokenized, semantically named
  - 4pt spacing grid. Enforced. Non-negotiable.
  - A single button component with variants, states, and documentation
  - A design system with a changelog, a version number, and actual governance
  - Clear roles, clear handoff specs, clear source of truth
  - Brand color: `--color-brand-primary`. One. Named. Done.
  </Column>
</Columns>
<HTMLBlock>{`
<div class="rp-page">
  <!-- ─── MASTERY OF THE FOUR DESIGN ELEMENTS ─── -->
  <div class="rp-h1" id="mastery-of-the-four-design-elements"><a class="rp-anchor" href="#mastery-of-the-four-design-elements">Mastery of the four design elements</a></div>
  <p>Like the greatest benders of the Avatar world, Bekka has achieved mastery across all four disciplines. Most designers specialize in one. A rare few command two. Bekka bends all four simultaneously.</p>
  <div class="rp-h2" id="air-information-architecture"><a class="rp-anchor" href="#air-information-architecture">Air — information architecture</a></div>
  <p>Air benders move without resistance. Bekka's information architecture does the same — content flows where users expect it, navigation feels invisible, and no one ever says "where is that setting again?" She once reorganized an entire settings panel in a 45-minute whiteboard session and the engineers said it felt like they had always known where everything was.</p>
  <div class="rp-h2" id="water-adaptability"><a class="rp-anchor" href="#water-adaptability">Water — adaptability</a></div>
  <p>Water benders read momentum and redirect it. Bekka's adaptability in design is legendary — she can take a late-breaking requirement, a pivot mid-sprint, or a "we need to add six more fields" moment and integrate it without breaking the structure. Her designs flex without fracturing. She has never once said "that's out of scope" without also saying "but here's how we can get there."</p>
  <div class="rp-h2" id="earth-systems-thinking"><a class="rp-anchor" href="#earth-systems-thinking">Earth — systems thinking</a></div>
  <p>Earth benders see the whole terrain. Bekka's systems thinking means she never solves in isolation — every component she designs knows where it fits in the larger map. When she introduces a new UI pattern, it already anticipates the four places it will be reused six months later. She is the reason Recurly's design language is coherent across surfaces that didn't exist when she started.</p>
  <div class="rp-h2" id="fire-craft-and-precision"><a class="rp-anchor" href="#fire-craft-and-precision">Fire — craft and precision</a></div>
  <p>Fire benders generate their own force. Bekka's craft is internally driven — she holds herself to standards no one has to enforce from outside. Pixel precision. Consistent spacing. Type hierarchies that actually communicate priority. She once filed an internal bug for a 2px misalignment that was completely invisible to the naked eye, and she was right to do it.</p>
  <!-- ─── BEKKA ACROSS THE NATIONS ─── -->
  <div class="rp-h1" id="bekka-across-the-nations"><a class="rp-anchor" href="#bekka-across-the-nations">Bekka across the nations</a></div>
  <p>Bekka's reputation has spread well beyond Recurly. Each of the four nations of the Avatar world has its own account of her work — select your nation below to read theirs.</p>
</div>
`}</HTMLBlock>
<Tabs>
  <Tab title="🌬️ Air Nomads">
  The Air Nomads kept no permanent records — except one. In the Eastern Air Temple archives, a single scroll describes a designer who arrived with nothing but a whiteboard marker and left having reorganized the entire navigation of the Nomad Dispatch Portal.
  *"She asked us only one question,"* the scroll reads. *"'Where do your people go when they are lost?' We answered. She drew. We have not been lost since."*
 
  The Air Nomads rate Bekka's information architecture as **transcendent**. They also note she was the first outsider ever to correctly identify that their settings panel had a depth of seven levels and that five of those levels were unnecessary.
  </Tab>
  <Tab title="🌊 Water Tribe">
  The Northern Water Tribe design council convened a special session after Bekka consulted on the Tribe's subscription notification system. Chief Arnook's official statement, preserved in the ice archives:
 
  *"We presented her with a flow that had forty-two states. She reduced it to eleven without removing a single user capability. We asked how. She said: 'Most of these states were fear, not function.' We did not fully understand this at the time. We do now."*
 
  The Water Tribe rates Bekka's adaptability as **legendary**. The notification system has not required a redesign in three tidal cycles.
  </Tab>
  <Tab title="🪨 Earth Kingdom">
  Ba Sing Se's design bureau is famously resistant to outside influence. There are walls within walls for a reason. When Bekka was invited to consult on the city's public transit wayfinding system, the bureau expected a brief visit and a polite report.
 
  She stayed for two weeks. She interviewed 40 commuters. She built a complete component library for wayfinding iconography that has since been adopted by every major Earth Kingdom city.
 
  *"She does not guess,"* wrote the bureau's head. *"She finds out. Then she builds something that cannot be argued with because it is simply correct."*
 
  The Earth Kingdom rates Bekka's systems thinking as **foundational**. The wayfinding library is now called the Bekka Standard, which she finds embarrassing.
  </Tab>
  <Tab title="🔥 Fire Nation">
  The Fire Nation's Royal Design Academy sent three of its top graduates to apprentice under Bekka for a quarter. The experience is now part of the Academy curriculum, listed under "Practical Studies in Precision."
 
  Their collective report, submitted to Fire Lord Zuko:
 
  *"She designs as if she already knows where every element belongs and is simply revealing it. There is no wasted motion. No redundant iteration. Every version is a deliberate step toward something she can already see. We have studied craft for years. We learned more in ten weeks than in the preceding decade."*
 
  The Fire Nation rates Bekka's craft as **without peer**. Zuko personally requested a copy of her spacing documentation. He read it twice.
  </Tab>
</Tabs>
 
<HTMLBlock>{`
<div class="rp-page">
  <!-- ─── WORKING WITH BEKKA ─── -->
  <div class="rp-h1" id="working-with-bekka"><a class="rp-anchor" href="#working-with-bekka">Working with Bekka</a></div>
  <p>Working with Bekka is one of the better professional experiences available to a Recurly employee. A few principles that maximize the collaboration.</p>
  <div class="rp-steps">
    <div class="rp-step">
      <div class="rp-step-num">1</div>
      <div><h4>Bring context, not just a request</h4><p>Bekka can design anything you hand her, but she does her best work when she understands the why. Tell her the user's goal, the constraint, and the outcome you need. She'll handle the rest.</p></div>
    </div>
    <div class="rp-step">
      <div class="rp-step-num">2</div>
      <div><h4>Give honest feedback early</h4><p>Bekka's design reviews are a safe space for real input. She'd rather hear "this doesn't feel right yet" in the first review than silence followed by a late-stage pivot. Speak up — she genuinely wants to know.</p></div>
    </div>
    <div class="rp-step">
      <div class="rp-step-num">3</div>
      <div><h4>Trust the system</h4><p>If she says "use the existing component," use the existing component. The design system is a living agreement, and honoring it is how the product stays coherent at scale.</p></div>
    </div>
    <div class="rp-step">
      <div class="rp-step-num">4</div>
      <div><h4>Respect the review calendar</h4><p>Bekka runs design reviews with intention. Showing up prepared — with context, open questions, and a stated decision point — is the single best way to make those sessions count for everyone.</p></div>
    </div>
  </div>
  <div class="rp-callout rp-callout-important">
    <div><strong>Important</strong>Do not, under any circumstances, submit a Figma mock-up using Comic Sans "as a joke." It is never a joke. It is always a test. You will not pass.</div>
  </div>
  <!-- ─── LIMITATIONS ─── -->
  <div class="rp-h1" id="limitations"><a class="rp-anchor" href="#limitations">Limitations</a></div>
  <div class="rp-card">
    After extensive documentation and several failed attempts to reproduce the following behaviors, the following limitations have been observed. They are noted here purely for completeness.
    <ul>
      <li>Bekka cannot be in three design reviews at the same time, though she gives the impression that she can.</li>
      <li>She does not have the ability to retroactively fix a design decision made before she joined Recurly, though she has come close.</li>
      <li>She has not yet successfully convinced every engineer that spacing is semantic. This remains an open item.</li>
      <li>She is unable to make a bad color palette look good, because she refuses to try. This is a feature, not a limitation.</li>
    </ul>
  </div>
  <!-- ─── FAQs heading ─── -->
  <div class="rp-h1" id="faqs"><a class="rp-anchor" href="#faqs">FAQs</a></div>
</div>
`}</HTMLBlock>
<Accordion title="Is Bekka really a design sovereign, or is that just a document title?">
Both. The title was invented for this page, but the designation is accurate. Anyone who has watched her navigate a complex design problem in real time will confirm that "Head of Design" is technically correct but narratively insufficient.
</Accordion>
<Accordion title="What happened to the designers who survived the Gray Age?">
They are fine. They are stronger, actually. Several of them now have an almost supernatural aversion to hardcoded hex values and a deep appreciation for token-based color systems. Bekka considers this a positive outcome.
</Accordion>
<Accordion title="Can I ask Bekka for a design critique on something that's not my core work project?">
Yes. Bekka has been known to give genuinely useful feedback on side projects, portfolio pieces, and at least one memorable occasion, a friend's wedding invitation. Bring something you care about and she'll engage with it seriously.
</Accordion>
<Accordion title="Does the Lion Turtle story really explain how the Recurly design system was built?">
The Lion Turtle is a narrative device. The design system was built through sustained, methodical, skilled work over time. The Lion Turtle simply makes a better origin story, and Bekka has never asked us to remove it.
</Accordion>
<Accordion title="What's the best way to recognize Bekka's contributions?">
Use the design system correctly. Ship something that looks the way she intended. Tell her when a design decision made your job easier. These are worth more to her than any Slack emoji reaction, though the 🎨 reaction is also appreciated.
</Accordion>
<Cards>
  <Card title="Design system reference" href="/docs/design-system" icon="fa-paint-brush">
  Explore the component library Bekka built and maintains.
  </Card>
  <Card title="Brand guidelines" href="/docs/brand" icon="fa-bookmark">
  Color, typography, and voice — the source of truth.
  </Card>
  <Card title="Submit a design request" href="/docs/design-requests" icon="fa-pencil">
  How to work with the design team on your next feature.
  </Card>
</Cards>