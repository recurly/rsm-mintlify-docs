---
title: Amazon Pay V2
excerpt: >-
  Integrate Amazon Pay V2 with Recurly using Recurly.js to let customers
  subscribe and purchase using payment methods already stored in their Amazon
  account.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
<div class="rp-page">
  <div class="rp-overview">Amazon Pay V2 lets customers subscribe or make purchases using the payment methods already stored in their Amazon account — no separate card entry required. V2 integrates directly into Recurly.js (no external Amazon library needed), supports 3DS in the UK and EU, and includes charge permission ID management for ongoing renewals.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-details"><span class="rp-toc-num">2</span>Key details</a>
    <a class="rp-toc-pill" href="#setup"><span class="rp-toc-num">3</span>Setup</a>
    <a class="rp-toc-pill" href="#integration"><span class="rp-toc-num">4</span>Integration</a>
    <a class="rp-toc-pill" href="#subscription-management"><span class="rp-toc-num">5</span>Subscription management</a>
    <a class="rp-toc-pill" href="#migrating-from-amazon-pay-v1"><span class="rp-toc-num">6</span>Migrating from V1</a>
    <a class="rp-toc-pill" href="#faqs"><span class="rp-toc-num">7</span>FAQs</a>
  </div>
</div>

### Prerequisites

<ul class="rp-list">
  <li>A Recurly account.</li>
  <li>An Amazon Pay Seller account with <code>https://api.recurly.com/</code> allow-listed in Amazon.</li>
  <li>A webhook endpoint configured in your Amazon Integration Settings — see <a href="#enabling-ipn-notifications--webhooks">Enabling IPN notifications / webhooks</a> below.</li>
  <li>Integration requires Recurly.js or Hosted Payment Pages (HPP).</li>
  <li>Currently supported in the US; Europe and UK support coming soon.</li>
</ul>

### Limitations

<ul class="rp-list">
  <li>Shipping addresses cannot be retrieved from Amazon in V2. Shipping address details must be provided to Recurly separately.</li>
  <li>The Amazon Pay V2 sandbox does not fully support testing 3DS flows.</li>
</ul>

# Definition

<div class="rp-definition">Amazon Pay V2 is a payment method integration that allows customers to subscribe or make purchases using payment details already stored in their Amazon account. Unlike V1, V2 integrates directly into Recurly.js — no external Amazon widget library required. V2 also supports full name, email, and billing address retrieval from Amazon via scopes, and enables 3DS and PSD2 compliance for UK and EU transactions.</div>

# Key details

<table class="rp-gw-table">
  <tr class="rp-thead-row"><td>Feature</td><td>Details</td></tr>
  <tr><td>Services that work with Recurly</td><td>One-time purchases and subscriptions</td></tr>
  <tr><td>Supported operations</td><td>Purchase, Refund, Verify, Void</td></tr>
  <tr><td>Supported payment types</td><td><a href="https://www.amazon.com/gp/help/customer/display.html?nodeId=GFBWMNXEPYVJAY9A" target="_blank">See Amazon support</a></td></tr>
  <tr><td>Supported card brands</td><td><a href="https://www.amazon.com/gp/help/customer/display.html?nodeId=GFBWMNXEPYVJAY9A" target="_blank">See Amazon support</a></td></tr>
  <tr><td>Gateway-specific 3DS2 supported</td><td>Yes (UK and EU regions only)</td></tr>
  <tr><td>Card on file supported</td><td>Yes</td></tr>
  <tr><td>Regions</td><td>Everywhere Amazon Pay is supported</td></tr>
  <tr><td>Currencies</td><td>USD, GBP, EUR, DKK, ZAR, SEK, JPY, CHF, NZD, HKD, AUD</td></tr>
</table>

<div class="rp-card">

### Use cases

- Subscriptions and one-time transactions for customers who prefer Amazon Pay
- 3DS support for UK and EU region merchants
- Reaching Amazon's broad customer base with a familiar, trusted checkout experience

</div>

## Regional support

Recurly supports Amazon Pay in the US, as well as the UK and Europe. Within the UK and Europe, 3DS and multi-currency are supported through Recurly.js.

### Europe

EUR, AUD, GBP, DKK, HKD, JPY, NZD, ZAR, SEK, CHF, and USD.

### United Kingdom

GBP, EUR, AUD, DKK, HKD, JPY, NZD, ZAR, SEK, CHF, and USD.

# Setup

## Sign up for (or Sign In to) an Amazon Pay Seller account

To use Amazon Pay, you'll need an Amazon Pay Seller account. Signing up is free. If you already have one, log in to your existing account.

After signing up or signing in, follow Amazon's Getting Started Guide to complete your account configuration:

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Enter your Business Information and URLs</h4><p>Amazon will give you an option to enter details now or 'fill in later'. You must fill them in now to complete onboarding. On this page, add your Business's contact information, as well as Merchant Website, Privacy Policy URLs, and full Recurly subdomain. Add your own website and Recurly subdomain to your Amazon allowed JavaScript origins / redirect URLs. This should be a full URL (https://your-subdomain.recurly.com). You can find your subdomain by logging in to your Recurly site and looking at the URL.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Test your integration</h4><p>Validate your Amazon Pay integration in sandbox mode before going live.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Go live</h4><p>After successful testing, switch your Amazon Pay account to Production mode.</p></div>
  </div>
</div>

<div class="rp-callout rp-callout-important">
  <div><strong><i class="fa-solid fa-circle-exclamation" aria-hidden="true"></i> Important</strong> Make sure you're selecting the correct Amazon Pay tile. If you have a UK or EU Seller account, do not authenticate through the US Amazon Pay tile. When you are on the Amazon UI, do not skip adding details.</div>
</div>

## Enabling IPN notifications / webhooks

Set up your webhook endpoint in Amazon Seller Central before adding the gateway in Recurly.

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Open Integration Settings</h4><p>In your Amazon Seller Central account, click the gear icon in the upper-right navigation and select <strong>Integration Settings</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Add your callback URL</h4><p>Under <strong>Instant Notification Settings</strong>, select <strong>Edit</strong> and enter your callback URL using the format below, replacing <code>YOUR_MERCHANT_SUBDOMAIN</code> with your site subdomain:</p></div>
  </div>
</div>

`https://callbacks.recurly.com/amazon_v2/YOUR_MERCHANT_SUBDOMAIN`

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Save your settings</h4><p>Click <strong>Update</strong> to finalize.</p></div>
  </div>
</div>

## Add the gateway in Recurly

Amazon Pay V2 uses a redirect-based authorization flow to securely obtain processing credentials.

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Select Amazon Pay V2</h4><p>In your Recurly dashboard, navigate to <strong>Configuration → Payment Gateways</strong> and select <strong>Amazon Pay V2</strong>. You'll be redirected to the Amazon Seller Central website that corresponds to your business entity's location.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Authenticate and approve</h4><p>Log in with your Amazon Seller credentials and approve Recurly to process on your behalf. US entities are redirected to the US Seller Central site; UK and EU entities are redirected to the UK/EU Seller Central site.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Return to Recurly</h4><p>After approval, you'll be redirected back to your Recurly dashboard to conduct sandbox transactions or configure for live operations.</p></div>
  </div>
</div>

<div class="rp-callout rp-callout-warning">
  <div><strong><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Warning</strong> Amazon will display a notice that you're being redirected to a specific URL. Do <strong>not</strong> copy and paste that URL — doing so returns a 404 error. Click the <strong>Transfer API Keys</strong> button instead.</div>
</div>

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong> Transactions are not processed in Recurly's sandbox environment. However, Amazon Pay credentials work in both development and production Recurly accounts. To process live transactions, both your Amazon Pay account and your Recurly account must be in production mode.</div>
</div>

# Integration

Once your Amazon Pay account is configured and your Recurly site is set up, integrate Recurly.js into your subscription checkout flow.

<div class="rp-callout rp-callout-important">
  <div><strong><i class="fa-solid fa-circle-exclamation" aria-hidden="true"></i> Important</strong> The Amazon Pay V1 library is not compatible with V2. Use standard Recurly.js functionality for all V2 integrations — do not use the separate Pay with Amazon library. Refer to the latest Recurly.js and Amazon Pay documentation for current integration details.</div>
</div>

Amazon Pay V2 is built into Recurly.js. Interactions follow the standard Recurly.js flow, with the initial Amazon login as the only step that takes customers off your site. After login, customers confirm their payment details and a Charge Permission ID is returned to Recurly and tokenized via Recurly.js. That token is then passed to Recurly's create subscription API as the account's billing information.

For detailed implementation steps, see the <a href="https://recurly.com/developers/reference/recurly-js/#amazon-pay-v2" target="_blank">Amazon Pay V2 Recurly.js documentation</a>.

## Setting the Amazon Pay region

For EU and UK transactions, you must specify a region code in your Recurly.js request (`options.region`). If you omit the region, transactions default to US settings — including USD as the currency — which causes declines on one-time transactions, initial subscriptions, and renewals. See the <a href="https://docs.recurly.com/recurly-subscriptions/docs/amazon-pay-v2-js" target="_blank">Amazon Pay V2 Recurly.js documentation</a> for implementation details.

## Handling 3DS and PSD2 (UK and EU)

UK and EU merchants must incorporate 3DS into their checkout flow to comply with Strong Customer Authentication (SCA) and PSD2 requirements. Amazon Pay V2 uses standard Recurly.js 3DS behaviors. If you're already handling this in your Recurly.js setup, no changes are needed. If not, see the <a href="https://recurly.com/developers/reference/recurly-js/#3d-secure" target="_blank">3DS behaviors in Recurly.js</a> documentation.

## Handling shipping addresses

Amazon Pay V2 does not currently support retrieving shipping addresses from Amazon. For transactions involving physical shipments, prompt customers to enter their shipping address separately before completing checkout.

## Merchant and buyer data

Recurly sends the following additional data to Amazon on subscriptions and transactions:

- **Merchant DBA** as Seller Store Name
- **Transaction description** as Buyer Notes — the plan name for subscriptions, or the invoice/item description for one-time charges

# Subscription management

When a customer checks out with Amazon Pay, they authenticate with their Amazon credentials and confirm their payment details, granting a Charge Permission ID for the subscription. Recurly stores this ID along with relevant Amazon account details and uses it automatically for subsequent renewals.

Customers and merchants can both update billing information:

- **Amazon** — Customers can update or cancel their Charge Permission ID directly from their Amazon account.
- **Recurly** — Use the <a href="https://docs.recurly.com/api/billing-info" target="_blank">update billing info API</a> to apply a new Amazon Charge Permission ID or switch to a different payment method. Customers must re-authenticate through Amazon to update billing via Recurly.js.

## Amazon references in Recurly admin

In the Recurly Admin panel under **Billing Info** on an Account Details page, you can view Amazon Pay transaction details for customer service and reporting, including:

- Charge Permission ID
- Capture Amount
- Transaction Status (at Amazon)
- Creation, updated, and expiration timestamps
- Charge ID
- Currency code
- Capture Now indicator

## Testing your implementation

To test transactions, use a secondary Amazon account — transactions cannot be processed through your own Seller Central account.

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong> The Amazon Pay V2 sandbox does not fully support testing 3DS flows.</div>
</div>

# Migrating from Amazon Pay V1

Amazon Pay V1 used external widgets, a separate library, and Billing Agreement IDs. V2 integrates directly into Recurly.js — no external library or widgets are needed, and Billing Agreement IDs are replaced by Charge Permission IDs.

For a full migration guide, see the <a href="https://recurly.com/developers/reference/recurly-js/#amazon-pay-v2" target="_blank">Amazon Pay V2 Recurly.js documentation</a>.

**Existing V1 subscriptions** can transition to V2 automatically when the V2 gateway is activated, unless a specific gateway code was assigned — in that case, a script update is required after activation. HPP one-time and initial subscription transactions switch to V2 automatically once V2 is enabled.

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong> Amazon Pay V2 became available in December 2023.</div>
</div>

# FAQs

<Accordion title="Are Amazon Pay Charge Permission IDs usable across regions?">
  No — Charge Permission IDs are specific to the region where they were created. To switch a user to a different region, you must generate a new Charge Permission ID in that region.
</Accordion>

<Accordion title="Can I retrieve shipping addresses from Amazon Pay V2?">
  Not currently. Shipping addresses must be passed to Recurly via API parameters. This page will be updated if Amazon adds native shipping address support in V2.
</Accordion>

<Accordion title="Are Amazon widgets available in V2?">
  No — Amazon widgets are not supported in Amazon Pay V2. All interactions go through standard Recurly.js flows.
</Accordion>

<Accordion title="Do I need to use the separate Amazon library for V2?">
  No. Amazon Pay V2 is built into Recurly.js, so the separate Pay with Amazon library is not needed and is not supported with V2.
</Accordion>

<Accordion title="There's no consent widget in Amazon Pay V2 — is that expected?">
  Yes. In V2, consent is obtained on the Amazon Pay hosted page, so a separate consent widget is no longer required.
</Accordion>

<Accordion title="Do I need another gateway to access Amazon Pay V2?">
  No — Amazon Pay V2 is a standalone service. No additional gateways or merchant accounts are required outside of Amazon.
</Accordion>

<Accordion title="What should I do if I can't authorize via hosted onboarding?">
  Verify the accuracy of your Amazon Seller Central credentials. For US accounts, confirm your business entity is located in the United States. For UK or EU accounts, confirm your entity is in the UK or an EU country, and that you're authenticating through the correct regional tile.
</Accordion>

<Accordion title="Which currencies are available for Amazon Pay by region?">
  In the US, only USD is available. In the UK, GBP is available. In the EU, EUR is available. Full multi-currency support for the UK and EU is listed in the <a href="#regional-support">Regional support</a> section above.
</Accordion>

<Accordion title="Amazon's hosted onboarding isn't completing / the gateway isn't appearing in my list of gateways. What can I do?">
  Ensure that you haven't 'skipped' filling in merchant details including your website, privacy policy URL, and your full Recurly site domain (https\://your-domain.recurly.com) on Amazon's UI when onboarding. If you have chosen 'fill in details later', this bypasses proper onboarding and will not work.
</Accordion>

<br />
