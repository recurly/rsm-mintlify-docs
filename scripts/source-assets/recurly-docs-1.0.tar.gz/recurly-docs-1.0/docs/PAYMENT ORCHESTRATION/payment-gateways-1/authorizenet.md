---
title: Authorize.net
excerpt: >-
  Connect Authorize.net to Recurly to process credit card transactions —
  configure your API credentials, AVS, CVV, and card type settings in a few
  steps.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
<div class="rp-page">
  <div class="rp-overview">Authorize.net is a well-established payment gateway that enables secure credit card processing between your payment portal and card networks. This guide walks you through connecting Authorize.net to Recurly, configuring fraud settings, and going live. For pricing and new account signup, visit <a href="https://www.authorize.net/" target="_blank">Authorize.net</a>.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-details"><span class="rp-toc-num">2</span>Key details</a>
    <a class="rp-toc-pill" href="#gateway-setup-guide"><span class="rp-toc-num">3</span>Gateway setup guide</a>
    <a class="rp-toc-pill" href="#fraud-settings"><span class="rp-toc-num">4</span>Fraud settings</a>
  </div>
</div>

### Limitations

<ul class="rp-list">
  <li><strong>Limited decline detail</strong> — Authorize.net's API responses are generic on declines. Recurly uses decline reasons, merchant-advice-code logic, and processor/issuer/network responses to inform retry decisions. Following Auth.net best practices, Recurly does not retry renewal declines where Auth.net recommends treating the decline as "hard" — this includes expired cards and lost or stolen cards. See <a href="https://support.authorize.net/knowledgebase/Knowledgearticle/?code=000001111" target="_blank">Auth.net's gateway response knowledgebase article</a> for details.</li>
  <li><strong>Fraud review flow not supported</strong> — If you're using Authorize.net's fraud monitoring, be aware the gateway can void or invalidate transactions that were initially approved. Monitor those external systems independently, as any cancellations made outside Recurly won't be visible within the platform.</li>
  <li><strong>Gateway Specific NTIDs on File</strong> — Authorize.net does not return raw NTIDs, but instead, their own value that we store. If you need to migrate away from Authorize.net to another platform, even within Recurly, contact Recurly Tech Support to initiate an NTID migration conversation with our team and Auth.net directly.</li>
</ul>

# Definition

<div class="rp-definition">Authorize.net is a payment gateway that facilitates secure credit card transactions between your payment portal and card processors. It includes built-in fraud prevention tools, supports a range of card brands, and integrates with Recurly to power recurring subscriptions and one-time payments.</div>

# Key details

<table class="rp-gw-table">
  <tr class="rp-thead-row"><td>Feature</td><td>Details</td></tr>
  <tr><td>Services that work with Recurly</td><td>Recurring subscriptions, payments (eCommerce and <a href="https://docs.recurly.com/recurly-subscriptions/docs/moto-transactions#/" target="_blank">MOTO</a>)</td></tr>
  <tr><td>Supported operations</td><td>Anti-Fraud, Authorize and Capture, Purchase, Refund, Verify, Void</td></tr>
  <tr><td>Supported payment types</td><td>Credit card</td></tr>
  <tr><td>Supported card brands</td><td>Visa, Mastercard, Amex, Discover, JCB, Diners Club, Union Pay</td></tr>
  <tr><td>Gateway-specific 3DS2 supported</td><td>No — Authorize.net does not support 3DS</td></tr>
  <tr><td>Card on file supported</td><td>Yes</td></tr>
  <tr><td>Regions</td><td>Worldwide</td></tr>
  <tr><td>Currencies</td><td>AUD, CAD, EUR, GBP, NZD, PLN, and USD</td></tr>
</table>

# Gateway setup guide

## Step 1: Sign up for an Authorize.net account

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Create your account</h4><p>Go to the <a href="https://www.authorize.net/sign-up/" target="_blank">Authorize.net signup page</a> and complete the application form with your business details.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Log in</h4><p>After approval, log in to your Authorize.net account to proceed with credential retrieval.</p></div>
  </div>
</div>

## Step 2: Get your API Login ID and Transaction Key

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Navigate to API credentials</h4><p>In your Authorize.net account, go to <strong>Account → Settings → API Credentials &amp; Keys</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Note your API Login ID</h4><p>Copy your API Login ID — you'll need it when configuring Recurly.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Generate a Transaction Key</h4><p>If you don't have a Transaction Key or need a new one, select <strong>New Transaction Key</strong>. You can optionally disable previously created keys using the checkbox in your Auth.net dashboard.</p></div>
  </div>
</div>

<div class="rp-callout rp-callout-warning">
  <div><strong><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Warning</strong> Checking "Disable Old Transaction Key Immediately" takes effect the moment you click Submit and will instantly break any active Auth.net integrations. Only select this option if you've been explicitly instructed to do so for fraud-prevention or security purposes.</div>
</div>

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">4</div>
    <div><h4>Submit and retrieve your key</h4><p>Click <strong>Submit</strong>. In some cases, Auth.net will email you a PIN to verify the request — enter that PIN in the field provided to complete key generation.</p></div>
  </div>
</div>


<Image src="https://files.readme.io/2c5f346-image.png" align="center" width="40%" border={true} />


<br />


<Image src="https://files.readme.io/cdbb55e-image.png" align="center" width="40%" border={true} />


<br />


<Image src="https://files.readme.io/4976dc3-image.png" align="center" width="75%" border={true} />


## Step 3: Configure Authorize.net in Recurly

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Open Payment Gateways</h4><p>In Recurly, navigate to <strong>Configuration → Payment Gateways</strong> and select <strong>Add a Gateway → Authorize.net</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Enter your API credentials</h4><p>Input your API Login ID and Transaction Key from Authorize.net.</p></div>
  </div>
</div>


<Image src="https://files.readme.io/060ff09-image.png" align="center" width="75%" border={true} />


<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Select accepted card types</h4><p>Choose which card types you're approved to accept. Contact your Auth.net representative if you're unsure which card brands apply to your account.</p></div>
  </div>
</div>


<Image src="https://files.readme.io/73811e6-image.png" align="center" width="75%" border={true} />


<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">4</div>
    <div><h4>Set accepted currencies</h4><p>Select the currencies your Auth.net gateway is approved to accept.</p></div>
  </div>
</div>


<Image src="https://files.readme.io/c4a227a-image.png" align="center" width="40%" border={true} />


<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">5</div>
    <div><h4>Configure zero-dollar authorizations (ZDA)</h4><p>Select which card types you'd like to accept ZDA-style transactions for. ZDA transactions verify a card's validity without charging any amount.</p></div>
  </div>
</div>


<Image src="https://files.readme.io/b4559de-image.png" align="center" width="75%" border={true} />


<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">6</div>
    <div><h4>Save your configuration</h4><p>Click <strong>Add Payment Gateway</strong> to save. If you're editing an existing setup, this button will read <strong>Update Payment Gateway</strong>.</p></div>
  </div>
</div>

## Step 4: Set up Address Verification Service (AVS)

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Open Payment Settings</h4><p>In Recurly, navigate to <strong>Configuration → Payment Settings</strong> and scroll to the <strong>Address Verification Check</strong> section.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Choose your AVS rules</h4><p>Select <strong>Enabled</strong> (default) or <strong>Disabled</strong>. When enabled, transactions where the provided address doesn't match the issuer's records will be rejected.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Save your changes</h4><p>Click <strong>Save Changes</strong>. Note that AVS settings apply to all supported gateways, not just Authorize.net.</p></div>
  </div>
</div>

## Step 5: Enable Card Code Verification (CVV)

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Open Payment Settings</h4><p>Navigate to <strong>Configuration → Payment Settings</strong> and scroll to the <strong>Credit Card Verification Code Check</strong> section.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Enable CVV verification</h4><p>Set the radio button to <strong>Enabled</strong>. Invalid or mismatched CVV submissions will be rejected based on issuer feedback.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Save your changes</h4><p>Click <strong>Save Changes</strong>. Like AVS, these settings apply to all supported gateways.</p></div>
  </div>
</div>


<Image src="https://files.readme.io/9306094-image.png" align="center" width="75%" border={true} />


## Step 6: Test your integration

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Run a configuration test</h4><p>In Recurly, go to <strong>Configuration → Payment Gateways → Authorize.net</strong> and click <strong>Test Configuration</strong>.</p></div>
  </div>
</div>


<Image src="https://files.readme.io/f5ff63a-image.png" align="center" width="75%" border={true} />


If your API Login ID and Transaction Key are correct, you'll see a confirmation message.

## Step 7: Go live

Once the configuration test passes, you're ready to accept real transactions. Monitor your transactions in both Recurly and Authorize.net to confirm everything is running as expected.

<div class="rp-callout rp-callout-tip">
  <div><strong><i class="fa-solid fa-lightbulb" aria-hidden="true"></i> Tip</strong> For specific questions about your integration, contact your Authorize.net representative or <a href="mailto:support@recurly.com">Recurly Support</a>. Always ensure PCI compliance when handling sensitive card data.</div>
</div>

# Fraud settings

## Address Verification Service (AVS)

AVS works well for US-based customers — US zip codes are numeric and match cleanly. However, many international postal codes contain letters, which causes AVS zip code matching to fail. If you accept payments from international customers, Recurly recommends configuring AVS to allow transactions where either the street address **or** zip code matches, rather than requiring both.

## Card Code Verification (CVV)

When a new subscription is created or a credit card number is updated, Recurly submits the card number and CVV to Authorize.net together. Per PCI regulations, CVV values can't be stored — so the CVV is used only on that initial request. Submitting the CVV upfront improves approval rates and deters fraud. Banks generally continue to approve subsequent transactions from the same merchant once a clean history has been established.
