---
title: Chase Orbital Gateway Setup
excerpt: ''
deprecated: false
hidden: true
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
Adding a Chase Orbital gateway to Recurly is as simple as adding any other credit card gateway we support, though there may be some additional setup you need to complete on the Chase end to create your account.

1. Confirm that you're being set up for the Chase Orbital "Salem" Platform. Chase offers the Tampa and Salem platforms with the latter being the platform supported by Recurly.
2. Provide Recurly's Submitter ID to Chase if requested. This value is 195670 and should allow Chase to setup your account to work correctly with Recurly. **Note, this value should not be entered on your Recurly site directly as Chase will provide you with your own login credentials once your gateway account is set up.**
