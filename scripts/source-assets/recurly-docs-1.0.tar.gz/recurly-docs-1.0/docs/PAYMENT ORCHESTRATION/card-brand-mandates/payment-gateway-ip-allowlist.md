---
title: Payment Gateway IP Allowlist
excerpt: ''
deprecated: false
hidden: true
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
Many payment gateways require an IP allowlist to verify that a transaction request came from Recurly's servers.

Requests will come from any of the following IP addresses:

50.18.192.88\
52.8.32.100\
52.9.209.233\
50.0.172.150\
52.203.102.94\
52.203.192.184
