---
title: The Recurly Gateway
excerpt: The Recurly Gateway is the only payment gateway designed for subscriptions.
deprecated: false
hidden: true
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
* **Optimize Renewals.** Recurly works to correct many common credit card errors to optimize your recurring revenue.

* **Seamless Integration.** Recurly integration tools greatly reduce your PCI compliance efforts, while remaining invisible to your customers.

## Getting started

To get started, Recurly needs to know how to connect to your merchant account. If you have a merchant account, see the instructions for connecting to an existing merchant account. Otherwise, start with [creating a new merchant account][1].

[1]: https://app.recurly.com/go/configuration/merchant_account/new

### New Merchant Accounts

If you need a merchant account, we can help you get started. Create a Recurly account, or log into your existing account, and the payment gateway setup process will walk you through the application for a new merchant account.

### Existing Merchant Accounts

Recurly can connect to over 400 merchant account banks in the United States. If you have an existing merchant account, please ask your merchant bank to create a TSYS Merchant Profile using Host Capture (Summit platform) for Recurly, version 1.0.

*Your merchant bank account provider will need to contact Recurly with your Authentication code, POS ID, merchant zip code, and approved payment methods.* POS ID should be 15 numbers and Authentication code is 6-10 letters/numbers. Once this data is received, you can expect to have the Recurly gateway configured on your site in one business day.

<i>Important Note: If you ever change address or phone number, make sure to contact your merchant account provider ahead of time to check if you need an updated merchant profile. Changing your address sometimes requires updated merchant account credentials, and if you don't update your Recurly gateway with those credentials you may experience downtime until a new VAR sheet is generated.</i>

## Advanced

### Multi Currency

Today, the Recurly Gateway is only available for US merchants and for US Dollars. You may combine the Recurly Gateway with our multi-currency feature and other gateways to accept additional currencies.

### Merchant Geography

The Recurly Gateway can process credit cards from customers around the world. However, it is only available today for merchants with a US based presence.

### Address Requirements

The Recurly Gateway has no minimum address requirements.

### CVV Requirements

Because the Recurly gateway is designed to handle recurring billing, there is no Card Security Code configuration needed.
