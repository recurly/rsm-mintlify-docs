---
title: Integration best practices
excerpt: >-
  Best practices for configuring, testing, syncing, and building on App
  Management — covering sandbox testing, data migration, external products,
  webhooks, and automated exports.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
<div class="rp-page">
  <div class="rp-overview">This guide collects the best practices for a successful App Management integration — how to configure and test with sandbox data, sync and migrate historical data safely, set up external products, and build reliable workflows on webhooks and the API. Follow these recommendations to avoid the common pitfalls before you go live in production.</div>
  <div class="rp-cost">
    <strong>Additional cost</strong><br/>
    This feature requires an additional cost. Contact <a href="https://recurly.com/demo/contact-sales/" target="_blank">Recurly Sales</a> for pricing details.
  </div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#configuration"><span class="rp-toc-num">1</span>Configuration</a>
    <a class="rp-toc-pill" href="#testing"><span class="rp-toc-num">2</span>Testing</a>
    <a class="rp-toc-pill" href="#data-sync"><span class="rp-toc-num">3</span>Data sync</a>
    <a class="rp-toc-pill" href="#external-products"><span class="rp-toc-num">4</span>External products</a>
    <a class="rp-toc-pill" href="#webhooks-and-api"><span class="rp-toc-num">5</span>Webhooks and API</a>
    <a class="rp-toc-pill" href="#automated-exports"><span class="rp-toc-num">6</span>Automated exports</a>
  </div>
</div>

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong>If you're already successfully viewing Apple or Google subscription lifecycle events within Recurly, you're welcome to skip this guide.</div>
</div>

# Configuration

Before you can use any App Management features — or prepare for migration — you need to configure App Management on your Recurly site. There are step-by-step guides for both the Apple App Store and the Google Play Store on your Recurly subdomain:

<ul class="rp-list">
  <li><a href="https://docs.recurly.com/docs/step-by-step-process#apple-app-store" target="_blank">Apple App Store step-by-step guide</a></li>
  <li><a href="https://docs.recurly.com/docs/step-by-step-process#google-play" target="_blank">Google Play Store step-by-step guide</a></li>
</ul>

# Testing

Before configuring App Management with your production data, we strongly recommend starting with sandbox or test data from each external store. Apple and Google each handle testing differently, and working through all your use cases is crucial to a successful integration.

## Apple

Apple lets developers use a Sandbox Server URL endpoint for testing. If that term is unfamiliar, you may need to set up your Sandbox Server URL in App Store Connect — see Apple's guide on <a href="https://developer.apple.com/help/app-store-connect/configure-in-app-purchase-settings/enter-server-urls-for-app-store-server-notifications/" target="_blank">entering server URLs for App Store Server Notifications</a>, under "Enter a URL for testing App Store Server Notifications in a Sandbox environment." When configuring your sandbox site in Recurly, edit the Sandbox Server URL instead of your Production Server URL.

## Google

Google uses Pub/Sub topics for notifications and only allows notifications to go to one topic. However, you can create a second subscription to the same Pub/Sub topic for testing. Both endpoints, defined in their respective Pub/Sub subscriptions, receive all test and production notifications. Recurly evaluates every payload and denotes whether the notification is production or test, so you'll likely see both flowing to your non-production and production Recurly subdomains. You can read more in the <a href="https://docs.recurly.com/docs/using-app-management#if-we-need-to-test-occasionally-eg-test-a-new-introductory-offer-to-ensure-everything-looks-good-within-recurly-how-can-we-ensure-that-testing-does-not-interfere-with-our-real-production-subscriptions" target="_blank">testing guidance for Using App Management</a>. If you have two apps — for example, one for dev and one for production — you can use your dev app and its Pub/Sub topic on your sandbox site in Recurly for testing.

# Data sync

Once you've configured the external stores to your Recurly site, whether for sandbox or production, they'll sync and send their notifications to Recurly. We don't ignore or delete notifications — we store them until we can successfully process them. To process a notification and associate it with a subscription event from Apple or Google, Recurly needs a unique ID established for each customer, which we look for in the notification from each platform. It's important that these unique IDs are built into your subscription purchasing workflows for Apple and Google. Learn more about <a href="https://docs.recurly.com/docs/app-management#1-uniquely-identifying-your-customers" target="_blank">uniquely identifying your customers</a>.

If you have any historical data within the platforms, you'll need to migrate it into Recurly so we can properly process notifications related to those historical accounts and subscriptions — and generate unique IDs for them if you haven't already.

<div class="rp-callout rp-callout-warning">
  <div><strong><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Warning</strong>Don't turn on the production sync before you're ready for migration. Doing so can lead to issues with the integration.</div>
</div>

When you're live on your production site with App Management, we'll create a shared folder on Google Drive to send you a daily report of unprocessed notifications. Use this report to determine what's needed for those external subscriptions — in most cases, you'll just need to import them.

# External products

External products let Recurly associate your unique Apple and Google subscriptions with a single product in Recurly, so you can track one subscription type whether it's sold on the web or your mobile apps. Learn more about <a href="https://docs.recurly.com/docs/step-by-step-process#creating-external-products" target="_blank">creating external products</a>. If you don't make the association, the purchases go to <a href="https://docs.recurly.com/docs/using-app-management#unassigned-purchases" target="_blank">unassigned purchases</a>.

<div class="rp-callout rp-callout-important">
  <div><strong><i class="fa-solid fa-circle-exclamation" aria-hidden="true"></i> Important</strong>Upgrades and downgrades in Recurly for Apple subscriptions can behave unexpectedly depending on how you set up your Subscription Order in App Store Connect. Make sure your highest upgrade is "1" and your lowest downgrade is the highest number. If numbers are shared between subscriptions, they may be treated as a downgrade when changing between them.</div>
</div>

# Webhooks and API

Recurly follows industry standards and doesn't recommend using webhooks as your source of truth. Webhooks may arrive out of order, be retried, or be sent multiple times due to failed delivery or other server errors. Make sure your endpoint can handle receiving the same notification multiple times and out of order. Webhook payloads can be JSON or XML.

Before processing a webhook, send Recurly a success response — this prevents Recurly from resending it. After sending the receipt, process the webhook.

The API is the most reliable data source, so always make an API call when you receive a webhook you act on, such as one that triggers a customer email. Use the receipt of the webhook to trigger an API query that validates the notification details against current API data. Use the latest version of the API (currently v2021-02-25) to ensure access to the newest features.

<ul class="rp-list">
  <li><a href="https://docs.recurly.com/recurly-subscriptions/docs/overview-webhooks#" target="_blank">Developer Reference</a></li>
  <li><a href="https://docs.recurly.com/docs/webhooks" target="_blank">Recurly Docs</a></li>
  <li><a href="https://docs.recurly.com/docs/api-support-and-webhooks" target="_blank">App Management API and Webhooks docs</a></li>
</ul>

# Automated exports

Automated Exports are a more efficient and reliable way to get data than cycling through resources in the API, and they work well for data warehousing. We offer Automated Exports for External Subscriptions and External Invoices. They can track events triggered in the last 24 hours, keeping your systems no more than a day out of sync.

<ul class="rp-list">
  <li><a href="https://docs.recurly.com/docs/automated-exports" target="_blank">Automated Exports documentation</a></li>
  <li><a href="https://docs.recurly.com/recurly-subscriptions/v2021-02-25/reference/get_export_dates" target="_blank">Automated Exports API</a></li>
</ul>

<br />
