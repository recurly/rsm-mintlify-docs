---
title: Compass Assistant
excerpt: >-
  An extension of your team.  Compass Assistant is an AI-powered chat that can
  help you make smarter, faster decisions to grow your subscription business.
deprecated: false
hidden: false
metadata:
  robots: index
---
<div class="rp-page">
  <div class="rp-overview">✦ Compass Assistant is a conversational AI interface built into Recurly. Ask questions, search records and docs, generate data exports, get code examples, and take action on your subscription configuration — all from a single chat panel on any page.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-details"><span class="rp-toc-num">2</span>Key details</a>
    <a class="rp-toc-pill" href="#faqs"><span class="rp-toc-num">3</span>FAQs</a>
  </div>
</div>

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Feature flag required</strong>Compass Assistant requires the Compass Assistant Chat feature flag to be enabled on your site. All users must have the appropriate permissions within a site where the flag is active. Contact <a href="mailto:support@recurly.com">support@recurly.com</a> to request access.</div>
</div>

# Definition

<div class="rp-definition">Compass Assistant is a network of agents, sub-agents, and tools accessible through a unified chat interface in Recurly. It combines conversational search across product docs, knowledge base articles, developer docs, and records; a Data Agent for generating exports; Ask AI for in-context product questions; agentic AI for taking action on plans, add-ons, and items; and code assistance — all from a single panel.</div>

# Key details

## ✦ Get answers


<Image src="https://files.readme.io/39e9f8c77c227bd9df119c28ed5bc8c3e380734f000763ff36f7da7ba9350a5c-image.png" align="left" width="10%" wrap={true} />


To open Compass Assistant, click the sparkles icon in the bottom right corner of your Recurly site. Start with an example prompt or ask your own question. Ask follow-up questions to refine results, and provide feedback with a thumbs up or thumbs down.

<div style={{position: "relative", paddingTop: "56.25%", marginBottom: "28px", borderRadius: "10px", overflow: "hidden"}}>
  <iframe src="https://fast.wistia.net/embed/iframe/w9q7umxwhk"
    title="Compass Assistant intro"
    allow="autoplay; fullscreen"
    allowtransparency="true"
    frameBorder="0"
    scrolling="no"
    allowFullScreen
    style={{position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: "none"}}></iframe>
</div>

Compass Assistant helps you find what you need through conversational navigation and record search. Search coverage includes:

- Product docs
- Knowledge base articles
- Developer docs
- Code snippets
- Records — including subscriptions, plans, accounts, transactions, invoices, gift cards, items, and users

***

## ✦ Full Screen Assistant

From Recurly's left navigation menu, select Assistant to access the assistant in a full screen view.  Your chat history is available to pick up where you left off or start a new chat.

![Full screen assistant ](https://files.readme.io/25db6cfbfe3ba71f9a572a437f9172e120c8198d21425ca6194dfed05c52c830-image.png)

## ✦ Get data with the Data Agent

The Data Agent is an embedded AI agent within Compass Assistant that lets you generate async exports through natural language. Request an export, specify filters (version, time range, variations), and receive a download link — without navigating export forms or learning export schemas.

<div style={{position: "relative", paddingTop: "56.25%", marginBottom: "28px", borderRadius: "10px", overflow: "hidden"}}>
  <iframe src="https://fast.wistia.net/embed/iframe/a9fdu35qwv"
    title="Data Agent"
    allow="autoplay; fullscreen"
    allowtransparency="true"
    frameBorder="0"
    scrolling="no"
    allowFullScreen
    style={{position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: "none"}}></iframe>
</div>

For an overview of available exports and how to use them, see the <a href="https://docs.recurly.com/recurly-subscriptions/docs/export-overview" target="_blank">Export overview</a>.

***

## ✦ Ask AI


<Image src="https://files.readme.io/25a6c030e6333fee3d795577619a6d3f25e4163790258a7300e7a4a793aa63ee-image.png" align="left" width="50px" border={true} wrap={true} />


Ask AI is an AI-powered assistant built into specific pages in Recurly. It answers questions about product functionality and helps you understand and act on information — without leaving your current workflow.

### Access Ask AI

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Navigate to a supported page</h4><p>Ask AI is currently available on the Accounts, Subscriptions, Invoices, Transactions, and Gift Card Settings pages.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Click Ask AI</h4><p>Select the <strong>Ask AI</strong> button on the page.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Ask your question</h4><p>Compass Assistant opens. Type your question or choose from suggested prompts.</p></div>
  </div>
</div>

**Example prompts:**

- "How do I export my data?"
- "Where can I manage my account settings?"

***

## ✦ Take action

Compass Assistant's agentic AI lets you create or modify plans, add-ons, and items directly from the chat — no manual form navigation required.

<div style={{position: "relative", paddingTop: "56.25%", marginBottom: "28px", borderRadius: "10px", overflow: "hidden"}}>
  <iframe src="https://fast.wistia.net/embed/iframe/i793ouxzm1"
    title="Take action with Compass Assistant"
    allow="autoplay; fullscreen"
    allowtransparency="true"
    frameBorder="0"
    scrolling="no"
    allowFullScreen
    style={{position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: "none"}}></iframe>
</div>

***

## ✦ Code

Compass Assistant knows Recurly's APIs and is ready to help you write code. Ask for code examples, available client libraries, parameter references, and more — and get working code without leaving the app.

<div style={{position: "relative", paddingTop: "56.25%", marginBottom: "28px", borderRadius: "10px", overflow: "hidden"}}>
  <iframe src="https://fast.wistia.net/embed/iframe/21c7i52czs"
    title="Code with Compass Assistant"
    allow="autoplay; fullscreen"
    allowtransparency="true"
    frameBorder="0"
    scrolling="no"
    allowFullScreen
    style={{position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: "none"}}></iframe>
</div>

***

## Get support

Compass Assistant detects when you need help from Recurly's Support team and can connect you directly. You can also click **Chat with Support** at any time.


<Image src="https://files.readme.io/644cdb8042d0893b0f7c8bc859270e09c8f97bfaa5edf8165ae11f6f8e781fc9-support.png" align="center" width="40%" border={true} />


***

## Tips for best results

- **Be specific.** The more context you provide, the more accurate and useful the response.
- **Iterate.** If the first response isn't quite right, refine your question or ask a follow-up.
- **Use natural language.** No special commands — just ask as you would a colleague.

***

## Manage conversations

**New chat** — Select **New chat** to start a fresh conversation with its own context.


<Image src="https://files.readme.io/9fc222b5492f9f11208ab7d4b735f7f8681e2ceb4dcfe6524acfb5e008c91117-image.png" align="center" width="75%" />


**Chat history** — Open **Chat history** to view your previous conversations.


<Image src="https://files.readme.io/8ee919cd7104dbff6e22a10a3413690d1099c312986818b39fa88290fa5179e4-image.png" align="center" width="75%" />


The speech bubble icon indicates a previous conversation. Select any conversation to reload it and continue the thread. Follow-up questions will use that conversation's context.

The s-shaped icon indicates a Compass Skill and to the right is the status of the skill \[Not Started, In Progress, Complete].&#x20;

Results respect your existing permissions — you only see content you already have access to. Your chats are private and visible only to you.

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Permission changes</strong>If a user's permissions become more restrictive, their chat history may contain information they're no longer permitted to view. Contact <a href="mailto:support@recurly.com">support@recurly.com</a> if this is a concern.</div>
</div>

# FAQs

<Accordion title="What AI models power Compass Assistant?">
  Compass Assistant is powered by Google Gemini. Learn more about [Gemini Data Governance](https://cloud.google.com/gemini/docs/discover/data-governance) and [Generative AI Governance](https://cloud.google.com/vertex-ai/generative-ai/docs/data-governance).
</Accordion>

<Accordion title="How is my data secured when used with AI?">
  Merchant data used with Recurly AI tools is stored in accordance with Recurly's Privacy Policy. AI models run on Google Vertex AI and Elasticsearch to support data security and compliance.
</Accordion>

<Accordion title="Is my data used to train AI models?">
  No. Recurly does not currently use merchant data for AI training.
</Accordion>

<Accordion title="Is my data shared with competitors?">
  No. Merchant- and subscriber-level data is never shared with competitors. Only aggregated, non-identifiable insights may be used for analytical or benchmarking purposes.
</Accordion>

<Accordion title="How do I opt out of Recurly Compass?">
  Contact [support@recurly.com](mailto:support@recurly.com) to opt out.
</Accordion>
