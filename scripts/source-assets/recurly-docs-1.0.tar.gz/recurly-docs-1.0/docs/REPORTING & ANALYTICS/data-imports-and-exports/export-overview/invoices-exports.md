---
title: Invoices - export
excerpt: >-
  Hidden page - please visit the following page for the most up to date
  information https://docs.recurly.com/docs/invoices-summary
deprecated: false
hidden: true
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
Recurly provides two exports to help you retrieve data related to invoices: Invoices - Summary and Invoices - Unused Numbers. These exports complement each other to provide details about different subsets of invoice numbers. 

## Version Change Log

### Invoices- Accounts Receivable

#### Version 2 - 7/25/2023

* Net term type column expanded to include new End of Month terms

### Invoices- Summary

#### Version 4 - 7/25/2023

* Net term type column expanded to include new End of Month terms

### Invoices- (Deprecated)

#### 7/25/2023

* Net term type column expanded to include new End of Month terms

# Invoices - Summary

The invoice summary export contains the invoice header information and the summary totals for each of your successfully-generated invoices. 

### Invoice Status Filter

#### All

Every invoice generated within your Recurly site, regardless of status.

#### Open

All invoices that have not received a payment attempt. This status has a value of 'pending' in the export and does not include invoices with a 'past\_due' status. This status only exists for manual invoices. If you see this status for an automatically collected invoice, it may mean that the payment attempt had a transaction communication error.

#### Processing

All invoices that have an ACH bank payment in progress. This status will only exist for ACH bank payments. The status means the associated payment transaction has not settled. An ACH invoice with the Processing status that reaches the due date will not move to Past Due or Paid until the transaction has settled.

#### Closed

All successfully collected invoices. This status has a value of 'paid' in the export and does not include the 'failed' status. It is important to note that the associated credit card, PayPal, or Amazon transaction with a paid invoice may not be settled with the gateway. Allow at least 1 to 3 business days for transaction settlement with the gateway.

#### Past Due

All automatic invoices that attempted collection, but the payment failed, or manual invoices that have reached their due date. Payment for automatic invoices will be retried automatically through <a href='/docs/dunning-management'>the dunning process</a>.

#### Failed

All invoices that have either experienced 20 declines or have been through the dunning process without successful payment. These invoices will not be retried. It is important to note that failed invoices will clear the owed balance from the account and will not attempt any future collections, but the charge line items will still exist in the account history.

#### Voided

All credit invoices that have been voided. These invoices will not be retried. It is important to note that voided invoices will clear the owed balance from the account and will not attempt any future collections, but the credit line items will still exist in the account history.

### Date Range Filters

#### Created

Shows invoices created during the selected time range. Uses the 'billed\_date' column in the export.

#### Modified

Shows invoices last modified during the selected time range. An invoice is only modified when its 'status' changes. Uses the 'modified\_at' column in the export.

### Export Contents

<Table align={["left","left","left"]}>
  <thead>
    <tr>
      <th style={{ textAlign: "left" }}>
        Column Name
      </th>

      <th style={{ textAlign: "left" }}>
        Example
      </th>

      <th style={{ textAlign: "left" }}>
        Description
      </th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="id">id</span>
      </td>

      <td style={{ textAlign: "left" }}>
        b964b5439c2548a489b3a136e75aee9f
      </td>

      <td style={{ textAlign: "left" }}>
        Unique internal identifier for the invoice. This is also called the 'invoice\_id' or 'uuid' for the invoice in the API.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="invoice_number">invoice\_number</span>
      </td>

      <td style={{ textAlign: "left" }}>
        1291
      </td>

      <td style={{ textAlign: "left" }}>
        External invoice identifier.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="billed_date">billed\_date</span>
      </td>

      <td style={{ textAlign: "left" }}>
        2012-02-19 12:01:33 PST
      </td>

      <td style={{ textAlign: "left" }}>
        Creation date of the invoice. Equivalent to date in the deprecated Invoices export. Used for Created date range filter.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="due_on">due\_on</span>
      </td>

      <td style={{ textAlign: "left" }}>
        2012-02-19 12:01:33 PST
      </td>

      <td style={{ textAlign: "left" }}>
        Date invoice is due. This is the date the net terms is reached.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="closed_at">closed\_at</span>
      </td>

      <td style={{ textAlign: "left" }}>
        2012-02-19 12:01:33 PST
      </td>

      <td style={{ textAlign: "left" }}>
        Date invoice was closed (paid) or failed.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="status">status</span>
      </td>

      <td style={{ textAlign: "left" }}>
        pending, processing, past\_due, paid, failed, voided
      </td>

      <td style={{ textAlign: "left" }}>
        Current status of the invoice. Equivalent to invoice\_state in the Adjustments export. See filter notes above for details on what each status means.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="net_terms">net\_terms</span>
      </td>

      <td style={{ textAlign: "left" }}>
        on-receipt, net-10, net-30, net-60
      </td>

      <td style={{ textAlign: "left" }}>
        Identifies the net\_terms agreement associated with the invoice. All automatic collection invoices are due 'on-receipt'. Manual collection invoices can have terms of net-10, net-30, net-60, or a custom net day amount.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="collection_method">collection\_method</span>
      </td>

      <td style={{ textAlign: "left" }}>
        automatic or manual
      </td>

      <td style={{ textAlign: "left" }}>
        Identifies whether the invoice fees are collected via manual or automatic invoicing. An automatic invoice means a corresponding transaction is run using the account's billing information at the same time the invoice is created. Manual invoices are created without a corresponding transaction.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="account_code">account\_code</span>
      </td>

      <td style={{ textAlign: "left" }}>
        123122E
      </td>

      <td style={{ textAlign: "left" }}>
        Account code being charged for this invoice.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="account_name">account\_name</span>
      </td>

      <td style={{ textAlign: "left" }}>
        JJ Smith
      </td>

      <td style={{ textAlign: "left" }}>
        First and last name from account associated with that invoice.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="account_company">account\_company</span>
      </td>

      <td style={{ textAlign: "left" }}>
        Company, Inc.
      </td>

      <td style={{ textAlign: "left" }}>
        Company name from account. This field is from the Account Info and is displayed on the invoice if it exists.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="account_line1">account\_line1</span>
      </td>

      <td style={{ textAlign: "left" }}>
        1 Main Street
      </td>

      <td style={{ textAlign: "left" }}>
        Address line 1 of the customer's address on the invoice. This will come from the Billing Address or the Account Address depending on your tax settings and the invoice collection method.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="account_line2">account\_line2</span>
      </td>

      <td style={{ textAlign: "left" }}>
        Suite 100
      </td>

      <td style={{ textAlign: "left" }}>
        Address line 2 of the customer's address on the invoice. This will come from the Billing Address or the Account Address depending on your tax settings and the invoice collection method.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="account_city">account\_city</span>
      </td>

      <td style={{ textAlign: "left" }}>
        San Francisco
      </td>

      <td style={{ textAlign: "left" }}>
        City of the customer's address on the invoice. This will come from the Billing Address or the Account Address depending on your tax settings and the invoice collection method.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="account_state">account\_state</span>
      </td>

      <td style={{ textAlign: "left" }}>
        CA
      </td>

      <td style={{ textAlign: "left" }}>
        State or province of the customer's address on the invoice. This will come from the Billing Address or the Account Address depending on your tax settings and the invoice collection method.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="account_zip">account\_zip</span>
      </td>

      <td style={{ textAlign: "left" }}>
        94107
      </td>

      <td style={{ textAlign: "left" }}>
        ZIP/postal code of the customer's address on the invoice. This will come from the Billing Address or the Account Address depending on your tax settings and the invoice collection method.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="account_country">account\_country</span>
      </td>

      <td style={{ textAlign: "left" }}>
        US
      </td>

      <td style={{ textAlign: "left" }}>
        The 2 letter country code for the country of the customer's address on the invoice. This will come from the Billing Address or the Account Address depending on your tax settings and the invoice collection method.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="vat_number">vat\_number</span>
      </td>

      <td style={{ textAlign: "left" }}>
        IE124211145
      </td>

      <td style={{ textAlign: "left" }}>
        VAT registration number for the customer on the invoice. This will come from the VAT Number field in the Billing Info or the Account Info depending on your tax settings and the invoice collection method.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="po_number">po\_number</span>
      </td>

      <td style={{ textAlign: "left" }}>
        AE12523
      </td>

      <td style={{ textAlign: "left" }}>
        For manual invoicing, this identifies the Purchase Order number associated with the invoice. This value must be entered by the merchant at the time the invoice is created or it will not exist.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="coupon_code">coupon\_code</span>
      </td>

      <td style={{ textAlign: "left" }}>
        50off
      </td>

      <td style={{ textAlign: "left" }}>
        The code for the coupon associated with any discounts on the invoice. This value will only exist if a coupon was applied to the invoice.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="currency">currency</span>
      </td>

      <td style={{ textAlign: "left" }}>
        USD
      </td>

      <td style={{ textAlign: "left" }}>
        The currency of the amounts on the invoice. We do not allow mixed currency invoices.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="invoice_total">invoice\_total</span>
      </td>

      <td style={{ textAlign: "left" }}>
        100
      </td>

      <td style={{ textAlign: "left" }}>
        The final total on the invoice. The summation of invoice charges, discounts, credits, and tax. Equivalent to the total in the deprecated Invoices export
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="invoice_subtotal">invoice\_subtotal</span>
      </td>

      <td style={{ textAlign: "left" }}>
        50
      </td>

      <td style={{ textAlign: "left" }}>
        The Subtotal on the invoice. The summation of charges, discounts, and credits, before tax.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="tax_amount">tax\_amount</span>
      </td>

      <td style={{ textAlign: "left" }}>
        15.00
      </td>

      <td style={{ textAlign: "left" }}>
        The total tax amount on the invoice.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="tax_type">tax\_type</span>
      </td>

      <td style={{ textAlign: "left" }}>
        usst, vat, ca, au, nz
      </td>

      <td style={{ textAlign: "left" }}>
        Provides the tax type as "vat" for EU VAT, "usst" for U.S. Sales Tax, or the 2 letter country code for country level tax types like Canada, Australia, New Zealand, Israel, and all non-EU European countries.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="tax_region">tax\_region</span>
      </td>

      <td style={{ textAlign: "left" }}>
        NY, FR, GST, VAT
      </td>

      <td style={{ textAlign: "left" }}>
        Provides the tax region applied on an invoice. For U.S. Sales Tax, this will be the 2 letter state code. For EU VAT this will be the 2 letter country code. For all country level tax types, this will display the regional tax, like VAT, GST, or PST.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="tax_rate">tax\_rate</span>
      </td>

      <td style={{ textAlign: "left" }}>
        0.1
      </td>

      <td style={{ textAlign: "left" }}>
        Tax rate applied on the invoice.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="credit_to_account">credit\_to\_account</span>
      </td>

      <td style={{ textAlign: "left" }}>
        0
      </td>

      <td style={{ textAlign: "left" }}>
        Amount of credit applied back to the account. This amount is a charge with adjustment\_origin of 'carryforward' on the invoice. This charge is what zeros out the invoice and should be filtered out of your reports. Credit to Account also maps to the uninvoiced credit that is created for the same amount and left on the account for payment of a future invoice. That credit will have an adjustment\_origin that matches the original charge's origin.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="recovery_reason">recovery\_reason</span>
      </td>

      <td style={{ textAlign: "left" }}>
        exp\_date, retry, account\_updater, prior\_recovery, customer\_updates
      </td>

      <td style={{ textAlign: "left" }}>
        If the initial transaction failed but a subsequent one succeeded, this field indicates why. See the details of what each reason means in our blog "[Revenue Recovery: What Has Recurly Recovered for Me Lately?](https://blog.recurly.com/what-has-recurly-recovered-revenue)".
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="invoice_country">invoice\_country</span>
      </td>

      <td style={{ textAlign: "left" }}>
        FR
      </td>

      <td style={{ textAlign: "left" }}>
        This column is only visible if your site has European Union VAT or New Zealand GST Location Validation enabled. Column shows the EU or NZ country code of the customer's address on the invoice. The country refers to the evidence\_matched.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="evidence_matched">evidence\_matched</span>
      </td>

      <td style={{ textAlign: "left" }}>
        Account Info Country, Billing Info Country, IP Address Country, Credit Card BIN Country
      </td>

      <td style={{ textAlign: "left" }}>
        This column is only visible if your site has European Union VAT or New Zealand GST Location Validation enabled. Column shows the two pieces of evidence that matched when the invoice was created. The corresponding country is the invoice\_country.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="modified_at">modified\_at</span>
      </td>

      <td style={{ textAlign: "left" }}>
        2014-12-26 08:23:34 PST
      </td>

      <td style={{ textAlign: "left" }}>
        The date the invoice was last modified. An invoice is only modified if the status changes. Used for Modified date range filter.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="invoice_type">invoice\_type</span>
      </td>

      <td style={{ textAlign: "left" }}>
        purchase, refund, renewal, immediate\_change, termination, credit, gift\_card, write\_off, external\_refund, carryforward\_credit, carryforward\_gift\_credit, usage\_correction, import
      </td>

      <td style={{ textAlign: "left" }}>
        This is the invoice origin. The original invoice will have a type of 'purchase'. Any refunds or voids will create a negative invoice to cancel out the original. This negative invoice will have a type of 'refund'.\ <br/>\
        All other invoice types are unlocked only when the Credit Invoices feature is enabled. See the full table of <a href='/docs/invoices#section-origins'>invoice origins</a> for descriptions.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="original_invoice_number">original\_invoice\_number</span>
      </td>

      <td style={{ textAlign: "left" }}>
        1002
      </td>

      <td style={{ textAlign: "left" }}>
        If the row is a refund invoice, this value will exist and show the invoice number of the purchase invoice the refund was created from.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="ship_address_name">ship\_address\_name</span>
      </td>

      <td style={{ textAlign: "left" }}>
        Julie Smith
      </td>

      <td style={{ textAlign: "left" }}>
        The first and last name associated with the shipping address
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="ship_address_line1">ship\_address\_line1</span>
      </td>

      <td style={{ textAlign: "left" }}>
        ship\_address\_line1
      </td>

      <td style={{ textAlign: "left" }}>
        ship\_address\_line1
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="ship_address_line2">ship\_address\_line2</span>
      </td>

      <td style={{ textAlign: "left" }}>
        Apt 1
      </td>

      <td style={{ textAlign: "left" }}>
        The second line of the street address for the shipping address
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="ship_address_city">ship\_address\_city</span>
      </td>

      <td style={{ textAlign: "left" }}>
        West Bloomfield
      </td>

      <td style={{ textAlign: "left" }}>
        The city for the shipping address
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="ship_address_state">ship\_address\_state</span>
      </td>

      <td style={{ textAlign: "left" }}>
        MI
      </td>

      <td style={{ textAlign: "left" }}>
        The state for the shipping address
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="ship_address_zip">ship\_address\_zip</span>
      </td>

      <td style={{ textAlign: "left" }}>
        48322
      </td>

      <td style={{ textAlign: "left" }}>
        The zip or postal code for the shipping address
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="ship_address_country">ship\_address\_country</span>
      </td>

      <td style={{ textAlign: "left" }}>
        US
      </td>

      <td style={{ textAlign: "left" }}>
        The country for the shipping address
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="ship_address_phone">ship\_address\_phone</span>
      </td>

      <td style={{ textAlign: "left" }}>
        248-555-1212
      </td>

      <td style={{ textAlign: "left" }}>
        The phone number associated with the shipping address
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="invoice_doc_type">invoice\_doc\_type</span>
      </td>

      <td style={{ textAlign: "left" }}>
        legacy, charge, credit
      </td>

      <td style={{ textAlign: "left" }}>
        This is the invoice document type. All invoices created before the Credit Invoices feature is enabled will have a type of ‘legacy’. Once Credit Invoices is enabled, new invoices will be either ‘charge’ or ‘credit’.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="invoice_balance">invoice\_balance</span>
      </td>

      <td style={{ textAlign: "left" }}>
        50.25
      </td>

      <td style={{ textAlign: "left" }}>
        The balance of the invoice.\
        **This column will be null until Recurly's Credit Invoices feature is enabled on your Recurly site.**
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="invoice_balance_modified_at">invoice\_balance\_modified\_at</span>
      </td>

      <td style={{ textAlign: "left" }}>
        2016-01-01 10:17:02 UTC
      </td>

      <td style={{ textAlign: "left" }}>
        The datetime the invoice\_balance last changed due to a transaction or credit payment.\
        **This column will be null until Recurly's Credit Invoices feature is enabled on your Recurly site.**
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="invoice_balance_modified_at">invoice\_balance\_modified\_at</span>
      </td>

      <td style={{ textAlign: "left" }}>
        10
      </td>

      <td style={{ textAlign: "left" }}>
        The total of all discounts on the invoice. This is the sum of each adjustment’s discount.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="invoice_discount">invoice\_discount</span>
      </td>

      <td style={{ textAlign: "left" }}>
        50.25
      </td>

      <td style={{ textAlign: "left" }}>
        The total of all adjustments on the invoice, before discounts and taxes.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="invoice_subtotal_before_discounts">invoice\_subtotal\_before\_discounts</span>
      </td>

      <td style={{ textAlign: "left" }}>
        50.25
      </td>

      <td style={{ textAlign: "left" }}>
        The refundable amount of the invoice, which is the invoice total, including discounts and tax, minus all credit invoices issued against it.\
        **This column will be null until Recurly's Credit Invoices feature is enabled on your Recurly site.**
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        <span id="business_entity_code">business\_entity\_code</span>
      </td>

      <td style={{ textAlign: "left" }}>
        123456789
      </td>

      <td style={{ textAlign: "left" }}>
        The Business Entity code is a unique string of letters and numbers you must create for each alternate business entity. This will be used to reference and assign/use business entity codes in the API, and is used to determine entities in exports. 
      </td>
    </tr>
  </tbody>
</Table>

# Invoices - Unused Numbers

The unused invoice number export contains basic information for all invoice numbers that were **not** used on successfully-generated invoices. An unused invoice number could result from a failed sign-up, among other events.

This log of unused invoice numbers is especially useful for audit purposes. It complements the invoice numbers provided in the Invoices - Summary export to provide an explanation for each invoice number in your sequence.

All invoice numbers unsuccessfully attempted on or after July 1, 2019 will be shown in this export.

### Export Contents

<Table align={["left","left","left"]}>
  <thead>
    <tr>
      <th style={{ textAlign: "left" }}>
        Column Name
      </th>

      <th style={{ textAlign: "left" }}>
        Example
      </th>

      <th style={{ textAlign: "left" }}>
        Description
      </th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td style={{ textAlign: "left" }}>
        invoice\_number
      </td>

      <td style={{ textAlign: "left" }}>
        1291
      </td>

      <td style={{ textAlign: "left" }}>
        External invoice identifier.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        invoice\_type
      </td>

      <td style={{ textAlign: "left" }}>
        purchase, refund, renewal, immediate\_change, termination, credit, gift\_card, write\_off, external\_refund, carryforward\_credit, carryforward\_gift\_credit, usage\_correction, import
      </td>

      <td style={{ textAlign: "left" }}>
        This is the invoice origin. The original invoice will have a type of 'purchase'. Any refunds or voids will create a negative invoice to cancel out the original. This negative invoice will have a type of 'refund'.\ <br/>\
        All other invoice types are unlocked only when the Credit Invoices feature is enabled. See the full table of <a href='/docs/invoices#section-origins'>invoice origins</a> for descriptions.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        invoice\_doc\_type
      </td>

      <td style={{ textAlign: "left" }}>
        legacy, charge, credit
      </td>

      <td style={{ textAlign: "left" }}>
        This is the invoice document type. All invoices created before the Credit Invoices feature is enabled will have a type of ‘legacy’. Once Credit Invoices is enabled, new invoices will be either ‘charge’ or ‘credit’.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        invoice\_date
      </td>

      <td style={{ textAlign: "left" }}>
        2019-07-19 12:01:33 PST
      </td>

      <td style={{ textAlign: "left" }}>
        Attempted creation date of the invoice.\
        The earliest invoice date possible is July 1, 2019, as this is the release date of this export.
      </td>
    </tr>
  </tbody>
</Table>

# Invoices (DEPRECATED)

The invoice export contains individual invoice line items including summary totals for invoices, so multiple items may be associated with the same invoice ID. 

> 🚧
>
> The Invoices export has been replaced by the "Invoices - Summary" export and the "Adjustments" export. **This export will be removed when your site enables credit memo functionality**.

### Invoice Status Filter

#### All

Every invoice generated within your Recurly site, regardless of status.

#### Open

All invoices that have not received a payment attempt. Open is equivalent to 'pending' in the new invoice exports and does not include the 'past\_due' status. This status only exists for manual invoices. If you see this status for an automatically collected invoice, it may mean that the payment attempt had a transaction communication error.

#### Processing

All invoices that have an ACH bank payment in process. This status will only exist for ACH bank payments. The status means the associated payment transaction has not settled. An ACH invoice with the Processing status that reaches the due date will not move to Past Due or Paid until the transaction has settled.

#### Closed

All successfully collected invoices. Closed is equivalent to 'paid' in the new invoice exports and does not include the 'failed' status. It is important to note that the associated credit card, PayPal, or Amazon transaction with a Closed invoice may not be settled with the gateway. Allow at least 1 to 3 business days for transaction settlement with the gateway.

#### Past Due

All automatic invoices that attempted collection, but payment failed, or manual invoices that have reached their due date. Payment for automatic invoices will be retried automatically through <a href='/docs/dunning-management'>the dunning process</a>.

#### Failed

All invoices that have either experienced 20 declines, or have been through the dunning process without successful payment. These invoices will not be retried. It is important to note that failed invoices will clear the owed balance from the account and will not attempt any future collections, but the charge line items will still exist in the account history.

### Date Range Filter

#### Created

Shows invoices created during the selected time range. Uses the 'billed\_date' column in the export.

#### Modified

Shows invoices last modified during the selected time range. An invoice is only modified when its 'status' changes. Uses the 'modified\_at' column in the export.

### Export Contents

| Column Name                  | Example                                                                        | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| :--------------------------- | :----------------------------------------------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| id                           | b964b5439c2548a489b3a136e75aee9f                                               | Unique internal identifier for the invoice. This is also called the 'invoice\_id' or 'uuid' for the invoice in the API.                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| account\_code                | 123122E                                                                        | Account code being charged for this invoice.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| account\_name                | JJ Smith                                                                       | First and last name from account,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| invoice\_number              | 1291                                                                           | External invoice identifier.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| subscription\_id             | 1fed8d153fcf4ea2a1d55ff2eebd51b7                                               | Subscription UUID associated with this line item on the invoice.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| plan\_code                   | basic                                                                          | The plan code for the plan associated with the subscription. This value will exist for plan fee, setup fee, add-on fee and free trial line items. This value will not exist for custom charges, custom credits, or open amount refund credits.                                                                                                                                                                                                                                                                                                                  |
| coupon\_code                 | 50off                                                                          | The code for the coupon associated with any discounts on the invoice. This value will only exist if a coupon was applied to the invoice and will show for all line items on an invoice, even if the specific line item was not discounted by the coupon.                                                                                                                                                                                                                                                                                                        |
| total                        | 100                                                                            | The final total on the invoice. The summation of invoice charges, discounts, credits, and tax. Equivalent to the invoice\_total in the Invoices - Summary export                                                                                                                                                                                                                                                                                                                                                                                                |
| subtotal                     | 50                                                                             | Total charges on the invoice before discounts, credits, and tax.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| tax\_amount                  | 12.25                                                                          | The total tax amount on the invoice. This is not the tax amount for the specific line item.                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| currency                     | USD                                                                            | The currency of the amounts on the invoice. Every line item on an invoice will have the same currency. We do not allow mixed currency invoices.                                                                                                                                                                                                                                                                                                                                                                                                                 |
| date                         | 2012-02-19 12:01:33 PST                                                        | Creation date of the invoice. Equivalent to billed\_date in the Invoices - Summary export. **Used for Created date range filter.**                                                                                                                                                                                                                                                                                                                                                                                                                              |
| status                       | open, processing, past\_due, closed, or failed                                 | Current status of the invoice. Equivalent to invoice\_state in the Adjustments export and status in the Invoices - Summary export. See filter notes above for details on what each status means.                                                                                                                                                                                                                                                                                                                                                                |
| closed\_at                   | 2012-01-18 11:47:13 PST                                                        | Date invoice was closed (paid) or failed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| purchase\_country            | IE                                                                             | The 2 letter country code for the country of the customer on the invoice. This will come from the Billing Address or the Account Address depending on your tax settings and the invoice collection method. Equivalent to account\_country in the Invoices - Summary export.                                                                                                                                                                                                                                                                                     |
| vat\_number                  | IE124211145                                                                    | VAT registration number for the customer on the invoice. This will come from the VAT Number field in the Billing Info or the Account Info depending on your tax settings and the invoice collection method.                                                                                                                                                                                                                                                                                                                                                     |
| line\_item\_total            | 500                                                                            | The total amount of the line item after discounts and taxes \[(quantity x price) + discount + tax]. Equivalent to adjustment\_total in the Adjustments export.                                                                                                                                                                                                                                                                                                                                                                                                  |
| line\_item\_description      | Basic Plan, one month                                                          | Description for a specific invoice line item. This is automatically generated for all plan line items. This is custom for one-time custom charges and credits. Equivalent to adjustment\_description in the Adjustments export.                                                                                                                                                                                                                                                                                                                                 |
| line\_item\_origin           | plan, plan\_trial, setup\_fee, add\_on, debit, one\_time, credit, carryforward | The original source for a line item. A credit created from an original charge will have the value of the charge's origin. Equivalent to adjustment\_origin in the Adjustments export. (plan = subscription fee, plan\_trial = trial period 0 amount charge, setup\_fee = subscription setup fee, add\_on = subscription add-on fee, debit = custom charge through the UI or Adjustments API, one\_time = custom charge through the Transactions API, credit = custom credit, carryforward = the charge that zeros out a negative invoice and should be ignored) |
| line\_item\_product\_code    | 0000yearly                                                                     | Plan code for a specific invoice line item. This will only populate if the line item is for a subscription. The value will always be the plan\_code, unless the line item is an add-on, which would then show the add-on code. Equivalent to adjustment\_product\_code in the Adjustments export.                                                                                                                                                                                                                                                               |
| line\_item\_accounting\_code | 0000yearly                                                                     | Internal accounting code for a specific invoice line item. This value will only populate if you define an accounting code for the line item. Accounting codes can be defined for all line items except free trials, which will inherit the plan's accounting code. Equivalent to adjustment\_accounting\_code in the Adjustments export.                                                                                                                                                                                                                        |
| line\_item\_start\_date      | 2012-01-19 11:03:23 PST                                                        | Bill cycle start date for a specific invoice line item. Equivalent to adjustment\_start\_at in the Adjustments export.                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| line\_item\_end\_date        | 2012-02-19 11:03:23 PST                                                        | Bill cycle end date for a specific invoice line item. This date will not exist for custom charges (one-time). Equivalent to adjustment\_end\_at in the Adjustments export.                                                                                                                                                                                                                                                                                                                                                                                      |
| net\_terms                   | on-receipt, net-10, net-30, net-60                                             | Identifies the net\_terms agreement associated with the invoice. All automatic collection invoices are due 'on-receipt'. Manual collection invoices can have terms of net-10, net-30, net-60, or a custom net day amount.                                                                                                                                                                                                                                                                                                                                       |
| po\_number                   | 213123                                                                         | For manual invoicing, this identifies the Purchase Order number associated with the invoice. This value must be entered by the merchant at the time the invoice is created or it will not exist.                                                                                                                                                                                                                                                                                                                                                                |
| collection\_method           | automatic or manual                                                            | Identifies whether the invoice fees are collected via manual or automatic invoicing. An automatic invoice means a corresponding transaction is run using the account's billing information at the same time the invoice is created. Manual invoices are created without a corresponding transaction. The merchant must enter a manual payment transaction or have the customer pay the invoice with an automatic method, like credit card, PayPal, Amazon, or ACH bank payment.                                                                                 |
| line\_item\_uuid             | 293f96f8c6fd1f8f622ec44306a3a92a                                               | Provides the unique internal identifier for each line item on an invoice. Equivalent to uuid in the Adjustments export.                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| tax\_type                    | usst, vat, ca, au, nz                                                          | Provides the tax type as "vat" for EU VAT, "usst" for U.S. Sales Tax, or the 2 letter country code for country level tax types like Canada, Australia, New Zealand, Israel, and all non-EU European countries.                                                                                                                                                                                                                                                                                                                                                  |
| tax\_region                  | NY, FR, GST, VAT                                                               | Provides the tax region applied on an invoice. For U.S. Sales Tax, this will be the 2 letter state code. For EU VAT this will be the 2 letter country code. For all country level tax types, this will display the regional tax, like VAT, GST, or PST.                                                                                                                                                                                                                                                                                                         |
| tax\_rate                    | 0.1                                                                            | Tax rate applied on the invoice                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| discount                     | -5                                                                             | Total discount amount applied on an invoice. This is not the discount for the specific line item.                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| original\_adjustment\_uuid   | b964b5439c2548a489b3a136e75aee9f                                               | Value is the uuid of the previous related line item (adjustment). Will only have a value if the line item is a credit created from a previous credit, or if the credit was created from a charge refund.                                                                                                                                                                                                                                                                                                                                                        |
| modified\_at                 | 2014-12-26 08:23:34 PST                                                        | The date the invoice was last modified. An invoice is only modified if the status changes. **Used for Modified date range filter.**                                                                                                                                                                                                                                                                                                                                                                                                                             |
| invoice\_type                | purchase, refund                                                               | The original invoice will have a type of 'purchase'. Any refunds or voids will create a negative invoice to cancel out the original. This negative invoice will have a type of 'refund'.                                                                                                                                                                                                                                                                                                                                                                        |
| original\_invoice\_number    | 1002                                                                           | If the row is a line item from a refund invoice, this value will exist and show the invoice number of the purchase invoice the refund was created from.                                                                                                                                                                                                                                                                                                                                                                                                         |