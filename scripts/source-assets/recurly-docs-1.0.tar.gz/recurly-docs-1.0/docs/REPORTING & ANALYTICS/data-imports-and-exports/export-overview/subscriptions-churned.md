---
title: Subscriptions — churned - export
excerpt: Track and export data on churned Recurly subscriptions with ease.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Required plan

This feature or setting is available to all customers on any Recurly subscription plan.

# Definition

In the Recurly platform, a "Churned Subscription" refers to subscriptions that have churned and are no longer active. This information is vital in understanding subscription lifecycles and trends in user retention.

<Image border={false} src="https://files.readme.io/e109c1baf3810a7af7931ca078abdc42ca0da2f13a7cd26f919d17baf5ccb0e8-image.png" />

# Filters

### **Versions Filter**

* The Versions filter allows you to select the version that is most appropriate for your needs. This is based on the version changelog at the bottom of this page.

### Time Range Filter

To get specific data, use the Time Range Filter which exports all the subscriptions that expired during a selected time frame. This filter uses the "expired_at" column in the export. Note that a subscription does not churn until it has expired, and the "canceled_at" and "expired_at" dates are not the same.

* The Time range filter (dropdown) allows you to view data within a specific period such as last month, year to date or a custom date range. The Start Date and End Date will automatically update based on the value selected in the Time range filter. You can also choose "Between..." in the dropdown, which will allow you to enter a customized date range.

# Exports table

<HTMLBlock>{`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Button</title>
    <style>
        .download-button {
            display: inline-block;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            color: #1C2833FF; 
            background-color: #F8F8F8FF; 
            border-radius: 5px;
            font-weight: normal;
            transition: background-color 0.5s ease, transform 0.3s ease;
          	transition: 0.4s !important;
            font-family: 'Proxima-nova', Arial, sans-serif;
            max-width: 100%; 
        }

        .download-button:hover {
            background-color: #FFFFFFFF; 
            transform: scale(1.02); 
        }
      	a:hover {
          	color: #1C2833FF;
          	text-decoration: underline !important;
        }
      </style>
</head>
<body>
    <a href="https://docs.google.com/spreadsheets/d/1U0_Wl_NMScJqKBZoBKMmQnybmLEr0gFi6r7dfNiP9Qc/export?format=xlsx" class="download-button">Download our complete export schema</a>
</body>
</html>
`}</HTMLBlock>

To help you identify and organize information effectively, the export provides a structured table that contains the following columns:

<Table align={["left","left","left"]}>
  <thead>
    <tr>
      <th>
        Column Name
      </th>

      <th>
        Example
      </th>

      <th>
        Description
      </th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td>
        <span id="uuid">uuid</span>
      </td>

      <td>
        5eg5bcc7ef8211e0a908005056b00005
      </td>

      <td>
        Unique identifier for a specific subscription plan.
      </td>
    </tr>

    <tr>
      <td>
        <span id="account_code">account_code</span>
      </td>

      <td>
        123456789, [test@example.com](mailto:test@example.com)
      </td>

      <td>
        Account associated with a given subscription UUID.
      </td>
    </tr>

    <tr>
      <td>
        <span id="email">email</span>
      </td>

      <td>
        [test@example.com](mailto:test@example.com)
      </td>

      <td>
        Email address associated with a given subscription UUID.
      </td>
    </tr>

    <tr>
      <td>
        <span id="plan_code">plan_code</span>
      </td>

      <td>
        basic
      </td>

      <td>
        Plan that the customer is subscribed to with this UUID.
      </td>
    </tr>

    <tr>
      <td>
        <span id="state">state</span>
      </td>

      <td>
        pending, modified, converted, active, canceled, expired
      </td>

      <td>
        Current state of the subscription. Modified and converted are depreciated states
      </td>
    </tr>

    <tr>
      <td>
        <span id="auto_renew">auto_renew</span>
      </td>

      <td>
        TRUE
      </td>

      <td>
        Defaults to TRUE for auto-renewing subscriptions. FALSE if subscription set to expire at end of current term.
      </td>
    </tr>

    <tr>
      <td>
        <span id="currency">currency</span>
      </td>

      <td>
        USD
      </td>

      <td>
        Identifies the currency being charged with this subscription.
      </td>
    </tr>

    <tr>
      <td>
        <span id="quantity">quantity</span>
      </td>

      <td>
        1
      </td>

      <td>
        Identifies the quantity of the subscription purchase.
      </td>
    </tr>

    <tr>
      <td>
        <span id="unit_amount">unit_amount</span>
      </td>

      <td>
        99
      </td>

      <td>
        Identifies the base price of 1 quantity of the subscription.
      </td>
    </tr>

    <tr>
      <td>
        <span id="add_on_amount">add_on_amount</span>
      </td>

      <td>
        15
      </td>

      <td>
        Identifies any additional charges to the subscription base fee from add_ons.
      </td>
    </tr>

    <tr>
      <td>
        <span id="total_recurring_amount">total_recurring_amount</span>
      </td>

      <td>
        114
      </td>

      <td>
        Identifies total recurring charges - unit_amount x quantity + add_on_amount.
      </td>
    </tr>

    <tr>
      <td>
        <span id="current_period_started_at">current_period_started_at</span>
      </td>

      <td>
        2009-12-04 00:46:59 PST
      </td>

      <td>
        Date and time that the current billing period started. *
      </td>
    </tr>

    <tr>
      <td>
        <span id="current_period_ends_at">current_period_ends_at</span>
      </td>

      <td>
        2009-12-04 00:46:59 PST
      </td>

      <td>
        Date and time that the current billing period ends at.
      </td>
    </tr>

    <tr>
      <td>
        <span id="trial_started_at">trial_started_at</span>
      </td>

      <td>
        2010-03-24 17:18:46 PDT
      </td>

      <td>
        Date and time that a trial period began on the subscription.
      </td>
    </tr>

    <tr>
      <td>
        <span id="trial_ends_at">trial_ends_at</span>
      </td>

      <td>
        2010-04-23 17:18:46 PDT
      </td>

      <td>
        Date and time that a trial period ends on the subscription.
      </td>
    </tr>

    <tr>
      <td>
        <span id="total_billing_cycles">total_billing_cycles</span>
      </td>

      <td>
        1
      </td>

      <td>
        This is the total number billing periods in the subscription term.
      </td>
    </tr>

    <tr>
      <td>
        <span id="remaining_billing_cycles">remaining_billing_cycles</span>
      </td>

      <td>
        0
      </td>

      <td>
        Number of remaining billing periods in the subscription’s current term. Will always be 0 if subscription term has 1 billing period
      </td>
    </tr>

    <tr>
      <td>
        <span id="renewal_billing_cycles">renewal_billing_cycles</span>
      </td>

      <td>
        1
      </td>

      <td>
        Number of billing periods in the subscription’s next term. Will default to plan’s total_billing_cycles unless customized. Nil if auto_renew = false
      </td>
    </tr>

    <tr>
      <td>
        <span id="current_term_started_at">current_term_started_at</span>
      </td>

      <td>
        2018-09-02 15:53:18 UTC
      </td>

      <td>
        Start date of the subscription’s current term
      </td>
    </tr>

    <tr>
      <td>
        <span id="current_term_ends_at">current_term_ends_at</span>
      </td>

      <td>
        2018-10-02 15:53:18 UTC
      </td>

      <td>
        End date of the subscription’s current term.
      </td>
    </tr>

    <tr>
      <td>
        <span id="activated_at">activated_at</span>
      </td>

      <td>
        2010-03-24 17:18:46 PDT
      </td>

      <td>
        Date and time the subscription was added to the account.
      </td>
    </tr>

    <tr>
      <td>
        <span id="modified_at">modified_at</span>
      </td>

      <td>
        2010-03-24 17:18:44 PDT
      </td>

      <td>
        Date and time the subscription was last updated.
      </td>
    </tr>

    <tr>
      <td>
        <span id="canceled_at">canceled_at</span>
      </td>

      <td>
        2010-03-28 22:54:46 PDT
      </td>

      <td>
        Date and time the subscription was canceled.
      </td>
    </tr>

    <tr>
      <td>
        <span id="expires_at">expires_at</span>
      </td>

      <td>
        2010-04-23 22:51:53 PDT
      </td>

      <td>
        Date and time the subscription was terminated. **Used for date range filter**
      </td>
    </tr>

    <tr>
      <td>
        <span id="maintenance_url">maintenance_url</span>
      </td>

      <td>
        app.recurly.com/account/sdasdasdad213525asdad
      </td>

      <td>
        Link to the customer's hosted account maintenance URL.
      </td>
    </tr>

    <tr>
      <td>
        <span id="net_terms">net_terms</span>
      </td>

      <td>
        on-receipt
      </td>

      <td>
        Identifies the net_terms agreement associated with the subscription.
      </td>
    </tr>

    <tr>
      <td>
        <span id="po_number">po_number</span>
      </td>

      <td>
        213123
      </td>

      <td>
        For manual invoicing, this identifies the PO number associated with the subscription.
      </td>
    </tr>

    <tr>
      <td>
        <span id="collection_method">collection_method</span>
      </td>

      <td>
        automatic/manual
      </td>

      <td>
        Identifies whether the subscription fees are collected via manual or automatic invoicing
      </td>
    </tr>

    <tr>
      <td>
        <span id="plan_name">plan_name</span>
      </td>

      <td>
        Basic Plan
      </td>

      <td>
        The plan name of the subscription at the time the subscription expired
      </td>
    </tr>

    <tr>
      <td>
        <span id="expiration_reason">expiration_reason</span>
      </td>

      <td>
        Canceled, Non-payment, Fixed billing cycles, Tax Location Invalid, Nonpayment_gift, Nonpayment_trial
      </td>

      <td>
        The reason that the subscription expired. Note that nonpayment_Trial only relates to cardless subscriptions trials
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_id">ship_address_id</span>
      </td>

      <td>
        2019760433389770000
      </td>

      <td>
        The unique ID assigned to the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_nickname">ship_address_nickname</span>
      </td>

      <td>
        Julie
      </td>

      <td>
        The nickname given to the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_firstname">ship_address_firstname</span>
      </td>

      <td>
        Julie
      </td>

      <td>
        The first name associated with the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_lastname">ship_address_lastname</span>
      </td>

      <td>
        Smith
      </td>

      <td>
        The last name associated with the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_company_name">ship_address_company_name</span>
      </td>

      <td>
        Big Company
      </td>

      <td>
        The company name associated with the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_street1">ship_address_street1</span>
      </td>

      <td>
        321 Michigan Street
      </td>

      <td>
        The first line of the street address for the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_street2">ship_address_street2</span>
      </td>

      <td>
        Apt 1
      </td>

      <td>
        The second line of the street address for the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_city">ship_address_city</span>
      </td>

      <td>
        West Bloomfield
      </td>

      <td>
        The city for the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_state">ship_address_state</span>
      </td>

      <td>
        MI
      </td>

      <td>
        The state for the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_zip">ship_address_zip</span>
      </td>

      <td>
        48322
      </td>

      <td>
        The zip or postal code for the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_country">ship_address_country</span>
      </td>

      <td>
        US
      </td>

      <td>
        The country for the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_vat">ship_address_vat</span>
      </td>

      <td>
        123456789
      </td>

      <td>
        The VAT number associated with the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_email">ship_address_email</span>
      </td>

      <td>
        [jsmith@example.com](mailto:jsmith@example.com)
      </td>

      <td>
        The email address associated with the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="ship_address_phone">ship_address_phone</span>
      </td>

      <td>
        248-555-1212
      </td>

      <td>
        The phone number associated with the shipping address
      </td>
    </tr>

    <tr>
      <td>
        <span id="started_with_gift">started_with_gift</span>
      </td>

      <td>
        TRUE, FALSE
      </td>

      <td>
        `TRUE` if the subscription was started with a gift card, whether or not billing information was collected.
      </td>
    </tr>

    <tr>
      <td>
        <span id="converted_at">converted_at</span>
      </td>

      <td>
        2016-09-02 15:53:18 UTC
      </td>

      <td>
        Date of the first successful transaction for the subscription.  
        This field is only used for gifts cards and cardless free trial conversions.  
        In other words, it will only have a value if started_with_gift is `TRUE` OR no_billing_info_reason is "plan_free"trial." Converted_at compared to the subscription's activated_at will give you the time to conversion.
      </td>
    </tr>

    <tr>
      <td>
        <span id="no_billing_info_reason">no_billing_info_reason</span>
      </td>

      <td>
        plan_free_trial
      </td>

      <td>
        Identifies the reason why a subscription did not have billing information at time of renewal/activation.
      </td>
    </tr>

    <tr>
      <td>
        <span id="shipping_amount_in_cents">shipping_amount_in_cents</span>
      </td>

      <td>
        500
      </td>

      <td>
        The amount of the shipping fee on the subscription, in cents.
      </td>
    </tr>

    <tr>
      <td>
        <span id="shipping_method_code">shipping_method_code</span>
      </td>

      <td>
        usps_overnight
      </td>

      <td>
        The code of the Shipping Method from configuration.
      </td>
    </tr>

    <tr>
      <td>
        <span id="pricing_model">pricing_model</span>
      </td>

      <td>
        ramp
      </td>

      <td>
        Pricing model of the subscription. Will be either fixed or ramp.
      </td>
    </tr>

    <tr>
      <td>
        <span id="current_ramp_id">current_ramp_id</span>
      </td>

      <td>
        pz82514rbd3s
      </td>

      <td>
        The id of the current ramp interval.
      </td>
    </tr>

    <tr>
      <td>
        subscription_api_id
      </td>

      <td>
        e28zov4fw0v2
      </td>

      <td>
        Subscription API ID
      </td>
    </tr>
  </tbody>
</Table>

# Version changelog

### Version 4 - 2/5/2025

* Addition of `subscription_api_id`.

### Version 3 - 12/7/2021

* Column added for pricing_model
* Column added for current_ramp_id

### Version 2 - 5/2/2019

* Column added for Shipping Cost
* Column added for Shipping Method
