---
title: Items — associated plans - export
excerpt: >-
  Explore the Items - Associated Plans export to manage and track your catalog
  efficiently.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Required plan

This feature or setting is available to all customers on any Recurly subscription plan.

### Prerequisites

You must enable the credit invoices feature to view this export. Please reach out to your Recurly account manager or [support@recurly.com](mailto:support@recurly.com) to have this feature activated in your account.

# Definition

The "Items - Associated Plans" export function in Recurly permits users to generate a report containing detailed information on all plan add-ons created from a saved item in your catalog during a specified period. It focuses exclusively on add-ons that are presently linked to active plans, ensuring that your report only contains the most pertinent and up-to-date data.

<Image border={false} src="https://files.readme.io/973f35469c0ae83c9faaeb6fecbb36a8f1e69229cb6719d886f2cab4705a8b25-image.png" />

<br />

# Filters

### **Versions Filter**

* The Versions filter allows you to select the version that is most appropriate for your needs. This is based on the version changelog at the bottom of this page.

### **Item Name Filter**

The Item name filter allows you to select existing item by name, code or SKU

### **Time Range Filter**

This export can be filtered based on a specified time range using the "plan_add_on_created_at" date in the export.

* The Time range filter (dropdown) allows you to view data within a specific period such as last month, year to date or a custom date range. The Start Date and End Date will automatically update based on the value selected in the Time range filter. You can also choose "Between..." in the dropdown, which will allow you to enter a customized date range.

# Exports table

<HTMLBlock>{`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Button</title>
    <style>
        .download-button {
            display: inline-block;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            color: #1C2833FF; 
            background-color: #F8F8F8FF; 
            border-radius: 5px;
            font-weight: normal;
            transition: background-color 0.5s ease, transform 0.3s ease;
          	transition: 0.4s !important;
            font-family: 'Proxima-nova', Arial, sans-serif;
            max-width: 100%; 
        }

        .download-button:hover {
            background-color: #FFFFFFFF; 
            transform: scale(1.02); 
        }
      	a:hover {
          	color: #1C2833FF;
          	text-decoration: underline !important;
        }
      </style>
</head>
<body>
    <a href="https://docs.google.com/spreadsheets/d/1U0_Wl_NMScJqKBZoBKMmQnybmLEr0gFi6r7dfNiP9Qc/export?format=xlsx" class="download-button">Download our complete export schema</a>
</body>
</html>
`}</HTMLBlock>

To help you identify and organize information effectively, the export provides a structured table that contains the following columns:

| Column Name                                                                                 | Example                 | Description                                                                                               | Data type (max size) |
| ------------------------------------------------------------------------------------------- | ----------------------- | --------------------------------------------------------------------------------------------------------- | :------------------- |
| <span id="item_id">item_id</span>                                                           | l20fl6bek3mp            | The system-generated unique internal identifier of the saved item used to create this add-on.             | string               |
| <span id="item_name">item_name</span>                                                       | Pink Sweater            | The name of the saved item used to create this add-on. This is also the add-on name on the invoice.       | varchar(255)         |
| <span id="item_code">item_code</span>                                                       | pink_sweater            | The unique Recurly identifier of the saved item used to create this add-on. This is also the add-on code. | varchar(50)          |
| <span id="external_sku">external_sku</span>                                                 | PS1234                  | The optional external SKU of the saved item used to create this add-on.                                   | varchar(50)          |
| <span id="item_status">item_status</span>                                                   | enabled                 | The status of the item in your Recurly catalog, which can be "enabled" or "disabled".                     | string               |
| <span id="plan_code">plan_code</span>                                                       | platinum                | The unique Recurly identifier of the plan that offers this item as an add-on.                             | varchar(50)          |
| <span id="plan_name">plan_name</span>                                                       | Platinum Plan           | The current name of the plan that offers this item as an add-on.                                          | varchar(255)         |
| <span id="plan_add_on_unit_amount_in_cents">plan_add_on_unit_amount_in_cents</span>         | 1599                    | The cost (in cents) of a unit of the add-on.                                                              | numeric              |
| <span id="plan_add_on_currency">plan_add_on_currency</span>                                 | USD                     | The currency of the plan, which is the currency of the plan_add_on_unit_amount_in_cents.                  | varchar(3)           |
| <span id="plan_add_on_created_at">plan_add_on_created_at</span>                             | 2020-02-05 15:52:46 MST | The date and time the add-on was created, used for date range filtering.                                  | timestamp            |
| <span id="plan_add_on_modified_at">plan_add_on_modified_at</span>                           | 2020-02-05 15:52:46 MST | The date and time the add-on was last modified.                                                           | timestamp            |
| <span id="plan_add_on_tier_type">plan_add_on_tier_type</span>                               | flat                    | Add on Tier Type.                                                                                         | string               |
| <span id="plan_allow_any_item_on_subscriptions">plan_allow_any_item_on_subscriptions</span> | false                   | Whether the plan allows any item on subscriptions                                                         | boolean              |
| item_api_id                                                                                 | e28zov4fw0v2            | Item API ID                                                                                               | string               |

# Version changelog

### Version 6 - 2/5/2025

Addition of `item_api_id`.

### Version 5 - 5/31/2022

Removal of plan_add_on_tax_inclusive column.

### Version 4 - 1/13/2022

Addition of plan_add_on_tax_inclusive column.

### Version 3 - 7/23/2020

Addition of plan_allow_any_item_on_subscriptions column.

### Version 2 - 4/29/2020

Addition of plan_add_on_tier_type column.
