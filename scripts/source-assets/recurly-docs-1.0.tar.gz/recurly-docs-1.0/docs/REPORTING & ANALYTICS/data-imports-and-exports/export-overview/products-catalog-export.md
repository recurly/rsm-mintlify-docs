---
title: Product Catalog - export
excerpt: >-
  Unlock detailed insights into your product catalog with the product catalog
  export.
deprecated: false
hidden: false
metadata:
  robots: index
---
# Overview

### Required plan

This feature or setting is available to all customers on any Recurly subscription plan.

# Definition

The "Product Catalog" export provides comprehensive details of all product offerings, add-ons and items, whether active or inactive.

<Image align="center" border={false} width="85% " src="https://files.readme.io/e8967cc406e075014f934dd166ddece8b4303f8c68d855750943c31f5ff41fde-image.png" />

<br />

# Filters

### Versions Filter

* The Versions filter allows you to select the version that is most appropriate for your needs. This is based on the version changelog at the bottom of this page.

### **Product Type Filter**

The Product type filter allows you to select existing plan, add on, item or setup fee.

* **Add-on**: Additional features, services, or products that customers can purchase alongside their subscription plan.
* **Item**: Collection of the sellable units of a business. This can include standalone products, services, or even add-ons.
* **Plan**: Recurring billing products that define the billing frequency and the product's base price, allowing businesses to create a revenue model that provides consistent income.
* **Setup-fee**: One time initial fee.

### &#x20;Export On Filters

* **Created**: Product created within the chosen timeframe.
* **Modified**: Product altered in the specified period.

### Time range filters

* The Time range filter (dropdown) allows you to view data within a specific period such as last month, year to date or a custom date range. The Start Date and End Date will automatically update based on the value selected in the Time range filter. You can also choose "Between..." in the dropdown, which will allow you to enter a customized date range.

# Exports table

<HTMLBlock>{`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Button</title>
    <style>
        .download-button {
            display: inline-block;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            color: #1C2833FF; 
            background-color: #F8F8F8FF; 
            border-radius: 5px;
            font-weight: normal;
            transition: background-color 0.5s ease, transform 0.3s ease;
          	transition: 0.4s !important;
            font-family: 'Proxima-nova', Arial, sans-serif;
            max-width: 100%; 
        }

        .download-button:hover {
            background-color: #FFFFFFFF; 
            transform: scale(1.02); 
        }
      	a:hover {
          	color: #1C2833FF;
          	text-decoration: underline !important;
        }
      </style>
</head>
<body>
    <a href="https://docs.google.com/spreadsheets/d/1U0_Wl_NMScJqKBZoBKMmQnybmLEr0gFi6r7dfNiP9Qc/export?format=xlsx" class="download-button">Download our complete export schema</a>
</body>
</html>
`}</HTMLBlock>

To help you identify and organize information effectively, the export provides a structured table that contains the following columns:

Note: The unique identifier for each record is the combination of product_id, plan_id, and add_on_id. If an item type is configured as an add-on, it can be associated with multiple plans; in such cases, the same product_id is reused across those plans.

| Column Name                                                                   | Example                                                                                                                                   | Description                                                                                                                                                                                                                                                                                                           | Data type (max size) |
| :---------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------- |
| <span id="product_id:">product_id:</span>                                     | e28zov4fw0v2                                                                                                                              | The api_id of the product (this matches item_api_id)                                                                                                                                                                                                                                                                  | string               |
| <span id="plan_id">plan_id</span>                                             | p47mx1taq9b5                                                                                                                              | The api_id of the plan                                                                                                                                                                                                                                                                                                | string               |
| <span id="add_on_id">add_on_id</span>                                         | k91trm8xe2c7                                                                                                                              | The api_id of the add_on                                                                                                                                                                                                                                                                                              | string               |
| <span id="item_code">item_code</span>                                         | item123                                                                                                                                   | The Item Code maps to the user-specified unique ID of the item that was sold on this adjustment.                                                                                                                                                                                                                      | string               |
| <span id="product_type">product_type</span>                                   | plan, add_on, setup_fee, item                                                                                                             | The type of product.                                                                                                                                                                                                                                                                                                  | string               |
| <span id="state">state</span>                                                 | active, inactive                                                                                                                          | If the product is available in Recurly the state will be “active”, if the product has been deleted and is no longer available in Recurly then the state will be “inactive”.  It is possible for subscribers to have “inactive” products on their subscription                                                         | string               |
| <span id="product_code">product_code</span>                                   | pink_sweater                                                                                                                              | The unique Recurly identifier of the saved product used to create the product.                                                                                                                                                                                                                                        | string               |
| <span id="external_sku">external_sku</span>                                   | PS1234                                                                                                                                    | The optional external SKU of the saved item used to create this add-on.                                                                                                                                                                                                                                               | string               |
| <span id="product_name">product_name</span>                                   | Pink Sweater                                                                                                                              | The name of the saved product. This is also the name displayed on the invoice.                                                                                                                                                                                                                                        | string               |
| <span id="product_description">product_description</span>                     | Sweater, color pink                                                                                                                       | The description of the product.                                                                                                                                                                                                                                                                                       | string               |
| <span id="plan_code">plan_code</span>                                         | Gold                                                                                                                                      | If the product is associated with a plan or is a plan this is the code of the plan.                                                                                                                                                                                                                                   | string               |
| <span id="plan_name">plan_name</span>                                         | Gold Plan                                                                                                                                 | If the product is associated with a plan or is a plan this is the name of the plan.                                                                                                                                                                                                                                   | string               |
| <span id="plan_interval_unit">plan_interval_unit</span>                       | months, weeks, days, years                                                                                                                | The interval type at which that plan is billed.                                                                                                                                                                                                                                                                       | string               |
| <span id="plan_interval_length">plan_interval_length</span>                   | 30                                                                                                                                        | The length of the interval type at which the plan is billed at.                                                                                                                                                                                                                                                       | numeric              |
| <span id="plan_total_billing_cycles">plan_total_billing_cycles</span>         | 12                                                                                                                                        | The total number of bill cycles that the plan will bill for 1 term.                                                                                                                                                                                                                                                   | numeric              |
| <span id="plan_trial_interval_unit">plan_trial_interval_unit</span>           | months, weeks, days, years                                                                                                                | The interval type that indicates the duration of the trial.                                                                                                                                                                                                                                                           | string               |
| <span id="plan_trial_interval_length">plan_trial_interval_length</span>       | 12                                                                                                                                        | The length of the interval type that sets the duration of the trial.                                                                                                                                                                                                                                                  | numeric              |
| <span id="trial_requires_billing_info">trial_requires_billing_info</span>     | false                                                                                                                                     | Indicates if the trial requires billing info.                                                                                                                                                                                                                                                                         | boolean              |
| <span id="recurring">recurring</span>                                         | true/false                                                                                                                                | Indicates if this charge will be recurring.                                                                                                                                                                                                                                                                           | boolean              |
| <span id="optional">optional</span>                                           | true/false                                                                                                                                | Indicates if this is required as part of a plan.                                                                                                                                                                                                                                                                      | boolean              |
| <span id="tax_exempt">tax_exempt</span>                                       | true/false                                                                                                                                | Indicates if the product is tax exempt.                                                                                                                                                                                                                                                                               | boolean              |
| <span id="tax_code">tax_code</span>                                           | P0000000, physical                                                                                                                        | Tax code is a field associated with the product that we send to Avalara for tax calculations. If you are using Recurly's EU VAT feature, you can use values of 'unknown', 'physical', or 'digital'. If you have your own Avalara AvaTax account configured, you can use Avalara tax codes to assign custom tax rules. | string               |
| <span id="general_ledger_liability_code">general_ledger_liability_code</span> | default_liability                                                                                                                         | Revenue Recognition general ledger liability code                                                                                                                                                                                                                                                                     | string               |
| <span id="general_ledger_revenue_code">general_ledger_revenue_code</span>     | default_revenue                                                                                                                           | Revenue Recognition general ledger revenue code                                                                                                                                                                                                                                                                       | string               |
| <span id="performance_obligation_name">performance_obligation_name</span>     | Over Time (Daily)                                                                                                                         | Revenue Recognition performance obligation assigned to the product.                                                                                                                                                                                                                                                   | string               |
| <span id="accounting_code">accounting_code</span>                             | jr_accounting_code                                                                                                                        | Optional accounting_code assigned to the product.                                                                                                                                                                                                                                                                     | string               |
| <span id="default_quantity">default_quantity</span>                           | 1                                                                                                                                         | Default quantity assigned to the product (default is 1)                                                                                                                                                                                                                                                               | numeric              |
| <span id="pricing_model">pricing_model</span>                                 | fixed                                                                                                                                     | This is the method the product is billed. Values include fixed, usage, tiered, ramp, volume, stairstep, percentage                                                                                                                                                                                                    | string               |
| <span id="currencies">currencies</span>                                       | `[{"currency":"EUR","price_details":[{"unit_amount_in_cents":1000}]},{"currency":"USD","price_details":[{"unit_amount_in_cents":1000}]}]` | Json object of the currencies and associated prices                                                                                                                                                                                                                                                                   | string               |
| <span id="custom_fields">custom_fields</span>                                 | `{"item": "so_custom_field"}`                                                                                                             | Json object of any custom fields that are assigned to the product                                                                                                                                                                                                                                                     | string               |
| <span id="created_at">created_at</span>                                       | 2025-11-12 08:23:34 UTC                                                                                                                   | Timestamp when the product was created                                                                                                                                                                                                                                                                                | timestamp            |
| <span id="modified_at">modified_at</span>                                     | 2025-11-12 08:23:34 UTC                                                                                                                   | Timestamp when the product was last modified                                                                                                                                                                                                                                                                          | timestamp            |
| <span id="deleted_at">deleted_at</span>                                       | 2025-11-12 08:23:34 UTC                                                                                                                   | Timestamp when the product was deleted                                                                                                                                                                                                                                                                                | timestamp            |

# Version changelog

<br />
