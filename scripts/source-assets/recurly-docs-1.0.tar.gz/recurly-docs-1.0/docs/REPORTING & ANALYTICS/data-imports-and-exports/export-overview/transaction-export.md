---
title: Transactions - export
excerpt: >-
  Maximize your understanding of every payment interaction with the
  comprehensive Transactions export.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Required plan

This feature or setting is available to all customers on any Recurly subscription plan.

# Definition

The Transactions export section provides a detailed report of all interactions communicated to and received from the payment gateway while processing a transaction. This data gives you a deeper understanding of every payment interaction to help you manage your financial transactions better.

<Image border={false} src="https://files.readme.io/4ce84800f4dd8c61fb58d053ee88190c6fab4f252215f25b32b0f4ee000fb7fb-image.png" />

# Filters

### Versions Filter

* The Versions filter allows you to select the version that is most appropriate for your needs. This is based on the version changelog at the bottom of this page.

### &#x20;Export On Filters

* **Created**: Transactions created within the chosen timeframe.
* **Modified**: Transactions altered in the specified period.

### Time range filters

* The Time range filter (dropdown) allows you to view data within a specific period such as last month, year to date or a custom date range. The Start Date and End Date will automatically update based on the value selected in the Time range filter. You can also choose "Between..." in the dropdown, which will allow you to enter a customized date range.

# Exports table

<HTMLBlock>{`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Button</title>
    <style>
        .download-button {
            display: inline-block;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            color: #1C2833FF; 
            background-color: #F8F8F8FF; 
            border-radius: 5px;
            font-weight: normal;
            transition: background-color 0.5s ease, transform 0.3s ease;
          	transition: 0.4s !important;
            font-family: 'Proxima-nova', Arial, sans-serif;
            max-width: 100%; 
        }

        .download-button:hover {
            background-color: #FFFFFFFF; 
            transform: scale(1.02); 
        }
      	a:hover {
          	color: #1C2833FF;
          	text-decoration: underline !important;
        }
      </style>
</head>
<body>
    <a href="https://docs.google.com/spreadsheets/d/1U0_Wl_NMScJqKBZoBKMmQnybmLEr0gFi6r7dfNiP9Qc/export?format=xlsx" class="download-button">Download our complete export schema</a>
</body>
</html>
`}</HTMLBlock>

To help you identify and organize information effectively, the export provides a structured table that contains the following columns:

| Column Name                                                             | Example                                   | Description                                                                                                                                                                                                            |
| :---------------------------------------------------------------------- | :---------------------------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| <span id="account_code">account_code</span>                             | 123sd341                                  | The specific account code charged during the transaction.                                                                                                                                                              |
| <span id="name">name</span>                                             | JJ Smith                                  | Customer name as stated in their billing data.                                                                                                                                                                         |
| <span id="transaction_id">transaction_id</span>                         | 6c17ba39e8734ebaa5bf98fff6d91bb9          | Unique identifier for the transaction within Recurly.                                                                                                                                                                  |
| <span id="type">type</span>                                             | authorization, purchase, refund           | Specifies the type of transaction reported to the gateway.                                                                                                                                                             |
| <span id="amount">amount</span>                                         | 9.95                                      | The total amount of the transaction sent to the payment gateway.                                                                                                                                                       |
| <span id="tax_amount">tax_amount</span>                                 | 15.00                                     | The tax charges associated with the transaction.                                                                                                                                                                       |
| <span id="currency">currency</span>                                     | USD                                       | The currency reported to the payment gateway for transaction processing.                                                                                                                                               |
| <span id="date">date</span>                                             | 2012-01-19 11:16:41 PST                   | The date and time the transaction took place. Used for "created" date range filter.                                                                                                                                    |
| <span id="status">status</span>                                         | declined, void, success, processing       | The response received from the payment gateway concerning the transaction.                                                                                                                                             |
| <span id="message">message</span>                                       | This transaction has been approved        | Message received from the payment gateway regarding the transaction.                                                                                                                                                   |
| <span id="test">test</span>                                             | TRUE, FALSE                               | Indicates if the transaction was carried out on a production gateway.                                                                                                                                                  |
| <span id="cc_type">cc_type</span>                                       | visa, master, discover, amex, jcb, diners | The type of credit card utilized for the transaction.                                                                                                                                                                  |
| <span id="cvv_result">cvv_result</span>                                 | M, N                                      | The result from checking the CVV/CVC value on the transaction when it was processed.                                                                                                                                   |
| <span id="avs_result">avs_result</span>                                 | N, P, D                                   | The overall AVS result from checking the transaction when it was processed.                                                                                                                                            |
| <span id="avs_result_postal">avs_result_postal</span>                   | N, Y                                      | The result from verifying the zip code on the transaction when it was processed.                                                                                                                                       |
| <span id="avs_result_street">avs_result_street</span>                   | N, Y                                      | The result from verifying the address 1 value on the transaction when it was processed.                                                                                                                                |
| <span id="reference">reference</span>                                   | 4119385445                                | The identifier for the transaction from the payment gateway.                                                                                                                                                           |
| <span id="approval_code">approval_code</span>                           | varies by gateway                         | The approval code for the transaction from the payment gateway.                                                                                                                                                        |
| <span id="description">description</span>                               | varies by gateway                         | The description sent to the payment gateway for the transaction.                                                                                                                                                       |
| <span id="state">state</span>                                           | CA                                        | The state value from the customer's billing information on the account.                                                                                                                                                |
| <span id="country">country</span>                                       | US                                        | The country value from the customer's billing information on the account.                                                                                                                                              |
| <span id="ip_address_country">ip_address_country</span>                 | US                                        | The country associated with the IP address of the customer's location when the transaction was processed.                                                                                                              |
| <span id="original_transaction_id">original_transaction_id</span>       | 6b9fc18e2497498b9e3700cd55e2ea84          | For refunds, this field identifies the payment being refunded.                                                                                                                                                         |
| <span id="invoice_id">invoice_id</span>                                 | 4bdb2171cebe4ecfb0cb129bd1a65746          | References the invoice that generated this transaction.                                                                                                                                                                |
| <span id="subscription_id">subscription_id</span>                       | 3252sdasdbe4ecfb0cb129bd1a65746           | References the subscription or list of subscriptions that instigated this transaction.                                                                                                                                 |
| <span id="po_number">po_number</span>                                   | AE12523                                   | The purchase order number for the invoice.                                                                                                                                                                             |
| <span id="collection_method">collection_method</span>                   | automatic, manual                         | The type of collection method used for the invoice.                                                                                                                                                                    |
| <span id="transaction_gateway_type">transaction_gateway_type</span>     | test, wirecard, authorize, etc            | The payment gateway utilized to process the transaction.                                                                                                                                                               |
| <span id="modified_at">modified_at</span>                               | 2014-01-01 10:00:00 PST                   | The date/time the transaction was last updated. Used for the "modified" date range filter.                                                                                                                             |
| <span id="origin">origin</span>                                         | recurring, API, hpp                       | Identifies what initiated the transaction.                                                                                                                                                                             |
| <span id="gateway_error_codes">gateway_error_codes</span>               | 500                                       | Lists the gateway error code for declined transactions, if applicable.                                                                                                                                                 |
| <span id="payment_method">payment_method</span>                         | PayPal, Amazon Payment, Credit Card, etc  | Specifies the method used for payment.                                                                                                                                                                                 |
| <span id="collected_at">collected_at</span>                             | 2014-01-01 10:00:00 PST                   | For manually recorded payments, this reflects the specified date when recording the transaction.                                                                                                                       |
| <span id="fraud_decision">fraud_decision</span>                         | DECLINE, REVIEW, APPROVE                  | Contains the decision returned by the Kount risk check service for this transaction.  This data mirrors the fraud info api object.                                                                                     |
| <span id="fraud_score">fraud_score</span>                               | 36 (between 1 and 99)                     | The risk score assigned by Kount's risk check service for this transaction. This data mirrors the fraud info api object.                                                                                               |
| <span id="fraud_message">fraud_message</span>                           | "848742"=>"BIN \<> Billing Country"       | Contains all the rules triggered during the Kount's risk check service. Each number is the fraud_risk_rule code and the text that follows is the fraud_risk_rule message. This data mirrors the fraud info api object. |
| <span id="failure_type">failure_type</span>                             | invalid_payment_method_hard               | Provides additional information regarding the failure type of a transaction.                                                                                                                                           |
| <span id="gateway_code">gateway_code</span>                             | ih06u98jfoto                              | The gateway used for each transaction is denoted here.                                                                                                                                                                 |
| <span id="cc_first_6">cc_first_6</span>                                 | 111111                                    | The first six digits of the credit card used for processing the transaction.                                                                                                                                           |
| <span id="vat_number">vat_number</span>                                 | EU12345678                                | The VAT or Tax ID number of the customer during the transaction in the export.                                                                                                                                         |
| <span id="backup_payment_method_used">backup_payment_method_used</span> | TRUE, FALSE                               | Indicates whether a backup payment method was used in the transaction attempt.                                                                                                                                         |
| <span id="vat_number">vat_number</span>                                 | 123456                                    | Indicates vat number.                                                                                                                                                                                                  |
| <span id="card_brand">card_brand</span>                                 | Mastercard                                | Card brand                                                                                                                                                                                                             |
| <span id="card_type">card_type</span>                                   | credit                                    | Card type                                                                                                                                                                                                              |
| <span id="card_level">card_level</span>                                 | prepaid                                   | Card level                                                                                                                                                                                                             |
| <span id="card_issuer">card_issuer</span>                               | JP Morgan Chase Bank NA                   | Card issuer                                                                                                                                                                                                            |
| <span id="card_issuing_country">card_issuing_country</span>             | US                                        | Card issuing country                                                                                                                                                                                                   |
| <span id="transaction_api_id">transaction_api_id</span>                 | gyqgg0d3v9n1                              | v3 API identifier for the transaction within Recurly.                                                                                                                                                                  |
| <span id="payment_method_identifier">payment_method_identifier</span>   | 1ai9th6o82f6v                             | Payment method identifier                                                                                                                                                                                              |
| <span id="cc_last_4">cc_last_4</span>                                   | 1234                                      | Card last 4 digits                                                                                                                                                                                                     |
| <span id="expire_month">expire_month</span>                             | 12                                        | Card expiration month                                                                                                                                                                                                  |
| <span id="expire_year">expire_year</span>                               | 2025                                      | Card expiration year                                                                                                                                                                                                   |
| <span id="processor_response_code">processor_response_code</span>       | 51                                        | Transaction processor response code                                                                                                                                                                                    |
| <span id="processor_response_text">processor_response_text</span>       | Insufficient funds/over credit limit      | Transaction processor response text                                                                                                                                                                                    |
| <span id="issuer_response_code">issuer_response_code</span>             | 51                                        | Issuer response code                                                                                                                                                                                                   |
| <span id="billing_info_id">billing_info_id</span>                       | igpvyfx08knw                              | Billing Info API ID                                                                                                                                                                                                    |

# Version changelog

### Version 9 - 10/14/2025

* **Column Additions**: Addition of payment_method_identifier, cc_last_4, expire_month, expire_year, processor_response_code, processor_response_text, issuer_response_code and billing_info_id.

### Version 8 - 10/5/2024

* **Column Additions**: Addition of transaction_api_id.

### Version 7 - 9/24/2024

* **Column Additions**: Addition of card_brand, card_type, card_level, card_issuer, card_issuing_country columns.

### Version 6 - 8/1/2023

* **Column Changes**: Introduced "vat_number" column for merchants to capture customer's VAT or Tax ID number during a transaction in the export.

### Version 5 - 4/20/21

* **Column Changes**: The 'backup_payment_method_used' column was added at the end of the export to identify transactions initiated through a backup payment method attempt.

### Version 4 - 5/23/2019

* **Column Changes**: 'cc_first_6' column incorporated at the end of the export.

### Version 3 - 4/25/2019

* **Column Additions**: Addition of "cc_first_6" column.

### Version 2 - 1/15/2019

* **Mapping**: New payment gateway mappings included for Adyen, Qiwi, SEPA, SOFORT, and iDeal.
