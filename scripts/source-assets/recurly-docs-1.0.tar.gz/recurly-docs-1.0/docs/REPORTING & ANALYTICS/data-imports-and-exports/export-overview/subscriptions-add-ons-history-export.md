---
title: Subscription add-ons — history  - export
excerpt: >-
  Delve into the rich history of your subscription add-ons and leverage valuable
  insights with our detailed export feature in the "Subscription Add-ons —
  History" section.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Required plan

This feature or setting is available to all customers on any Recurly subscription plan.

### Prerequisites

Please reach out to your Recurly account manager or [support@recurly.com](mailto:support@recurly.com) to have this feature activated in your account.

# Definition

Explore the subscription add-on history feature that allows tracking all the changes made to a subscription add-on over time. Every time a change or multiple changes are made simultaneously, a new version of the subscription add-on history is created. This feature is vital for keeping historical versions of add-ons that change on subscriptions. The oldest historical data available for this export is April 2019.

<Image border={false} src="https://files.readme.io/a8af2a1c6dce65ec6d6ce49fa08ebe63610dd52973be9e54b4387f369503744a-image.png" />

# Filters

### **Versions Filter**

* The Versions filter allows you to select the version that is most appropriate for your needs. This is based on the version changelog at the bottom of this page.

### Subscription Status Filter

* **All**: Displays all subscription history status.
* **Trial**: Displays all subscription history respective to trial status.
* **Open**: Displays all subscription history respective to open status.
* **Canceled**: Displays all subscription history respective to canceled status.
* **Expired**: Displays all subscription history respective to expired status.

### Export On Filters

* **Activated** - showcases the past versions of subscription add-ons that were activated or reactivated within the chosen time frame. It utilizes the `subscription_activated_at` column for data representation.
* **Version Created** - depicts the past versions of subscription add-ons generated during a specified time range, utilizing data from the `version_started_at` column.
* **Version Modified** - view recent alterations to all subscriptions within a chosen time range, referring to a combination of _version_state_ and version_started_at columns.

### **Time Range Filter**

* The Time range filter (dropdown) allows you to view data within a specific period such as last month, year to date or a custom date range. The Start Date and End Date will automatically update based on the value selected in the Time range filter. You can also choose "Between..." in the dropdown, which will allow you to enter a customized date range.

# Exports table

<HTMLBlock>{`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Button</title>
    <style>
        .download-button {
            display: inline-block;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            color: #1C2833FF; 
            background-color: #F8F8F8FF; 
            border-radius: 5px;
            font-weight: normal;
            transition: background-color 0.5s ease, transform 0.3s ease;
          	transition: 0.4s !important;
            font-family: 'Proxima-nova', Arial, sans-serif;
            max-width: 100%; 
        }

        .download-button:hover {
            background-color: #FFFFFFFF; 
            transform: scale(1.02); 
        }
      	a:hover {
          	color: #1C2833FF;
          	text-decoration: underline !important;
        }
      </style>
</head>
<body>
    <a href="https://docs.google.com/spreadsheets/d/1U0_Wl_NMScJqKBZoBKMmQnybmLEr0gFi6r7dfNiP9Qc/export?format=xlsx" class="download-button">Download our complete export schema</a>
</body>
</html>
`}</HTMLBlock>

To help you identify and organize information effectively, the export provides a structured table that contains the following columns:

<Table align={["left","left","left","left"]}>
  <thead>
    <tr>
      <th>
        Column Name
      </th>

      <th>
        Example
      </th>

      <th>
        Description
      </th>

      <th>
        Data type (max size)
      </th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td>
        subscription_uuid
      </td>

      <td>
        434f11do8b297982eb
      </td>

      <td>
        Unique internal identifier for the subscription. Even if a subscription is modified, this identifier is maintained.
      </td>

      <td>
        varchar(32)
      </td>
    </tr>

    <tr>
      <td>
        version_uuid
      </td>

      <td>
        43509049eb30fb
      </td>

      <td>
        Unique internal identifier for the version of a subscription_uuid.  
        A new version if created when a change is made to a subscription. If multiple different changes are made at the same time,  all will be captured in the same new version.
      </td>

      <td>
        string
      </td>
    </tr>

    <tr>
      <td>
        account_code
      </td>

      <td>
        123456789,  
        [test@example.com](mailto:test@example.com)
      </td>

      <td>
        Account associated with a given subscription_uuid.
      </td>

      <td>
        varchar(50)
      </td>
    </tr>

    <tr>
      <td>
        subscription_activated_at
      </td>

      <td>
        2018-03-24 17:18:46 PDT
      </td>

      <td>
        Date and time the subscription became active (or reactivated) on an account. Note that this might not always match exactly with the subscription_created_At date if a subscription is created with a future start date.
      </td>

      <td>
        timestamp
      </td>
    </tr>

    <tr>
      <td>
        subscription_expires_at
      </td>

      <td>
        2018-09-24 17:18:46 PDT
      </td>

      <td>
        Date and time the subscription was/ will churn.

        This field is populated when a subscription cancels with the expected expiration date.
      </td>

      <td>
        timestamp
      </td>
    </tr>

    <tr>
      <td>
        subscription_state
      </td>

      <td>
        active, canceled, paused,  
        expired
      </td>

      <td>
        State of the subscription at the time the version was active.
      </td>

      <td>
        string
      </td>
    </tr>

    <tr>
      <td>
        version_started_at
      </td>

      <td>
        2018-03-20 03:22:25 EST
      </td>

      <td>
        The date a change was made to the subscription and thus the new version was created.
      </td>

      <td>
        timestamp
      </td>
    </tr>

    <tr>
      <td>
        version_ended_at
      </td>

      <td>
        2018-07-20 03:22:25 EST
      </td>

      <td>
        The date a version is no longer active because another change to the subscription is a made and a newer version is created.  
        All versions with the version_state of "inactive" will have a version_expired_at date.
      </td>

      <td>
        timestamp
      </td>
    </tr>

    <tr>
      <td>
        version_state
      </td>

      <td>
        inactive or active
      </td>

      <td>
        the versions of a subscription that reflect the current attributes of that subscription (i.e are currently in use) are "active." All expired versions are "inactive"
      </td>

      <td>
        string
      </td>
    </tr>

    <tr>
      <td>
        plan_code
      </td>

      <td>
        bronze_1
      </td>

      <td>
        the plan that the subscription was actively on while that version was active. Codes are used internally only.
      </td>

      <td>
        varchar(50)
      </td>
    </tr>

    <tr>
      <td>
        plan_name
      </td>

      <td>
        Bronze Plan # 1
      </td>

      <td>
        The name of the plan the subscriber was actively on while that version was active.
      </td>

      <td>
        varchar(25)
      </td>
    </tr>

    <tr>
      <td>
        subscription_currency
      </td>

      <td>
        USD, GBP, CAD
      </td>

      <td>
        The currency associated with that subscription at the time that version was active
      </td>

      <td>
        varchar(3)
      </td>
    </tr>

    <tr>
      <td>
        version_plan_interval_unit
      </td>

      <td>
        months, weeks, days, years
      </td>

      <td>
        The interval type at which that subscription is billed while that version was active.  Combined with the version_plan_internval_length, you can understand how often your customer is billed  
        example: 1 month, 2 months, 1 year, etc.
      </td>

      <td>
        varchar(10)
      </td>
    </tr>

    <tr>
      <td>
        version_plan_interval_length
      </td>

      <td>
        any number
      </td>

      <td>
        The length of the interval type at which the subscription is billed at while the version was active.  
        Example: 1 month, 2 months, 1 year ,etc
      </td>

      <td>
        numeric(10)
      </td>
    </tr>

    <tr>
      <td>
        version_collection_method
      </td>

      <td>
        automatic, manual
      </td>

      <td>
        Identifies whether the subscription fees are collected via manual or automatic invoicing.
      </td>

      <td>
        string
      </td>
    </tr>

    <tr>
      <td>
        version_total_billing_cycles
      </td>

      <td>
        1
      </td>

      <td>
        If configured on the plan, the total number of bill cycles that the subscription will bill at the time the version was active.  
        If not specifically configured, the subscription will auto renew and this field will be blank.
      </td>

      <td>
        numeric
      </td>
    </tr>

    <tr>
      <td>
        version_subscription_quantity
      </td>

      <td>
        1, 2
      </td>

      <td>
        Identifies the quantity of the subscription purchase at the time the version was active.
      </td>

      <td>
        numeric
      </td>
    </tr>

    <tr>
      <td>
        version_subscription_unit_amount
      </td>

      <td>
        100
      </td>

      <td>
        Identifies the base price of 1 quantity of the subscription at the time the version was active.
      </td>

      <td>
        numeric
      </td>
    </tr>

    <tr>
      <td>
        version_add_on_code
      </td>

      <td>
        add_on1, add_on1,  add_on2
      </td>

      <td>
        A list of add ons that were active on the subscription at the time the version was active.  
        If there is more than one of the same add_on, it will be listed the same number of times as the quantity.
      </td>

      <td>
        varchar(50)
      </td>
    </tr>

    <tr>
      <td>
        version_add_on_quantity
      </td>

      <td>
        1
      </td>

      <td>
        Identifies the quantity of the add-on at the time the version was active.
      </td>

      <td>
        numeric
      </td>
    </tr>

    <tr>
      <td>
        version_add_on_type
      </td>

      <td>
        fixed, fixed, usage
      </td>

      <td>
        Lists the type of add_on in corresponding order to the listed add_on_codes on the subscription at the time the version was active.
      </td>

      <td>
        string
      </td>
    </tr>

    <tr>
      <td>
        version_add_on_unit_amount
      </td>

      <td>
        10, 10, 5%
      </td>

      <td>
        Lists the unit amount of the add_on in corresponding order to the listed add_on_codes and listed add_on_types.  
        If the add_on_type is "usage" the "%" will be listed
      </td>

      <td>
        numeric
      </td>
    </tr>

    <tr>
      <td>
        version_add_ons_total
      </td>

      <td>
        20
      </td>

      <td>
        Sums the add_on_unit_amounts on the subscription at the time the version was active.  
        Does not include usage based add ons.
      </td>

      <td>
        numeric
      </td>
    </tr>

    <tr>
      <td>
        version_total_recurring_amount
      </td>

      <td>
        120
      </td>

      <td>
        (version_unit_amount) * (version_subscription_quantity) + version_add_on_total
      </td>

      <td>
        numeric
      </td>
    </tr>

    <tr>
      <td>
        version_in_trial
      </td>

      <td>
        Y, N
      </td>

      <td>
        Indicates whether or not the subscription was in trial while the version was active.
      </td>

      <td>
        boolean
      </td>
    </tr>

    <tr>
      <td>
        version_auto_renew
      </td>

      <td>
        Y, N
      </td>

      <td>
        Indicates whether or not the subscription was set to auto renew while the version was active.
      </td>

      <td>
        boolean
      </td>
    </tr>

    <tr>
      <td>
        version_renewal_billing_cycles
      </td>

      <td>
        1
      </td>

      <td>
        Indicated the number of billing cycles a subscription will have after the end of the subscription term.
      </td>

      <td>
        numeric
      </td>
    </tr>

    <tr>
      <td>
        external_sku
      </td>

      <td>
        093094f0420
      </td>

      <td>
        * <br />
      </td>

      <td>
        varchar(50)
      </td>
    </tr>

    <tr>
      <td>
        version_add_on_tier_type
      </td>

      <td>
        flat, tiered, volume, stairstep
      </td>

      <td>
        The pricing model used to calculate the costs for the subscriptions based on the quantity purchased.
      </td>

      <td>
        string
      </td>
    </tr>

    <tr>
      <td>
        version_add_on_source
      </td>

      <td>
        * <br />
      </td>

      <td>
        * <br />
      </td>

      <td>
        string
      </td>
    </tr>

    <tr>
      <td>
        version_add_on_unit_amount_decimal
      </td>

      <td>
        * <br />
      </td>

      <td>
        * <br />
      </td>

      <td>
        numeric
      </td>
    </tr>

    <tr>
      <td>
        version_add_on_billing_model
      </td>

      <td>
        * <br />
      </td>

      <td>
        * <br />
      </td>

      <td>
        string
      </td>
    </tr>

    <tr>
      <td>
        subscription_api_id
      </td>

      <td>
        e28zov4fw0v2
      </td>

      <td>
        Subscription API ID
      </td>

      <td>
        string
      </td>
    </tr>

    <tr>
      <td>
        subscription_add_on_api_id
      </td>

      <td>
        e28zov4fw0v2
      </td>

      <td>
        Add on API ID
      </td>

      <td>
        string
      </td>
    </tr>
  </tbody>
</Table>

# Version changelog

### Version 6 - 2/5/2025

* Addition of `subscription_api_id` and `subscription_add_on_api_id`.

### **Version 5 - 3/9/2022**

* Introduced a new column version_add_on_billing_model.

### **Version 4 - 1/22/2021**

* Introduced a new column version_add_on_unit_amount_decimal.

### **Version 3 - 6/23/2020**

* Introduced a new column version_add_on_source.

### **Version 2 - 4/2/2020**

* Introduced a new column for external SKU concerning saved item add-ons.
* Introduced a new column version_add_on_tier_type.
