---
title: Invoices — unused numbers - export
excerpt: >-
  Discover your Recurly invoice data effortlessly with the Invoices -  Unused
  numbers feature.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Required plan

This feature or setting is available to all customers on any Recurly subscription plan.

# Definition

The unused invoice number export showcases the fundamental details of all the invoice numbers that have not been utilized in successfully generated invoices. Situations such as failed sign-ups could result in an unused invoice number.

This log aids significantly in audit procedures, supplementing the numbers provided in the Invoices - Summary export to furnish a detailed account for every number in your sequence. The oldest historical data available for this export is July 2019.

<Image border={false} src="https://files.readme.io/9938ab519bfe268f32c3976f52caa75a2fa2446e156aa593b2e99a0aafe2a45f-image.png" />

# Filters

### Versions Filter

* The Versions filter allows you to select the version that is most appropriate for your needs. This is based on the Version changelog at the bottom of this page.

### Time range filters

* The Time range filter (dropdown) allows you to view data within a specific period such as last month, year to date or a custom date range. The Start Date and End Date will automatically update based on the value selected in the Time range filter. You can also choose "Between..." in the dropdown, which will allow you to enter a customized date range.

# Exports table

<HTMLBlock>{`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Button</title>
    <style>
        .download-button {
            display: inline-block;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            color: #1C2833FF; 
            background-color: #F8F8F8FF; 
            border-radius: 5px;
            font-weight: normal;
            transition: background-color 0.5s ease, transform 0.3s ease;
          	transition: 0.4s !important;
            font-family: 'Proxima-nova', Arial, sans-serif;
            max-width: 100%; 
        }

        .download-button:hover {
            background-color: #FFFFFFFF; 
            transform: scale(1.02); 
        }
      	a:hover {
          	color: #1C2833FF;
          	text-decoration: underline !important;
        }
      </style>
</head>
<body>
    <a href="https://docs.google.com/spreadsheets/d/1U0_Wl_NMScJqKBZoBKMmQnybmLEr0gFi6r7dfNiP9Qc/export?format=xlsx" class="download-button">Download our complete export schema</a>
</body>
</html>
`}</HTMLBlock>

To help you identify and organize information effectively, the export provides a structured table that contains the following columns:

| Column Name                                         | Example                                                                                                                                                                          | Description                                                                                                                                                                                                                                                                                                                                                                              | Data type (max size) |
| :-------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------- |
| <span id="invoice_number">invoice_number</span>     | 1291                                                                                                                                                                             | External invoice identifier.                                                                                                                                                                                                                                                                                                                                                             | string               |
| <span id="invoice_type">invoice_type</span>         | purchase, refund, renewal, immediate_change, termination, credit, gift_card, write_off, external_refund, carryforward_credit, carryforward_gift_credit, usage_correction, import | This refers to the origin of the invoice. The primary invoice possesses a 'purchase' type. Negative invoices generated due to refunds or voids to offset the initial one have a 'refund' type. Other invoice types become accessible when the Credit Invoices feature is activated. Detailed descriptions can be found in the [invoice origins section](/docs/invoices#section-origins). | string               |
| <span id="invoice_doc_type">invoice_doc_type</span> | legacy, charge, credit                                                                                                                                                           | This column indicates the document type of the invoice. Before activating the Credit Invoices feature, all invoices bear the 'legacy' type. Post activation, the invoices are categorized as either 'charge' or 'credit'.                                                                                                                                                                | string               |
| <span id="invoice_date">invoice_date</span>         | 2019-07-19 12:01:33 PST                                                                                                                                                          | The date and time the invoice creation was attempted. The inception date for this export is July 1, 2019.                                                                                                                                                                                                                                                                                | timestamp            |
| invoice_api_id                                      | e28zov4fw0v2                                                                                                                                                                     | Invoice API ID                                                                                                                                                                                                                                                                                                                                                                           | string               |

# Version changelog

### Version 2 - 2/5/2025

* Addition of `invoice_api_id`
