---
title: Coupons — bulk unique codes - export
excerpt: >-
  Uncover intricate details of your bulk unique coupons with this exclusive
  Coupons - Bulk Unique Codes export.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Required plan

This feature or setting is available to all customers on any Recurly subscription plan.

### Prerequisites

This export will only appear on the Exports page if you have created a bulk coupon on your site.

# Definition

The Coupons - Bulk Unique Codes export section allows users to export and analyze all the unique codes pertaining to a specific bulk coupon. This includes redemption details for each code. This export option becomes available on the Exports page once a bulk coupon is created on your site. It enables a meticulous breakdown of each code's performance and status, providing insights that can aid in optimizing coupon strategies.

<Image border={false} src="https://files.readme.io/cdf6e7a27e32fd4aa4155e4fcd1c6ef987d48a28b0c010a8277c99446ecdbd5a-image.png" />

<br />

# Filters

### **Versions Filter**

* The Versions filter allows you to select the version that is most appropriate for your needs. This is based on the Version changelog at the bottom of this page.

### **Bulk Unique Coupon Filter**

* To utilize this filter, select all or the desired bulk coupon from a dropdown menu that enumerates the internal name of the coupon and the prefix of the codes, enclosed in parentheses. This list is alphabetically arranged according to the internal names of the coupons.

### **Export On Filter**

* **Created** - defines the date range according to the 'created_at' column in the export. Leveraging the "All Time" option with "Created" will showcase the entire compilation of your unique codes. To zero in on a subset of codes crafted during a specific span of the campaign, simply filter the dates accordingly.
* **Modified**- establishes the date range based on the most recent modification date, aligned with the 'modified_at' column in the export. A unique code experiences modification upon its redemption (tracked in 'applied_at') or premature expiration (noted in 'deactivated_at'). The expiration date ('expired_at') does not constitute a modification event.

### Time Range Filter

* The Time range filter (dropdown) allows you to view data within a specific period such as last month, year to date or a custom date range. The **Start Date** and **End Date** will automatically update based on the value selected in the Time range filter. You can also choose "Between..." in the dropdown, which will allow you to enter a customized date range.

<br />

# Exports table

<HTMLBlock>{`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Button</title>
    <style>
        .download-button {
            display: inline-block;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            color: #1C2833FF; 
            background-color: #F8F8F8FF; 
            border-radius: 5px;
            font-weight: normal;
            transition: background-color 0.5s ease, transform 0.3s ease;
          	transition: 0.4s !important;
            font-family: 'Proxima-nova', Arial, sans-serif;
            max-width: 100%; 
        }

        .download-button:hover {
            background-color: #FFFFFFFF; 
            transform: scale(1.02); 
        }
      	a:hover {
          	color: #1C2833FF;
          	text-decoration: underline !important;
        }
      </style>
</head>
<body>
    <a href="https://docs.google.com/spreadsheets/d/1U0_Wl_NMScJqKBZoBKMmQnybmLEr0gFi6r7dfNiP9Qc/export?format=xlsx" class="download-button">Download our complete export schema</a>
</body>
</html>
`}</HTMLBlock>

To help you identify and organize information effectively, the export provides a structured table that contains the following columns:

| **<span id="Id">Id</span>**                                         | **Example**                       | **Description**                                                                                                                                                                                  |        |
| ------------------------------------------------------------------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | :----- |
| <span id="bulk_coupon_id">bulk_coupon_id</span>                     | 769158967603640335                | UUID identifying the bulk coupon campaign, referential to the id in the Coupons export.                                                                                                          |        |
| <span id="bulk_coupon_prefix">bulk_coupon_prefix</span>             | save                              | Prefix common to all unique codes, mapped to the coupon_code of the bulk coupon in the Coupons export.                                                                                           |        |
| <span id="unique_coupon_code">unique_coupon_code</span>             | save-012478                       | Specific code for the bulk coupon, displayed as the coupon_code in the Coupon Redemptions export where the customer applied it at redemption.                                                    |        |
| <span id="discount">discount</span>                                 | 5                                 | Details of the fixed amount discount, which is applicable post-redemption, with the associated currency being showcased in the currency column. Maintains a null value for percentage discounts. |        |
| <span id="discount_percent">discount_percent</span>                 | 5                                 | Represents the percentage discount, remaining visible irrespective of the redemption status. Assumes a null value for fixed amount discounts.                                                    |        |
| <span id="timeframe">timeframe</span>                               | forever                           | Stipulates the active duration of the coupon.                                                                                                                                                    |        |
| <span id="redeem_by_date">redeem_by_date</span>                     | 2015-10-10 11:59:59 PST           | Defines the expiration date and time post which the code becomes non-redeemable. Always set at 11:59:59 PST of the designated day.                                                               |        |
| <span id="created_at">created_at</span>                             | 2015-09-07 19:23:03 PST           | Marks the creation date and time of the unique code.                                                                                                                                             |        |
| <span id="modified_at">modified_at</span>                           | 2015-09-07 19:23:03 PST           | Logs the most recent modification date and time, aligning with redemption ('applied_at') or early expiration ('deactivated_at').                                                                 |        |
| <span id="deactivated_at">deactivated_at</span>                     | 2015-09-07 19:23:03 PST           | Registers the early expiration date and time, if applicable.                                                                                                                                     |        |
| <span id="applied_at">applied_at</span>                             | 2013-01-02 06:21:14 PST           | Records the date and time of the code's redemption on an account.                                                                                                                                |        |
| <span id="expires_at">expires_at</span>                             | 2014-01-02 06:21:14 PST           | Signifies the automatic expiration date and time of the code after the preset duration concludes.                                                                                                |        |
| <span id="redemption_uuid">redemption_uuid</span>                   | 306f7937d86f088f046dd945a1a24df2  | The unique ID representing each unique code's redemption.                                                                                                                                        |        |
| <span id="account_code">account_code</span>                         | 306f7937d86f088f046dd945a1a24df2  | The unique identifier for the account where the code was redeemed.                                                                                                                               |        |
| <span id="subscription_id">subscription_id</span>                   | 306f7937d86f088f046dd945a1a24df2  | UUID of the subscription linked to the unique code's redemption on a customer account, displayed only for subscription-level redemptions.                                                        |        |
| <span id="total_discount">total_discount</span>                     | 100.50                            | The aggregated discount applied on the account from the unique code's redemption till date.                                                                                                      |        |
| <span id="currency">currency</span>                                 | USD                               | The currency assigned to the 'total_discount' and 'discount' columns.                                                                                                                            |        |
| <span id="discount_type">discount_type</span>                       | percent, fixed_amount, free_trial | The category of the coupon — percentage discount, fixed amount discount, or a custom trial period.                                                                                               |        |
| <span id="free_trial_coupon_amount">free_trial_coupon_amount</span> | 14                                | For 'free_trial' discount type, it defines the period number corresponding to the unit period (like 14 for a 14-day trial).                                                                      |        |
| <span id="free_trial_coupon_unit">free_trial_coupon_unit</span>     | day, week, month                  | For 'free_trial' discount type, it specifies the unit of the trial period (day/week/month corresponding to the trial period).                                                                    |        |
| unique_coupon_code_api_id                                           | e28zov4fw0v2                      | Unique Coupon Code API ID                                                                                                                                                                        | String |

# Version changelog

### Version 2 - 2/5/2025

* Addition of `unique_coupon_code_api_id`.
