---
title: Subscription add-ons - export
excerpt: >-
  Explore the comprehensive details of your current subscription add-ons with
  the Subscription Add-ons export feature.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Required plan

This feature or setting is available to all customers on any Recurly subscription plan.

# Definition

The Subscription Add-on export tool helps you to gather detailed information about all the subscription add-ons created within a specific timeframe. It is important to note that this export only includes details of the add-ons that are currently active and attached to subscriptions. Add-ons that have been removed will not feature in this export.

<Image align="center" border={false} src="https://files.readme.io/f8a71558ad2f36ead13ea6b2986d3be5815c888e0efae2a1c3a29194e77352dd-image.png" />

# Filters

### **Versions Filter**

* The Versions filter allows you to select the version that is most appropriate for your needs. This is based on the version changelog at the bottom of this page.

### Time Range Filter

Utilize the Time Range Filter to view all active subscription add-ons that were activated within a chosen time frame. This feature relies on the "subscription activated_at" date mentioned in the export details.

* The Time range filter (dropdown) allows you to view data within a specific period such as last month, year to date or a custom date range. The Start Date and End Date will automatically update based on the value selected in the Time range filter. You can also choose "Between..." in the dropdown, which will allow you to enter a customized date range.

# Exports table

<HTMLBlock>{`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Button</title>
    <style>
        .download-button {
            display: inline-block;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            color: #1C2833FF; 
            background-color: #F8F8F8FF; 
            border-radius: 5px;
            font-weight: normal;
            transition: background-color 0.5s ease, transform 0.3s ease;
          	transition: 0.4s !important;
            font-family: 'Proxima-nova', Arial, sans-serif;
            max-width: 100%; 
        }

        .download-button:hover {
            background-color: #FFFFFFFF; 
            transform: scale(1.02); 
        }
      	a:hover {
          	color: #1C2833FF;
          	text-decoration: underline !important;
        }
      </style>
</head>
<body>
    <a href="https://docs.google.com/spreadsheets/d/1U0_Wl_NMScJqKBZoBKMmQnybmLEr0gFi6r7dfNiP9Qc/export?format=xlsx" class="download-button">Download our complete export schema</a>
</body>
</html>
`}</HTMLBlock>

To help you identify and organize information effectively, the export provides a structured table that contains the following columns:

| Column Name                                                                                                         | Example                          | Description                                                                                    | Data type (max size) |
| ------------------------------------------------------------------------------------------------------------------- | -------------------------------- | ---------------------------------------------------------------------------------------------- | :------------------- |
| <span id="subscription_uuid">subscription_uuid</span>                                                               | 5eg5bcc7ef8211e0a908005056b00005 | Unique identifier for a specific subscription plan.                                            | string               |
| <span id="add_on_add_on_code">add_on_add_on_code</span>                                                             | extra                            | Code used to identify the add-on.                                                              | varchar(50)          |
| <span id="subscription_add_on_quantity">subscription_add_on_quantity</span>                                         | 1                                | Number of add-ons added to the subscription.                                                   | numeric              |
| <span id="subscription_add_on_unit_amount_in_cents">subscription_add_on_unit_amount_in_cents</span>                 | 500                              | Cost (in cents) of a unit of the add-on.                                                       | numeric              |
| <span id="subscription_add_on_created_at">subscription_add_on_created_at</span>                                     | 2014-01-07 23:54:41 PST          | The date and time the add-on was created, utilized for the date range filter.                  | timestamp            |
| <span id="subscription_add_on_modified_at">subscription_add_on_modified_at</span>                                   | 2014-01-07 23:54:41 PST          | The date and time the add-on was last modified.                                                | timestamp            |
| <span id="subscription_add_on_deleted_at">subscription_add_on_deleted_at</span>                                     | 2014-01-07 23:54:41 PST          | Deprecated column; it no longer populates due to filtering out add-ons with a deleted_at date. | timestamp            |
| <span id="account_code">account_code</span>                                                                         | 239485723046981734               | Customer's account code to whom the subscription add-on belongs.                               | varchar(50)          |
| <span id="add_on_name">add_on_name</span>                                                                           | Video Streaming                  | Name of the add-on that appears on the customer's invoice.                                     | varchar(255)         |
| <span id="add_on_type">add_on_type</span>                                                                           | fixed, usage                     | Indicates whether the add-on is fixed-price or usage-based.                                    | string               |
| <span id="subscription_currency">subscription_currency</span>                                                       | USD                              | Currency of the subscription and the unit amount in cents.                                     | varchar(3)           |
| <span id="subscription_add_on_percentage">subscription_add_on_percentage</span>                                     | 4.5                              | If usage-based, indicates the percentage of the subscription add-on.                           | numeric              |
| <span id="measured_unit_internal_name">measured_unit_internal_name</span>                                           | Bandwidth Units                  | For usage-based add-ons, the internal name of the associated measured unit.                    | varchar(255)         |
| <span id="measured_unit_display_name">measured_unit_display_name</span>                                             | GB                               | For usage-based add-ons, the display name of the associated measured unit.                     | varchar(50)          |
| <span id="external_sku">external_sku</span>                                                                         | abc123                           | SKU of the sold item associated with this add-on, specified by the user.                       | varchar(50)          |
| <span id="subscription_add_on_tier_type">subscription_add_on_tier_type</span>                                       | flat, tiered, volume, stairstep  | Pricing model used to calculate costs based on purchased quantity.                             | string               |
| <span id="subscription_add_on_total_amount_in_cents">subscription_add_on_total_amount_in_cents</span>               | 1000                             | Total amount for a subscription add-on, excluding usage add-ons.                               | numeric              |
| <span id="subscription_add_on_source">subscription_add_on_source</span>                                             | source                           | Subscription add-on source.                                                                    | string               |
| <span id="subscription_add_on_unit_amount_in_decimal_cents">subscription_add_on_unit_amount_in_decimal_cents</span> | 1000                             | Total amount for a subscription add-on, excluding usage add-ons.                               | numeric              |
| <span id="subscription_add_on_billing_model">subscription_add_on_billing_model</span>                               | 1000                             | Total amount for a subscription add-on, excluding usage add-ons.                               | string               |
| subscription_add_on_api_id                                                                                          | e28zov4fw0v2                     | Add On API ID                                                                                  | string               |
| subscription_api_id                                                                                                 | e28zov4fw0v2                     | Subscription API ID                                                                            | string               |

# Version changelog

### Version 6 - 2/5/2025

* Addition of `subscription_add_on_api_id` and `subscription_api_id`.

### Version 5 - 3/9/2023

The addition of subscription_add_on_billing_model to indicate whether it’s term or period based billing.

### Version 4 - 1/14/2021

The addition of subscription_add_on_unit_amount_in_decimal_cents to indicate add on unit amount in decimal cents.

### Version 3 - 7/23/2020

The addition of column subscription_add_on_source to indicate add on source.

### Version 2 - 4/2/2020

The addition of a column for External SKU for item add-ons Inclusion of columns for Add-On Tier Type and Add-On Total Amount
