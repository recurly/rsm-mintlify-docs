---
title: Renewal declines trendalyzer
excerpt: Analyze your renewal decline trends of various metrics with dynamic pivoting.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
<div class="rp-page">
  <div class="rp-overview">The renewal declines trendalyzer dashboard helps you dig into failed renewal invoices and understand where your payment strategy is falling short. Pivot the data across payment type, brand, gateway, and failure type, then trend it daily, weekly, or monthly over any date range you choose.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-benefits"><span class="rp-toc-num">2</span>Key benefits</a>
    <a class="rp-toc-pill" href="#key-details"><span class="rp-toc-num">3</span>Key details</a>
  </div>
</div>

### Prerequisites

<ul class="rp-list">
  <li>Users must have Analytics user role permission.</li>
</ul>

# Definition

<div class="rp-definition">The renewal declines trendalyzer dashboard is a pivotable breakout dashboard for failed renewal invoice data. Select a primary dimension and up to two breakout dimensions, choose a metric — Decline Rate, Total Transactions, or Failed Transactions — and the dashboard rebuilds the chart and table to match.</div>

# Key benefits

<div class="rp-benefits">
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
    <strong>Informed decision-making</strong>
    <span>Make data-driven decisions to set realistic goals and strengthen your subscription growth and customer retention strategies.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
    <strong>Forecasting and planning</strong>
    <span>Improve forecasting and resource allocation to set reachable growth targets.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
    <strong>Customizable data views</strong>
    <span>Pivot data to optimize how it's presented, select specific metrics, and analyze trends across daily, weekly, or monthly ranges.</span>
  </div>
</div>

# Key details

This breakout dashboard lets you adjust the pivot table to view fields in different orders and switch between metrics like Decline Rate, Failed Transactions, and Total Transactions. The top chart shows your primary dimension over time, while the table breaks that dimension down by your selected breakout dimensions.

## General filters (top left corner)


<Image src="https://files.readme.io/ea3a17b3f5cc482d91fa41f61e7d278c099423cf6cf62eca3866413270201d21-image.png" align="center" width="75%" border={true} />


<ul class="rp-list">
  <li><strong>Timeframe</strong>: Analyze different monthly timeframes.</li>
  <li><strong>Invoice creation date</strong>: Choose a specific date range, up to the last 18 months, using the start and end date dropdowns.</li>
  <li><strong>Primary dimension</strong>: Focus on a specific metric by selecting from Payment Type, Brand, Gateway, or Failure Type.</li>
  <li><strong>Dimension breakout 1</strong>: Select an additional dimension from the list, or view all dimensions.</li>
  <li><strong>Dimension breakout 2</strong>: Choose another dimension from the list, or view all dimensions.</li>
  <li><strong>Metric</strong>: Select the key metric to analyze — Decline Rate (%), Total Transactions, or Failed Transactions.</li>
  <li><strong>Gateway type</strong>: Specify the gateway you'd like to view in the data.</li>
  <li><strong>Failure type</strong>: Filter by failure reason, choosing the top 5, top 10, or all reasons.</li>
</ul>
