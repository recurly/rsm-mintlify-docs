---
title: Renewal invoices trendalyzer
excerpt: >-
  Learn how to use Recurly's renewal invoices trendalyzer dashboard to pivot and
  trend renewal invoice data by payment type, brand, gateway, and outcome.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
<div class="rp-page">
  <div class="rp-overview">The renewal invoices trendalyzer dashboard helps you assess how well your payment methods and gateway strategy are performing on renewals. Pivot the data across payment type, brand, gateway, and invoice outcome, then trend it daily, weekly, or monthly over any date range you choose.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-benefits"><span class="rp-toc-num">2</span>Key benefits</a>
    <a class="rp-toc-pill" href="#key-details"><span class="rp-toc-num">3</span>Key details</a>
  </div>
</div>

### Prerequisites

<ul class="rp-list">
  <li>Users must have Analytics user role permission.</li>
</ul>

# Definition

<div class="rp-definition">The renewal invoices trendalyzer dashboard is a pivotable breakout dashboard for renewal invoice data. Select a primary dimension and up to two breakout dimensions, choose a metric — Total Paid Count, Total Count, Total Paid Amount, Renewal Rate by Count, or Renewal Rate by Amount — and the dashboard rebuilds the chart and table to match.</div>

# Key benefits

<div class="rp-benefits">
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
    <strong>Informed decision-making</strong>
    <span>Use real-world data to set realistic goals and optimize your subscription growth and customer retention strategies.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
    <strong>Forecasting and planning</strong>
    <span>Improve forecasting and long-term planning to set achievable growth targets and allocate resources effectively.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
    <strong>Customizable data views</strong>
    <span>Pivot data dynamically to optimize how it's presented, choose specific metrics, and trend different date ranges at daily, weekly, or monthly intervals.</span>
  </div>
</div>

# Key details

This breakout dashboard lets you adjust the pivot table to view fields in different orders and switch between metrics like Total Paid Count, Total Count, Total Paid Amount, Renewal Rate by Count (%), and Renewal Rate by Amount (%). The top chart shows your primary dimension over time, while the table breaks that dimension down by your selected breakout dimensions.

## General filters (top left corner)

<ul class="rp-list">
  <li><strong>Timeframe</strong>: Analyze data across different monthly timeframes.</li>
  <li><strong>Invoice creation date</strong>: Select a specific date range, up to the last 18 months, using the start and end date dropdowns.</li>
  <li><strong>Primary dimension</strong>: Focus on a specific metric by selecting from Payment Type, Brand, Gateway, or Invoice Outcome.</li>
  <li><strong>Dimension breakout 1</strong>: Choose an additional dimension from the list, or view all dimensions.</li>
  <li><strong>Dimension breakout 2</strong>: Choose another dimension from the list, or view all dimensions.</li>
  <li><strong>Metric</strong>: Select the key metric to analyze — Total Paid Count, Total Count, Total Paid Amount, Renewal Rate by Count (%), or Renewal Rate by Amount (%).</li>
</ul>


<Image src="https://files.readme.io/e0f20d8a275387a4677177b297b5242d67c3282725c550b05a627de060a38c14-image.png" align="center" width="75%" border={true} />


## Renewal invoices over time

The Renewal Invoices Over Time bar chart shows how different payment methods trend across consecutive months, making it easy to spot seasonal patterns, shifts in payment preference, or anomalies in transaction volume.

The Renewal Invoices Detail table below it complements the chart with an exact breakdown of the selected metric for each payment type, month by month, so you can make precise comparisons over time. Together, these two views help you see which payment methods drive most of your renewal activity, track how your payment mix changes, and flag categories — like unclassified or low-volume types — that might need attention.
