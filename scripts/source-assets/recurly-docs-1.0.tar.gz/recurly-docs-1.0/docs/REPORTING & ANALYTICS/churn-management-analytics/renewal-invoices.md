---
title: Renewal invoices
excerpt: >-
  Learn how to use Recurly's Renewal Paid Rate dashboard to track renewal
  invoice outcomes and recovery performance.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
<div class="rp-page">
  <div class="rp-overview">The Renewal Paid Rate dashboard shows you how many renewals are successfully paid against all renewal invoices. See which invoices pay without any intervention, how Recurly's churn management features help recover the rest, and how that performance breaks down by currency.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-benefits"><span class="rp-toc-num">2</span>Key benefits</a>
    <a class="rp-toc-pill" href="#key-details"><span class="rp-toc-num">3</span>Key details</a>
  </div>
</div>

### Prerequisites

<ul class="rp-list">
  <li>Users must have Analytics user role permission.</li>
</ul>

# Definition

<div class="rp-definition">The Renewal Paid Rate dashboard shows you renewals that are successfully paid against all renewal invoices.</div>

# Key benefits

<div class="rp-benefits rp-benefits-2x2">
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
    <strong>Industry comparison</strong>
    <span>Compare key subscription metrics with industry benchmarks to see how you stack up against peers, and spot your strengths and weaknesses.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
    <strong>Competitive insights</strong>
    <span>See how competitors are performing on the same subscription metrics, and find areas where you can differentiate and improve.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
    <strong>Informed decision-making</strong>
    <span>Make decisions based on real-world data to set realistic goals for subscription growth and customer retention.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
    <strong>Forecasting and planning</strong>
    <span>Enable more accurate forecasting and long-term planning, so you can set reachable growth targets and allocate resources effectively.</span>
  </div>
</div>

# Key details

## Filters (top left corner)

<ul class="rp-list">
  <li><strong>Date range</strong>: Use the dropdowns to select a timeframe and date range, up to the past 18 months, reflected on the dashboard.</li>
  <li><strong>Select timeframe</strong>: Adjust this to view data over different periods for a more detailed or broader overview.</li>
  <li><strong>Currency</strong>: Select a specific currency from the dropdown. By default, all currencies are converted to the site's primary currency.</li>
</ul>

## Renewal invoices paid without issue

These two graphs show the trend in the percentage of invoices paid without any intervention from Recurly or the customer — invoices that don't require any recovery, before or after the transaction, such as account updater or customer updates. One graph breaks these invoices down by percentage of total invoices created, and the other by invoice count.

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong>The number of invoices shown for the current month will be lower than for previous months, since invoices continue to be generated as the month goes on.</div>
</div>


<Image src="https://files.readme.io/d505574551929c18fd0286546679f7554c1230d7d4bddab801672a934e5f53c5-image.png" align="center" width="75%" border={true} />


## Renewal invoice outcomes

This series of four graphs shows how many invoices were paid without any intervention, and how Recurly helped drive invoice success through our churn management features.

The remaining two graphs show the status of the rest of your invoices — how many were successfully paid through Recurly's churn management features (Account Updater, Expired Card Management, Intelligent Retries, Customer Updates during dunning, and Backup Payment Method), how many failed during the selected period, how many are past due or processing, and how many were updated through external recoveries.

To understand how well each feature is performing, we show both the count and the percentage of revenue across these tables.

This data is also broken out by currency, so you can see how recovery success varies across currencies.


<Image src="https://files.readme.io/0ab4ca4cafe7594a91364a23312604661361bceaed1cb1c952b421964d70b4ba-image.png" align="center" width="75%" border={true} />



<Image src="https://files.readme.io/5c3521deee977af5347bdcdf623a182a8f0a0e7f6146ed3825006dc88c816d1b-image.png" align="center" width="75%" border={true} />


## Related dashboards

Explore related dashboards to learn more about how Recurly helps prevent churn and lower your renewal invoice decline rate. Review your dunning campaign strategy too, to keep increasing your dunning recoveries.


<Image src="https://files.readme.io/0f63abd-image.png" align="center" width="75%" border={true} />
