---
title: Sales, marketing and services
excerpt: >-
  Empower your sales, marketing, and service teams with seamless integrations to
  industry-leading platforms. Drive growth, engagement, and customer
  satisfaction.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Additional cost

This feature or setting requires an additional cost. Please reach out to your Recurly account manager or [support@recurly.com](mailto:support@recurly.com) for more pricing details.

### Prerequisites

* Knowledge of the specific third-party software you're integrating.
* An active account or subscription with the chosen third-party service.
* Necessary API keys or authentication credentials as specified by the third-party software.

### Limitations

* The depth and breadth of integration are contingent upon the third-party software's API and feature updates.
* Some functionalities might not be fully compatible or may demand additional configurations.
* Periodic maintenance and updates might be essential to ensure uninterrupted integration.

# Definition

The Sales, Marketing & Services integrations refer to the strategic connection between our platform and top-tier third-party solutions in the sales, marketing, and service sectors. These integrations are designed to enhance user experience, streamline operations, and optimize outreach and customer service efforts.

# Key benefits

* **Unified operations:** Centralize your sales, marketing, and service operations on one platform.
* **Enhanced customer engagement:** Leverage advanced tools to boost customer interactions and satisfaction.
* **Data-driven decisions:** Gain insights from integrated platforms to make informed marketing and sales strategies.
* **Automated workflows:** Reduce manual tasks, ensuring efficiency and accuracy in operations.
* **Scalability:** Adapt and expand integrations based on evolving business requirements.

# Key details

**Zendesk Integration**

Integrate with [Zendesk ](https://docs.recurly.com/docs/recurly-for-zendesk)to offer top-notch customer service. Manage tickets, track customer interactions, and ensure timely responses, all from our unified platform.

**Salesforce Integration**

Connect with [Salesforce](https://docs.recurly.com/docs/salesforce), the world's leading CRM, to manage leads, opportunities, and customer relationships more effectively. Harness the power of Salesforce's analytics and reporting within our platform for a holistic view of your sales pipeline.

**MailChimp**

Synchronize with [MailChimp ](https://docs.recurly.com/docs/mailchimp)to optimize your email marketing campaigns. Design, send, and track email campaigns, manage subscribers, and analyze results, ensuring your marketing efforts resonate with your audience.

**Braze**

[Braze ](https://docs.recurly.com/docs/braze-integration)provides a leading customer engagement platform that enables and automates personalized cross-channel communications to enhance subscriber engagement, drive retention, and improve the user experience.