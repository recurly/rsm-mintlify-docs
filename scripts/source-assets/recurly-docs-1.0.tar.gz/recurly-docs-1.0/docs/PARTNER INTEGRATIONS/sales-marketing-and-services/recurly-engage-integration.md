---
title: Recurly Engage integration
excerpt: >-
  Drive action across your in-app subscriber lifecycle with Recurly's
  integration with Recurly Engage.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Required plan

This feature **may not be included** in the Starter or Pro plans. If you are interested, please contact [Recurly Sales](https://recurly.com/demo/contact-sales/) to discuss upgrade options.

### Additional Cost

This feature or setting requires an additional cost. Please reach out to your Recurly account manager or [support@recurly.com](mailto:support@recurly.com) for more pricing details.

<a href="https://recurly.com/demo/subscriber-engagement-demo/" target="_blank">Book a Recurly Engage demo</a>

# Definition

Recurly Engage is a platform that delivers real-time, personalized messages across web, mobile, and TV based on users’ behavior, allowing B2C companies to guide their customers to take actions that will drive acquisition, retention, and upselling. Your best chance to get your subscribers' attention is when they’re actively using your product.

# Key benefits

* **Personalized subscriber engagement:** Deliver targeted in-app messages to drive actions like purchases, renewals, and upgrades.
* **Increased subscriber lifetime value:** Enhance customer experience and loyalty through tailored prompts and guidance.
* **Streamlined implementation:** Easily create and manage engaging subscriber journeys without extensive development resources.

# Key details

* **Minimal dev lift and easy to implement**: Growth and product teams can drive engagement and subscriber journey prompts without waiting for engineering resources.
* **Real-time and cross-platform**: Don’t wait for that scheduled email to go out, deliver real-time prompts based on actions and segments across desktop and mobile web, iOS, Android, Apple TV, Roku, Fire TV, and Samsung TV. No other platform offers TV device support.
* **Predict and prevent churn**: Predict users likely to cancel and create personalized cancellation flows to save them.
* **Subscription changes with 1-click**: With only 1-click from your subscribers, automatically make changes to their subscription in Recurly (ie. add-ons, pause, change plans, apply coupons).
  A/B test and analyze what’s working: Easily A/B test unlimited variations to drive conversions and optimize revenue.
* **Drive engagement across your subscriber’s lifecycle**: Prompt your customers at every phase of their journey, from acquisition to renewals, upgrading, and cancellation.

# Implementation guide

## Step 1: Recurly configuration / Recurly Engage (pulse account) provisioning

1. From within Recurly Admin: **go** to Integrations section -> Recurly Engage

* When a merchant has purchased Recurly Engage, they will be able to connect from within the Recurly app.
* Fill out the form to create a Recurly Engage instance.
* This will automatically generate your Recurly Engage instance, provision the Recurly API key, and complete the creation process.


<Image src="https://files.readme.io/56557a4-image.png" align="center" width="80% " border={true} />



<Image src="https://files.readme.io/aa285a2-image.png" align="center" width="80% " border={true} />


2. **Configure** Recurly Engage.

* You will receive an invitation to create your account/password in Recurly Engage.

![](https://files.readme.io/376835ea973bd71fdf1416dbc6e4dc135c11d35327a0740e6d3513e9584ca821-image.png)

* **Log** into Recurly Engage using your new Recurly Engage account from the step above.

> **Note:** You can only have one email address associated with each Recurly Engage instance (site/subdomain).

* If you are planning to be in more than one instance (site/subdomain), you will have to use the alias process (similar to Recurly), e.g., [chad+demo@recurly.com](mailto:chad+demo@recurly.com).
* Once you are logged into Recurly Engage, **go** to Settings→Application:
  * **Enter** your domain.

  * You can also change/edit the name of the instance here if needed—make it descriptive so that you know what the instance usage will be.

  * **Click** save changes.


  > **Note:** the ID and API keys should already be populated from Recurly.

**Inviting a co-worker to the Recurly Engage console is easy:**

* Go to Settings→Users and click on 'Add User'.
* Enter their email and click + Add User.
* Learn more in Recurly Engage: <a href="https://help.redfast.com/docs/invite-users" target="_blank">invite users</a>.


<Image src="https://files.readme.io/1ede92b-image.png" align="center" width="60% " border={true} />


## Step 2: Configure Recurly Engage / add Recurly Engage tag

* **Go** to Settings→User Tracking

  * User tracking is set by either enabling the Recurly Engage tag in Google Tag Manager or copying the script displayed to each page in the customer’s storefront to enable tracking.
  * Once one of these options is enabled on the storefront, tracking will begin. You can verify this by noting the status of “Active” with a green dot.


<Image src="https://files.readme.io/a4444bf-image.png" align="center" border={true} />


* You can configure additional tracking items here. Some examples include identifying the cancellation button ID or creating a new tracker.
* Learn more in [Recurly Engage](https://docs.recurly.com/recurly-engage/docs/usage-tracking-1#/).
* The Javascript SDK is automatically installed on the [Hosted Account Management](https://docs.recurly.com/recurly-subscriptions/docs/hosted-account-management#/) and [Recurly Checkout](https://docs.recurly.com/recurly-subscriptions/docs/checkout#/) pages.

> **Note:** This step is not required on pages where [Recurly.js ](https://docs.recurly.com/recurly-subscriptions/v1.2/docs/overview-recurlyjs#/) is installed.

## Step 3: Fetch ID logic

In order for Recurly Engage to populate prompts to users, the Recurly Engage tag needs to be able to access information about the user.

**Example:** A webpage that authenticates a user, and pulls in information from Recurly including the account code, plan information, and other customer attributes, needs to be live to allow the Recurly Engage JS tag to access this data to identify the user. Device applications (mobile & TV SDKs) will also need to authenticate a user in order to provide targeted prompts to the users.

* Learn more in [Recurly Engage.](https://docs.recurly.com/recurly-engage/docs/custom-js-snippet#/)

Admin users may override certain behaviors of the Recurly Engage Javascript SDK. Upon deploying Recurly Engage for the first time, it is important to configure the following to ensure that users are recognized using your unique identifiers. These identifiers will be utilized for 1-click actions as well as downstream reporting, so it is important that these are correctly configured.

You may need to work with your developers to determine the best method to identify users. The most common methods to retrieve a User ID are:

* localStorage or sessionStorage item
* browser cookie
* accessing an item stored in the browser's dataLayer

## Step 4: Import user traits (using both Recurly and Recurly Engage sites)

#### Recurly - Automated Exports

Within Recurly, **go** to Integrations→Automated Exports and enable the following automated exports:

1. Billing Info v7
   1. Filter on "Modified Yesterday"
2. Invoices - Summary v5
   1. Filter on "Modified Yesterday"
3. Subscriptions v5
   1. Filter on "Modified Yesterday"
4. External Subscriptions v6
   1. Filter on "Modified Yesterday"
   2. Note: this is only available if utilizing App Management

_Note: The lowest supported version is v2 for all four exports._


<Image src="https://files.readme.io/aaa214d-image.png" align="center" border={true} />


#### Recurly Engage - Importing Traits

Follow the steps outlined in [Recurly Engage.](https://docs.recurly.com/recurly-engage/docs/user-traits#/)

After completing these steps in Recurly Engage, you can:

1. Create a CSV file.
2. Upload the file to AWS.
3. This file will be validated after it is uploaded. Notify Recurly Support to complete this process. Once complete, you can view the attributes in Settings→User Traits.

#### Recurly Engage - customizing user traits

Learn more in [Recurly Engage](https://docs.recurly.com/recurly-engage/docs/user-traits#/customizing-user-traits).

1. Within Recurly Engage, go to Settings→User Traits to view the attributes.
2. Configure the Type field for each attribute: Boolean, String, Number, or Date.
3. Configure the Display field for each attribute: HINT, the options are different for each type so assign accordingly.

## Step 5: Customize segments, triggers, and actions

Continuing in Recurly Engage and based on Use Cases, modify the specific user segments, triggers and actions.

#### Test Users

To test your implementation, configure [Test Users](https://docs.recurly.com/recurly-engage/docs/test-users#/) as outlined within Recurly Engage.

* Settings → Users → Test Users.

#### Guides

Within Recurly Engage, you still see the two pre-built guides for Cancel Save and Failed Payment. Follow the steps below to customize these guides.


<Image src="https://files.readme.io/e52e66e-image.png" align="center" width="80% " border={true} />


### Syncing Recurly data

Recurly data will be synced to Recurly Engage for use in building out offers. This includes plan and coupon data. In order to keep plan and coupon data in sync, there is a step to take anytime that a new plan or coupon is created.

To force a sync, navigate to Recurly Engage -> Settings -> Integrations -> External -> Recurly. Uncheck the active checkbox, save, then recheck it, which forces a refresh


<Image src="https://files.readme.io/d8a9d83-Screen_Shot_2024-06-13_at_9.38.26_AM.png" align="center" width="60% " border={true} />


### Cancel save guide

1. Add or modify the options on the reasons for cancellation screen. The following three options are standard (optional):
   * Too expensive with CTA to a save offer
   * Not enough content with CTA to save offer or the latest content
   * Technical issues with CTA to support
2. Create an A-B experiment on any of the prompts in the guide to experiment with offers or design (optional).
3. Set the segment to Test Users (optional - this will allow you to test the guide).
4. Set the trigger to activate using the cancel button click (required).
5. The 'Live' feature can detect and add the cancel click event.
6. Start the guide (required).
7. Add your User ID to the Test Users segment within Settings→Users→Test Users (required for using the test users segment).
8. Confirm that the guide launches when you click on cancel (required).

### Failed payment guide

Configuration steps for [Payment Failure](https://docs.recurly.com/recurly-engage/docs/failed-rebill#/).

1. The failed payment guide will be set to “Journey” (required).
2. The first prompt is set to a Notification prompt type that is shown when the first subscription renewal attempt has failed (required).
3. Set the CTA for this prompt to redirect to your payment update screen (required).
4. You may also set the redirect to Recurly’s hosted billing info update page.
5. Create an A-B experiment on any of the prompts in the guide to experiment with offers or design (optional).
6. Set the segment to Test Users (optional - this will allow you to test the guide).
7. Set the trigger to activate on Any Page (this may be changed later).
8. Start the guide (required).
9. Add your user ID to the Test Users segment from Settings→Users→Test Users (required for using the test users segment).
10. Confirm that the guide is triggered as configured (required).
11. Change the targeting for this prompt to be members with failed payment (required).

## Step 6: Set up, test, activate prompts

Based on use cases, set up the specific prompts triggered by actions.

1. Configure all additional prompts and guides.
2. Apply the applicable segments to all prompts and guides.
3. Complete testing of all additional prompts and guides.
4. Activate all prompts and guides.

Testing on your production account is favorable and has many benefits. By using Test Users, you can test your prompts on your production instance of Recurly and/or Recurly Engage. This will reduce effort to change site alias, rebuilt prompts, and or change API keys. When testing against Test Users, these test accounts can be added to a segment that will apply to the prompts you are testing.

### Post go-live

After the merchant is up and running with prompts, CSM can help monitor the progress and results of prompts to optimize their business. This is a mix of Recurly Engage performance data and Recurly Analytics.

# Helpful resources

Learn more about Recurly Engage by visiting these resources:

* <a href="https://recurly.com/product/subscriber-engagement/" target="_blank">Recurly's subscriber engagement solutions</a>
* <a href="https://recurly.com/product/engage/" target="_blank">Recurly Engage</a>

Already interested? <a href="https://recurly.com/demo/subscriber-engagement-demo/" target="_blank">Book a Recurly Engage demo</a>

# FAQs

**Q: What is Recurly Engage and how does Recurly Engage work?**
**A:** Recurly Engage is a no-code platform that presents prompts to customers when using the merchant application. It utilizes Google Tag Manager (GTM) and a Recurly Engage JS token on the merchant web page, or SKDs or mobile apps.

**Q: What is a prompt?
A:** A prompt refers to content or behavior that is presented to users within one or more segments.

**Q: What is a guide?
A:** A guide is a collection of prompts that appear one after another.

**Q: What segmentation is available in Recurly Engage?
A:** Recurly subscriber data can be used for driving segmentation across prompts and guides to target the message to your unique subscribers.

**Q: How do I monitor the success of the prompts displayed to customers?
A:** Recurly Engage offers robust analytics to measure prompt performance. Recurly analytics can provide insight into the effectiveness of the overall strategy using Recurly Built-In Benchmarks. We are evaluating pulling data from Recurly Engage into Recurly Analytics.

**Q: What if a merchant does not use Google Tag Manager?
A:** Adobe, Tealium or GTM are the tag options out of the box. Other tag managers can be used, and need to have tag script added to each page

**Q: Does my Recurly Engage API key count towards my API key limit?
A:** Yes, the Recurly Engage API key that is generated via the Recurly provisioning flow will utilize one of your API keys. If you need additional API keys, contact sales to increase your limit.
