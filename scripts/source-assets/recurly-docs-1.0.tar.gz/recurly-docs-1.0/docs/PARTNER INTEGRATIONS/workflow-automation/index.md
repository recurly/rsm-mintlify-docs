---
title: Workflow automation
excerpt: >-
  Enhance your efficiency with Recurly's workflow automation through our
  Integration Partners. Discover how to automate tasks and streamline
  operations, connecting our platform to a wide array of applications.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Required plan

These features or settings are available to all customers on any Recurly subscription plan.

# Definition

Workflow automation refers to the design and implementation of automated processes that manage tasks and data flow between various systems and applications. This reduces the need for manual intervention, enhancing productivity and accuracy.

# Key benefits

* **Enhanced efficiency**: Automate repetitive tasks to save time and focus on more critical activities.
* **Improved accuracy**: Minimize human errors by automating data entry and task management.
* **Scalability**: Easily scale operations by integrating with a wide range of applications and services.

# Key details

**Tray.io Integration**

Integrate with [Tray.io](https://tray.io) to automate workflows between our platform and a multitude of apps. With Tray.io, you can set up complex workflows using triggers and actions, creating a network of automated tasks that save time and minimize the need for manual interventions.

**Zapier Integration**

Integrate with [Zapier ](https://docs.recurly.com/docs/zapier)to automate workflows between our platform and over 2,000+ apps. Set up triggers and actions, creating a web of automated tasks that save time and reduce manual interventions.
