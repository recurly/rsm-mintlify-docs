---
title: Payments Use Case Guides
deprecated: false
hidden: false
metadata:
  robots: index
---
# Overview

Harnessing the full power of Recurly's subscription management platform means going beyond the user interface and leveraging our robust API. For developers and product teams, the Recurly API is the key to unlocking unparalleled flexibility and deep integration, allowing you to embed sophisticated billing logic directly into your applications and internal systems. This direct access enables a wide array of powerful payment and subscription management use cases that cater to your unique business needs, transforming Recurly from a billing tool into a core component of your entire tech stack.

By integrating with our API, you can move beyond standard billing and create truly dynamic, automated, and seamless experiences for both your team and your customers.