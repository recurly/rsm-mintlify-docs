---
title: Open source attribution
excerpt: ''
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Open source attribution

* Array Unique - MIT
* Axios - MIT
* Babel - MIT
* Babel Loader - MIT
* Bowser - MIT
* Bugsnag - MIT
* Classnames - MIT
* Component Clone - MIT
* Component Each - MIT
* Component Emitter - MIT
* Component Emitter - MIT
* Component Find - MIT
* Cookie - MIT
* CSS Loader - MIT
* Currency Symbol Map - BSD 2 Clause
* Debug - MIT
* Deep Equal - MIT
* Deep Filter - MIT
* Downshift - MIT
* Easing JS - MIT
* ES6 Promise - MIT
* File Loader - MIT
* File Saver - MIT
* Image Webpack Loader - MIT
* Immutable - MIT
* Inflected - MIT
* Intersect - MIT
* jQuery - MIT
* JSONP - MIT
* LiquidJS - MIT
* Load Script - MIT
* Lodash - MIT
* Mini CSS Extract Plugin - MIT
* Moment - MIT
* Moment Range - Unlicense
* Moment Timezone - MIT
* NanoID - MIT
* Node SASS - MIT
* Number Abbreviate - BSD 2 Clause
* Pikaday - MIT
* Pluralize - MIT
* PostCSS Loader - MIT
* PostCSS Preset Env - CC0 1.0
* Promise - MIT
* Prop Types - MIT
* Q - MIT
* QS - BSD 3 Clause
* Query String - MIT
* React - MIT
* React Copy to Clipboard - MIT
* React Date Range - MIT
* React Datepicker - MIT
* React Focus Lock - MIT
* React JSON Pretty - MIT
* React Measure - MIT
* React Redux - MIT
* React Router - MIT
* React Select - MIT
* React Spring - MIT
* React Transition Group - BSD 3 Clause
* React Virtualized - MIT
* Recharts - MIT
* Redux - MIT
* Redux Devtools Extension - MIT
* Redux Flash - MIT
* Redux Query Sync - Unlicense
* Redux Thunk - MIT
* Reselect - MIT
* RX Dom - Apache 2.0
* SASS Loader - MIT
* String Squish - MIT
* Style Loader - MIT
* Stylus - MIT
* Stylus Loader - MIT
* Tabbable - MIT
* To Slug Case - MIT
* URL Loader - MIT
* Use Query Params - ISC
* VisibilityJS - MIT
* Webpack - MIT
* Webpack Assets Manifest - MIT
* Webpack Bugsnag Plugins - MIT
* Webpack CLI - MIT
* Webpack Merge - MIT
* Webpack Shell Plugin - MIT
* Whatwg Fetch - MIT
* Worker Loader - MIT
* World Countries - ODbL

***

<br />