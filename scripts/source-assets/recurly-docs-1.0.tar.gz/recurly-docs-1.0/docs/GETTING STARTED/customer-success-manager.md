---
title: Customer success manager
excerpt: >-
  Unlock your business's full potential with Recurly's Customer Success
  services! Our team serves to champion our clients by proactively understanding
  their needs and goals, providing partnership, best-practices, data-driven
  insights and guidance throughout the client journey.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
<div class="rp-page">
  <div class="rp-overview">A Recurly Customer Success Manager (CSM) is your dedicated partner for growth, optimization, and ongoing strategic guidance. With more than 75 years of combined payments experience across the team, CSMs are committed to understanding your business, aligning Recurly to your goals, and helping you get measurable ROI from your subscription program.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Not included in Starter or Pro — contact Recurly Sales to upgrade</div>
  <div class="rp-cost">
    <strong>Additional cost</strong><br/>
    Access to a named CSM below the ACV threshold carries an additional cost. For pricing details or current ACV thresholds, reach out to your Recurly account manager or <a href="mailto:support@recurly.com" target="_blank">support@recurly.com</a>.
  </div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#what-to-expect-from-your-csm"><span class="rp-toc-num">2</span>What to expect from your CSM</a>
  </div>
</div>

# Definition

<div class="rp-definition">A Customer Success Manager champions your account by proactively engaging with your team, understanding your unique goals, and providing strategic guidance throughout your Recurly journey. CSMs communicate best practices, surface data-driven insights, and make sure you're well adopted, continuously optimized, and realizing ROI — with the goal of turning you into a Recurly advocate.</div>

# What to expect from your CSM

<div class="rp-benefits">
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-bullseye" aria-hidden="true"></i></div>
    <strong>Strategic alignment meetings</strong>
    <span>Your CSM will build a joint success plan (JSP) to define and track your key objectives and KPIs — then run regular meetings to keep your goals aligned with Recurly best practices and benchmark data.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-chart-line" aria-hidden="true"></i></div>
    <strong>Business and strategic reviews</strong>
    <span>Annual executive business reviews drive deeper partnership and set the vision for ongoing success. Quarterly strategic business reviews reflect on targets, data, projects, and updates.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-gauge-high" aria-hidden="true"></i></div>
    <strong>Adoption and optimization expertise</strong>
    <span>Your CSM analyzes your subscription configuration and metrics against industry trends, surfacing actionable insights to help you stay competitive and get more from your Recurly setup.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-chart-bar" aria-hidden="true"></i></div>
    <strong>Custom benchmark reports</strong>
    <span>Receive benchmark reports tailored to your specific industry so you have a clear view of how your performance compares to peers — and where the biggest opportunities lie.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-bullhorn" aria-hidden="true"></i></div>
    <strong>Voice of the customer</strong>
    <span>Your CSM advocates for you internally, gathering your feedback and influencing Recurly's product roadmap to prioritize enhancements and features that align with your needs.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-lightbulb" aria-hidden="true"></i></div>
    <strong>Thought leadership</strong>
    <span>Gain access to industry insights, webinars, roundtables, advocacy programs, and reports — developed in partnership with Recurly's Marketing team to help you drive subscription growth.</span>
  </div>
</div>