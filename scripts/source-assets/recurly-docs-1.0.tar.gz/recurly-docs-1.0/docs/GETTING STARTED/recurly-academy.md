---
title: Recurly Academy
excerpt: >-
  Delve into Recurly Academy—an enriching hub of interactive courses tailored to
  guide you through Recurly's functionalities at your own pace. Your journey
  from a novice to a seasoned Recurly user is just a course away!
deprecated: false
hidden: true
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Required plan

This feature or setting is available to all customers on any Recurly subscription plan.

### Prerequisites

* Access to Recurly's sandbox environment. <a href="https://app.recurly.com/signup" target="_blank">Sign up here</a>
* An email address to register and sign in to Recurly Academy. See sign-up directions below. 

# Key benefits

* **Comprehensive learning**: Acquire a well-rounded understanding of Recurly through structured courses that break down complex topics into digestible chunks.
* **Interactive training**: Engage in hands-on exercises within a sandbox environment to practically apply what you learn and better retain the knowledge.
* **Customized pathways**: Whether you prefer a linear learning path or wish to explore courses based on your interest, Recurly Academy accommodates your learning style.
* **On-Demand access**: Learn at your own pace, anytime, with a wealth of knowledge accessible at your fingertips.
* **Free initial access**: Experience the richness of Recurly Academy's content without any financial commitment for the first three months.

# Recurly Academy

<Image align="center" width="80%" src="https://files.readme.io/e54a17a-academy_recurly_logo_2707x395.png" />

A structured pathway to mastering Recurly.

Feeling overwhelmed by extensive documentation? Or, are you ready to dive deeper into specific topics like Analytics or Coupons? Recurly Academy is here to cater to all your learning needs!

> 📘 How to register
>
> 1. [Sign up here](https://recurly-academy.workramp.io/register)
> 2. Use the same email address for both Recurly Academy and your Recurly Sandbox 
> 3. Enter the registration code `Potential Recurly Expert`

## Journey from A to Z with Recurly

Recurly Academy serves as a repository of interactive, self-paced courses tailored for individuals aiming to unlock the full potential of the Recurly Admin Console. Delve into topics ranging from core feature access to advanced insights on Dunning Campaigns and Fraud Management.\
Seize the opportunity to access this resource **free** for the first 3 months—no credit card needed.

## Kickstart your learning

Upon registration, unlock four insightful collections:

* Step by step - set up Recurly
* Video demos
* Training your customer service team
* Optimizing Recurly

Each collection contains a set of courses catering to different stages of your Recurly usage. Pick a collection, choose a course of interest, and embark on your learning journey. For a structured learning path, select ‘Paths’ to view grouped courses.

Not sure where to start? Our highly recommended first path is *Step by Step - Set up Recurly*, a series of courses on Recurly's features in the sandbox environment. Delve into each feature with detailed explanations, demonstrations, and hands-on exercises to practice in your sandbox.

Whenever you wish to take a break and then resume, [sign in here](https://recurly-academy.workramp.io/login) to continue your educational voyage with Recurly Academy.
