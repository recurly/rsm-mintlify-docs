---
title: Quantity-based pricing
excerpt: >-
  Configure tiered, volume, or stairstep pricing models in Recurly to charge
  customers based on the number of units they purchase.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
<div class="rp-page">
  <div class="rp-overview">
    Quantity-based pricing lets you charge customers based on how many units they purchase — and gives you three distinct models to work with: tiered, volume, and stairstep. Each one unlocks a different incentive structure, from graduated discounts to flat-rate tiers. This page explains how each model works and walks you through setting one up in Recurly.
  </div>

  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>

  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-benefits"><span class="rp-toc-num">2</span>Key benefits</a>
    <a class="rp-toc-pill" href="#pricing-models"><span class="rp-toc-num">3</span>Pricing models</a>
    <a class="rp-toc-pill" href="#activate-quantity-based-pricing"><span class="rp-toc-num">4</span>Activate quantity-based pricing</a>
  </div>
</div>

# Definition

<div class="rp-definition">
  Quantity-based pricing is a flexible billing model that calculates charges based on the number of units a customer acquires. Rather than a flat rate, the price a customer pays shifts with volume — making it a natural fit for businesses that want to reward larger purchases or offer predictable tiers.
</div>

# Key benefits

<div class="rp-benefits">
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-sliders" aria-hidden="true"></i></div>
    <strong>Pricing flexibility</strong>
    <span>Incentivize larger purchases with graduated pricing, bulk discounts, or flat-rate tiers — whatever fits your business strategy.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-layer-group" aria-hidden="true"></i></div>
    <strong>Cross-industry adaptability</strong>
    <span>Whether you're billing for documents, seats, shirts, or API calls, quantity-based pricing maps cleanly to almost any product or service.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-calculator" aria-hidden="true"></i></div>
    <strong>Simplified cost calculation</strong>
    <span>Customers can determine their total cost at a glance based on quantity — reducing friction at checkout and keeping billing transparent.</span>
  </div>
</div>

# Pricing models

Recurly supports three quantity-based pricing models. Each one handles unit pricing differently as volume increases — choose the one that best matches your product's cost structure and the behavior you want to encourage.

## Tiered pricing

Tiered pricing assigns a different unit price to each range of quantities. As a customer buys more, only the units within each tier are charged at that tier's rate — creating a graduated cost structure.

**Example:** An office services firm charges $1 per document for the first 100, then $0.50 per document beyond that. A customer who orders 150 documents pays $1 × 100 + $0.50 × 50 = $125.

<span class="rp-zoom">
  <a class="rp-zoom-label" href="#">
    <img src="https://files.readme.io/5e9aa7392e822d34d0daee0240098ae9fb192cac2ae433b05e15f7a0f84d9b67-Screenshot_2025-01-16_at_11.32.58_AM.png" alt="Tiered pricing configuration in Recurly" class="rp-zoom-img" />
  </a>
</span>

## Volume pricing

Volume pricing charges all units at the rate of the highest tier reached. Once a customer crosses a volume threshold, every unit — including the first — is repriced at the lower rate.

**Example:** A screen-printing company charges $10 per shirt for orders of 1–20 shirts, and $9 per shirt for orders over 20. A customer who orders 25 shirts pays $9 × 25 = $225 — not a blended rate.

<span class="rp-zoom">
  <a class="rp-zoom-label" href="#">
    <img src="https://files.readme.io/50fedf7bf0859eea6dd2c1c9e5acc7f142f91f9e3fec6bb1049d151cca5fcd50-Screenshot_2025-01-16_at_11.34.57_AM.png" alt="Volume pricing configuration in Recurly" class="rp-zoom-img" />
  </a>
</span>

## Stairstep pricing

Stairstep pricing charges a flat rate for an entire quantity range — the price doesn't change within a tier, no matter how many units a customer acquires within it.

**Example:** A SaaS company prices seat licenses at $50 for 1–10 seats, $100 for 11–20 seats, and $150 for 21+ seats. Whether a customer has 25 or 100 seats, they pay $150 flat. This model is ideal when your delivery costs don't scale linearly with each additional unit.

<span class="rp-zoom">
  <a class="rp-zoom-label" href="#">
    <img src="https://files.readme.io/c997473503d6a04046f5bc0df17ba02c179f3b7bf47860faed273b86863abdc5-Screenshot_2025-01-16_at_11.36.23_AM.png" alt="Stairstep pricing configuration in Recurly" class="rp-zoom-img" />
  </a>
</span>

# Activate quantity-based pricing

Quantity-based pricing is configured on a plan using an add-on. Recurly handles the total calculation automatically once you've defined your tiers, prices, and subscription quantity.

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div>
      <h4>Choose your pricing model</h4>
      <p>Decide whether tiered, volume, or stairstep pricing best fits your business needs. See the <a href="#pricing-models">Pricing models</a> section above for a comparison of each approach.</p>
    </div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div>
      <h4>Set up a plan with an add-on</h4>
      <p>Quantity-based pricing is applied at the add-on level, not the plan level. Create or edit a plan, then add an add-on to serve as the quantity-priced component.</p>
    </div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div>
      <h4>Define your tiers and prices</h4>
      <p>On the add-on, select your pricing model and configure each tier's quantity range and unit price. You can add as many tiers as needed.</p>
    </div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">4</div>
    <div>
      <h4>Assign a quantity to the subscription add-on</h4>
      <p>When creating or updating a subscription, supply a quantity for the add-on. Recurly uses this value to calculate the correct total based on the pricing model you've configured.</p>
    </div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">5</div>
    <div>
      <h4>Let Recurly handle the math</h4>
      <p>Once quantity and tiers are set, Recurly automatically calculates the correct charge at billing time. No custom logic required on your end.</p>
    </div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">6</div>
    <div>
      <h4>Enable editable quantity (optional)</h4>
      <p>If you're using Recurly's Checkout or Hosted Payment Pages, check the <strong>Editable Quantity</strong> box on the add-on. This lets subscribers set their own quantity when signing up.</p>
    </div>
  </div>
</div>

<span class="rp-zoom">
  <a class="rp-zoom-label" href="#">
    <img src="https://files.readme.io/c2bacf2-image.png" alt="Editable quantity setting on Hosted Payment Pages" class="rp-zoom-img" />
  </a>
</span>