---
title: Automatic invoicing terms
excerpt: >-
  Set invoice terms on automatic invoices to separate invoice creation and
  payment collection.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
# Overview

### Required plan

* This feature or setting is available to all customers on any Recurly subscription plan.

# Definition

Collect your automatic invoices on a date after the invoice creation. This allows the invoice to be shared, including the final billable amount and any usage based billing charges, prior to payment collection. This invoice would collect after the predetermined time using the payment method on file.

# Key benefits

* **Communicate final invoice amounts before charge:** For merchants who use Recurly's “usage based billing” feature, after all usage is logged, the invoice will be created so you can inform your customer of the final invoice amount before they are billed.
* **Prioritize compliance:** Customer communication is key for merchants who comply with strict payments regulations. Customers may need to be informed of the final invoice amount a certain number of days prior to their payment method being charged.
* **Charge customer upon shipment or delivery:** Merchants who ship physical goods may want to create the customer invoice when a subscription renews, and delay charging the customer until their box ships or is delivered.

# Key details

## Collection terms

### Automatic invoices

This method will directly bill a credit card that the customer has on file. When invoice terms are not set, the invoice will collect “On-Receipt”. [Learn more](https://docs.recurly.com/docs/invoice-settings#default-values)

### Manual invoices

This method allows for a manual invoice to be generated for the customer. [Learn More](https://docs.recurly.com/docs/manual-payments)

### Terms options for automatic invoices

> **Note**: The default collection behavior can be configured in your invoice settings.

**Invoice terms**: These are the available options:

* On-Receipt
* Net-10
* Net-30
* Net-60
* Custom days

### End of month (EOM) terms

This feature **may not be included** in the Starter or Pro plans. If you are interested, please contact [Recurly Sales](https://recurly.com/demo/contact-sales/) to discuss upgrade options.

These terms are particularly useful when you have business customers who pay invoices weeks or even months after the initial invoice was issued.

**Calculation**: The "due dates" on invoices indicate when they're considered "past due". An additional 24-hour window is added beyond the payment deadline. When an EOM term is applied, the "due date" considers the "issue date" of the invoice. From the last day of the issued month, the selected EOM duration is added, plus an extra 24 hours to get the final "Due Date".

**Examples**:

* Invoice created on June 6 with EOM +0 term: Due Date is July 1.
* Invoice created on February 18 with EOM +15 term: Due Date is March 16.
* Invoice created on September 27 with EOM +60 term: Due Date is November 30.

**Supported EOM terms**:

* EOM +0
* EOM +15
* EOM +30
* EOM +45
* EOM +60
* EOM +90

**Restrictions**: Custom EOM terms are not supported. Once an [EOM ](https://docs.recurly.com/docs/manual-payments#4-end-of-month-eom-terms)term is set on an invoice, **its due date can't be edited**. To change the due date, a refund must be issued for the current invoice, and a new one should be created.

**API availability**: This feature is currently accessible via our User Interface and V2 and V3 APIs.

### Understanding past due invoices

An invoice is considered past due the day after its official due date. For example, a "Net 30" invoice becomes past due exactly on the 31st day.

# Step-by-step process

1. **Configure default terms for automatic invoices**

<Image align="center" className="border" border={true} width="60% " src="https://files.readme.io/485a128-image.png" />

You are able to configure the default terms for automatic invoices. By default, this value is set to “On-Receipt”. Selecting a different value will set terms on automatic invoices unless otherwise specified on an invoice. Note, you can configure different terms for automatic and manual invoices.

2. **Configure terms on specific invoices**

<Image align="center" className="border" border={true} width="60% " src="https://files.readme.io/9806032-image.png" />

When generating an automatic invoice, you can override the site default and set a different term for the invoice being generated. This is available via the API and in the Recurly Admin console.

3. **Communicate to your customers**

When terms are set on an automatic invoice, the “New Invoice” email template will be sent to your customers so they understand the invoice amount they will be charged when invoices are due.

# FAQs

**Q: What if an invoice fails on the due date?**\
**A**: The invoice will be set in a past\_due state, and will enter the dunnings schedule as configured by the merchants' dunning configuration. Applicable emails will be sent.

**Q: What if I attempt collection prior to the invoice term and the collection attempt fails?**\
**A**: The invoice will not enter dunning or be marked as past due, yet will attempt to collect on the due date set on the subscription or invoice. Applicable emails will be sent.

**Q: What considerations are there regarding my dunning configuration?**\
**A**: The invoice will enter dunning after a failure on the due date, which could be closer to or overlap with your dunning window. Be sure to take this into account when configuring your dunning length, if you wish to avoid another subscription cycle starting without a paid invoice.