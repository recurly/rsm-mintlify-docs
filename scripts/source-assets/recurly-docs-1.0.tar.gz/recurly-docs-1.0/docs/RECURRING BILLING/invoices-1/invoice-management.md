---
title: Invoice management
excerpt: >-
  Recurly's invoice management system generates, tracks, and customizes invoices
  for subscriptions, renewals, and refunds — with configurable numbering,
  collection methods, and display options.
deprecated: false
hidden: false
metadata:
  title: ''
  description: ''
  robots: index
next:
  description: ''
---
<div class="rp-page">
  <div class="rp-overview">Recurly automates your entire invoice lifecycle — from generating the first charge to handling refunds and failed payments. Every invoice captures a complete transaction record with configurable numbering, flexible collection methods, and display options that keep your billing process organized and compliant.</div>
  <div class="rp-plan"><i class="fa-solid fa-key" aria-hidden="true"></i> Available on all Recurly plans</div>
  <div class="rp-toc">
    <a class="rp-toc-pill" href="#definition"><span class="rp-toc-num">1</span>Definition</a>
    <a class="rp-toc-pill" href="#key-benefits"><span class="rp-toc-num">2</span>Key benefits</a>
    <a class="rp-toc-pill" href="#key-details"><span class="rp-toc-num">3</span>Key details</a>
    <a class="rp-toc-pill" href="#faqs"><span class="rp-toc-num">4</span>FAQs</a>
  </div>
</div>

<div class="rp-card">

### Limitations

- Invoice number customization and prefix addition require support assistance.
- Certain invoice display customizations may not be supported in all configurations.
- Invoices displayed via the Admin Console, Hosted Invoice, and PDF truncate line items after the first 500.
- Once a manual invoice is paid or a payment attempt is made using billing information on file, it converts to automatic collection. Converting a charge invoice from automatic to manual collection is not currently supported.
- Once an invoice is failed (via Stop Collection), it cannot be reopened.

</div>

# Definition

<div class="rp-definition">Recurly's invoice management system generates, tracks, and customizes invoices to automate your billing process. Each invoice records transactions — including sales, renewals, and refunds — and clearly details the services or products provided and their associated costs. The system supports customizable invoice numbering and includes features to identify transaction origins, making financial reporting and compliance straightforward.</div>

# Key benefits

<div class="rp-benefits">
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-file-lines" aria-hidden="true"></i></div>
    <strong>Detailed transaction records</strong>
    <span>Every invoice provides a full breakdown of transactions, including origins, amounts, and customer details — giving you the transparency you need to build trust with subscribers.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-list-ol" aria-hidden="true"></i></div>
    <strong>Customizable numbering and sequencing</strong>
    <span>Tailor invoice numbering to start from a specific number or add prefixes for better organization — especially useful for businesses operating across multiple markets or product lines.</span>
  </div>
  <div class="rp-benefit">
    <div class="rp-benefit-icon"><i class="fa-solid fa-sliders" aria-hidden="true"></i></div>
    <strong>Comprehensive display options</strong>
    <span>Customize invoices to include the business and customer information that matters most, keeping them informative, compliant, and on-brand.</span>
  </div>
</div>

# Key details

## Invoice numbering


<Image src="https://files.readme.io/2d854e9d97470a9a00e91944efdb6f1283cdcf0cbd4a37a39aa25773626b28e4-Screenshot_2026-04-28_at_2.25.43_PM.png" align="center" width="75%" border={true} />


<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong>Invoice numbers are commonly used to reconcile invoices and transactions. Keep this in mind before adding an entity-specific prefix, as gateways handle invoice number length differently. See <a href="https://docs.recurly.com/recurly-subscriptions/update/docs/gateway-specific-information-for-invoice-numbers" target="_blank">gateway-specific information for invoice numbers</a> for details.</div>
</div>

### Add an entity prefix

An entity prefix is an alphanumeric value (four characters or fewer) prepended to the sequential invoice number. When you add one, the sequence restarts at 1000 and increments by one. Entity prefixes also support country-specific sequencing for EU countries within each sequence.

**To add an entity prefix:**

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Open Invoice Number Settings</h4><p>Go to <strong>Business Entity → Invoice Settings → Invoice Number Settings: Entity Prefix</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Contact support</h4><p>Email <a href="mailto:support@recurly.com">support@recurly.com</a> to have the entity invoice prefix added to your account.</p></div>
  </div>
</div>

For full configuration details, see <a href="https://docs.recurly.com/recurly-subscriptions/docs/business-entities#invoice-settings" target="_blank">Business Entity Invoice Settings</a>.

### Enable EU country-specific numbering

If you need a separate invoice sequence for each European Union (EU) country, you can activate Country Invoice Sequencing.

**To enable EU country sequencing:**

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Open Invoice Settings</h4><p>Go to <strong>Business Entity → Invoice Settings</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Enable Country Invoice Sequencing</h4><p>Find <strong>Country Sequencing</strong> and enable <strong>Country Invoice Sequencing</strong>.</p></div>
  </div>
</div>

For more information, see <a href="https://docs.recurly.com/recurly-subscriptions/docs/eu-vat-2015#invoice-sequencing-by-country" target="_blank">EU Country Sequencing</a>.

### Add a hidden order number prefix

If you use the same payment gateway across multiple billing systems, you can add a hidden prefix to segment your transactions. This prefix doesn't appear on invoices and is not configured per business entity.

**To add an order number prefix:**

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Open Site Settings</h4><p>Go to <strong>Configuration → Site Settings</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Enter your prefix</h4><p>Enter your desired prefix under <strong>Order Number Prefix</strong>.</p></div>
  </div>
</div>


<Image src="https://files.readme.io/b85d93e470e2b710adb1c1c440ffdf3a9a19d0aa11027b6a08f05e5d3aab3ed9-image.png" align="center" width="75%" border={true} />


### Customize the starting number

If you'd like to start your invoice numbering at a number other than 1000, reach out to <a href="https://support.recurly.com/" target="_blank">Recurly Support</a>.

***

## Business entities

A business entity defines your company's identity on customer-facing invoices and emails. Setting it up correctly lets you control the company name, address, phone number, and VAT/Tax ID information that appear on every invoice.


<Image src="https://files.readme.io/39d19465f4103b6cf482c18cd54f4d0382c305833ada260b4f3a4e30ce2dde98-image.png" align="center" width="75%" border={true} />


For businesses with global locations, Recurly lets you set different addresses for invoice display and tax calculations — for example, a US address for tax purposes and a European address for invoice display.

### Set up your business entity

Setting up a business entity involves three required components and a few optional ones.

**Required components:**

- **Company details:** The legal name of your business, location, contact information, and a unique entity code used in URLs and API references. The default entity code is `default` and cannot be modified.
- **Invoice display address:** The company address that appears on each customer invoice. By default, this address is also used for tax calculations.
- **Tax address:** The address Recurly uses to calculate tax obligations. If you want to use a different address for tax purposes, check **Set a different address for tax calculation** — this address will be sent to Avalara or Vertex, while the invoice display address remains unchanged.


<Image src="https://files.readme.io/432de9b65c0a0c7302f7952394c1156dde527859eeec979331f02d333a417bca-image.png" align="center" width="75%" border={true} />



<Image src="https://files.readme.io/d74c7110316318650028b5d55e617bf68d0c9eea87bd1ae0623a5563b535358b-image.png" align="center" width="75%" border={true} />



<Image src="https://files.readme.io/acbfd75b522d3cc6b586948ade4b0bd2285952f48de71e898552c578fcb0b346-image.png" align="center" width="75%" border={true} />


**Optional components:**

- **Tax ID Numbers (TINs) / TIN/VAT information:** If your company collects VAT or has a Tax Identification Number (TIN), enter it here. Consult your tax advisor to determine whether this applies to your business.
- **Billing contact email:** The email address displayed on all Recurly invoices and receipts, and used as the "from" address for all transaction-related customer communications. Your Site Default Entity always uses the billing contact email set on your Site Settings page. If you're on Recurly's Elite plan, you can set <a href="https://docs.recurly.com/docs/multiple-business-entities#entity-specific-merchant-email-addresses" target="_blank">unique email addresses for each alternate business entity</a>.
- **Logo/images for header and footer:** Optional images added to the top and bottom of your invoices.
- **Customer notes:** A free-text section for any customer-specific details — for example, "Thanks for your business!" This is also where you can add information required for local invoice compliance, such as authorized dealer info, delivery note numbers, or Israel-specific invoice fields.
- **Terms and conditions:** A free-text section for payment terms, legal notes, or other contractual information.

<div class="rp-callout rp-callout-tip">
  <div><strong><i class="fa-solid fa-lightbulb" aria-hidden="true"></i> Merchants on Recurly's Elite plans</strong><a href="https://docs.recurly.com/docs/multiple-business-entities#entity-level-invoice-treatments" target="_blank">Learn more about entity-level invoice treatments.</a></div>
</div>

***

## Invoice display

Invoices rendered in the Admin Console, Hosted Invoice, or as a PDF include the following sections.

### Number and collection

Every invoice shows its invoice number and posting date. Charge invoices also display a payment term and due date. Credit invoices list the relevant charge invoice number(s) they were issued against.

Invoice numbers may include entity prefixes or EU country codes depending on your configuration.


<Image src="https://files.readme.io/de8c42f72668ee9f22b1eed749ff5993d5922ceab201d0df15cd5eb926bb0c1a-image.png" align="center" width="75%" border={true} />


### From address

Located at the top left of the invoice, the From address pulls from your Site Settings and includes: company name, address (lines one and two), city, state/province, zip/postal code, and country, phone number, billing contact email, VAT number, and registration number.

### Bill to

The Bill To section defaults to the account's billing information for automatic collection, or account information for manual collection. You can configure it to always use account information (with billing information as a fallback) by enabling **Use Account Information Address for all Invoices** under **Configuration → Taxes → Tax Settings**.

Fields displayed in the Bill To section: first and last name, company name (from Account Information), address (lines one and two), city, state/province, zip/postal code, country, and VAT number.

### Ship to

The Ship To section displays: first and last name, address (lines one and two), city, state/province, zip/postal code, country, and VAT number. Learn more about <a href="https://docs.recurly.com/docs/shipping-addresses" target="_blank">Shipping Addresses</a>.

### Line items

Invoices include a table of line items with the following columns:

<table class="rp-gw-table">
  <tr class="rp-thead-row"><td>Column</td><td>Details</td></tr>
  <tr><td>Date</td><td>The date the line item was created.</td></tr>
  <tr><td>Description</td><td>The item description. HS Code is displayed after the description if provided.</td></tr>
  <tr><td>Quantity</td><td>The number of units charged.</td></tr>
  <tr><td>Price</td><td>The per-unit price.</td></tr>
  <tr><td>Discount</td><td>Shown only if a discount applies.</td></tr>
  <tr><td>Subtotal</td><td>Line item total before tax.</td></tr>
  <tr><td>Tax</td><td>Shown only if applicable — displays the tax rate.</td></tr>
  <tr><td>Tax Net</td><td>Shown only if applicable — displays tax calculated from the subtotal and rate.</td></tr>
  <tr><td>Total</td><td>Shown only if tax is applicable.</td></tr>
</table>


<Image src="https://files.readme.io/a92bac25e71813afc14bc6a42def2339e755646c47c23ba4756f9bc8209d8652-image.png" align="center" width="75%" border={true} />


### Quantity-based pricing line items

Line item structure varies depending on your pricing model.

**Tiered pricing:** Each tier results in a separate line item. The add-on name includes the unit range (e.g., "Seats: 1–10").


<Image src="https://files.readme.io/3dc4f14-Image_2020-03-20_at_8.53.19_AM.png" align="center" width="75%" border={true} />


**Volume pricing:** Line items are similar to fixed-price products, using the per-unit price from the applicable subscription tier.


<Image src="https://files.readme.io/576c291-volume.png" align="center" width="75%" border={true} />


**Stairstep pricing:** A single line item is created showing the add-on name and purchased quantity. The charge quantity is set to one, with the price reflecting the fixed price for the applicable tier.


<Image src="https://files.readme.io/a983819-Image_2020-03-20_at_8.59.44_AM.png" align="center" width="75%" border={true} />


### Total and balance

At the bottom right of the invoice, you'll find:

- **Subtotal:** The total before taxes and additional charges
- **Tax:** Shown only if applicable
- **Total:** The invoice total, inclusive of all charges and taxes
- **Balance:** The remaining amount due

Between the Total and Balance, the following balance-changing entries are listed:

- **Paid:** Represents the total of all payment transactions
- **Credit Applied/Redeemed:** The total value of all credit payments applied to the invoice
- **Payment Refund:** The total of all refund transactions made against the invoice
- **Credit Voided:** Any portion of the credit balance that has been removed or voided
- **Write-Off:** The amount of the invoice that has been written off

### Payment history

The Payments section lists all transactions and credit payments that have reduced the invoice's balance, including the date and amount of each.

### Notes

Invoices include up to three notes sections, which are visible only if they contain text. You can set site-level defaults on the <a href="https://app.recurly.com/go/configuration/invoice_settings/edit" target="_blank">Invoice Settings</a> page, and override them per invoice via the Admin Console or API.

- **Customer notes:** Visible to the customer. Ideal for invoice-specific details, a thank-you message, or any information required for local invoice compliance (e.g., authorized dealer info, delivery note numbers, Israel-specific invoice fields).
- **Terms and conditions:** For payment terms, legal notes, or other important contractual information.
- **VAT reverse charge notes:** Used for EU reverse charge tax scenarios. Configured on the Tax Settings page. Learn more about <a href="https://docs.recurly.com/docs/eu-vat-2015#section-eu-vat-registered-customers" target="_blank">VAT Reverse Charge Notes</a>.

### Invoice currency notes

When currency conversion applies, Recurly displays the relevant currency information in the Notes section following any customer notes — including the displayed currency, converted currency rate, conversion date, and source used.


<Image src="https://files.readme.io/6b0b5a50696c86ec60a37243c47758a48cdd01bb3c6aac8ae55fb3d62e812f5c-image.png" align="center" width="75%" border={true} />


***

## PDF invoice attachments

You can attach PDF invoices to email notifications sent from Recurly.

**To enable PDF attachments:**

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Open Email Templates</h4><p>Go to <strong>Configuration → Email Templates</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Edit the template</h4><p>Open the edit view of the email template you want to update.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Enable the attachment</h4><p>Under <strong>Attachments</strong>, select <strong>Attach PDF</strong>.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">4</div>
    <div><h4>Save your changes</h4><p>Save the template to apply the setting.</p></div>
  </div>
</div>

The following email templates support PDF invoice attachments: New Subscription, New Invoice (Manual Invoice feature only), Invoice Past Due (Manual Invoice feature only), Payment Confirmation, Payment Declined, Payment Refunded, and Payment Voided.


<Image src="https://files.readme.io/7991f5e1662aac7700799c06d51013d81571f449a5957f284458d36a833b94cf-image.png" align="center" width="75%" border={true} />


***

## Invoice emails

Recurly sends invoice-related emails based on the type of invoice and how it was created:

- **Initial subscription:** The first invoice is included in the **New Subscription** email.
- **Automatic collection invoices:** Subsequent invoices use the **Payment Confirmation** email. Invoices with a $0.00 total are not sent.
- **Manual collection invoices:** Always trigger the **New Invoice** email template.

To resend an invoice email, use the **Resend Last Email** button on the invoice detail page.

***

## Proration

Line items are prorated for immediate subscription changes. Proration is calculated down to the second, although line item dates are displayed by day. Learn more about <a href="https://docs.recurly.com/docs/change-subscription#section-time-based-proration" target="_blank">immediate subscription change proration</a>.

***

## Collection methods

The collection method on a charge invoice determines whether Recurly processes payment immediately or simply issues the invoice for manual payment.

### Automatic collection

Recurly attempts payment using the billing information on file (e.g., credit card, bank account, PayPal, Amazon). For new subscriptions and the Purchases API, a successful transaction is required before the invoice posts. For renewals and the Post Invoice API, the invoice posts and payment is processed per the invoice terms. If the transaction is declined, the invoice enters Past Due status and the dunning cycle begins.

### Manual collection

Recurly issues the invoice without attempting payment. External payments can be recorded manually later, or subscribers can pay via the **Make a Payment** button on the Hosted Invoice.

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong>Once a manual invoice is paid — or a payment attempt is made using billing information on file — it converts to automatic collection. It's not currently possible to record a manual payment on an automatic collection invoice, or to convert a charge invoice from automatic to manual collection.</div>
</div>

To record an external payment manually, open the invoice in the Admin Console and enter the payment details in the left sidebar. A manually paid invoice can be reopened.

Learn more about <a href="https://docs.recurly.com/docs/manual-payments" target="_blank">manual collection</a> and the <a href="https://docs.recurly.com/docs/hosted-account-management#section-online-payments" target="_blank">Make a Payment option</a>.

### Change a subscription's collection method

Changing the collection method on a subscription affects the next charge invoice generated — it doesn't change any already-issued invoices.

**To change the collection method:**

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Open the subscription</h4><p>Open the subscription in the Admin Console.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Edit the subscription</h4><p>Select <strong>Edit Subscription</strong> from the <strong>Subscription Actions</strong> dropdown.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">3</div>
    <div><h4>Update the collection method</h4><p>Scroll to the <strong>Invoicing</strong> section and select a new value from the <strong>Collection Method</strong> dropdown.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">4</div>
    <div><h4>Save your changes</h4><p>Save the subscription to apply the new collection method.</p></div>
  </div>
</div>

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong>The change applies immediately, regardless of whether "On next renewal" is selected under Plan Effective Date.</div>
</div>

### Dunning

When an invoice enters Past Due status, Recurly initiates the dunning cycle:

- **Automatic collection:** Dunning begins after the first transaction decline, using the **Payment Declined** email template.
- **Manual collection:** Dunning begins 24 hours after the invoice's due date, using the **Invoice Past Due** email template.

At the end of the dunning cycle, you can choose to fail the invoice or leave it past due. With <a href="https://docs.recurly.com/docs/account-updater" target="_blank">Account Updater</a> enabled, Recurly will continue running Account Updater on the account and attempt to collect payment indefinitely.

Learn more about <a href="https://docs.recurly.com/docs/dunning-management" target="_blank">Dunning Management</a> and <a href="https://docs.recurly.com/docs/retry-logic" target="_blank">Automated Transaction Retry Logic</a>.

### Stop collection

To write off an unpaid invoice, use **Stop Collection** from the **Invoice Actions** dropdown on the invoice detail page. This changes the invoice state to Failed and removes the amount from the customer's account balance. With Credit Invoices enabled, failing an invoice creates a corresponding write-off credit invoice that balances the failed invoice to zero. Stopping collection also halts all dunning activity, including automated emails, payment retries, and Account Updater.

<div class="rp-callout rp-callout-important">
  <div><strong><i class="fa-solid fa-circle-exclamation" aria-hidden="true"></i> Important</strong>Failing an invoice does not cancel the related subscription. Cancel the subscription separately to stop future billing.</div>
</div>

***

## Refunds

Refunds are processed at the invoice level. You can issue a refund by changing a subscription, refunding a specific invoice, or refunding the last invoice while terminating a subscription. These actions generate a refund credit invoice with credit line items against previously paid charge line items.

**To issue a refund:**

<div class="rp-steps">
  <div class="rp-step">
    <div class="rp-step-num">1</div>
    <div><h4>Open the invoice</h4><p>Open the invoice in the Admin Console.</p></div>
  </div>
  <div class="rp-step">
    <div class="rp-step-num">2</div>
    <div><h4>Select Issue Refund</h4><p>Select <strong>Issue Refund</strong> from the <strong>Invoice Actions</strong> dropdown.</p></div>
  </div>
</div>


<Image src="https://files.readme.io/b9244b94fbf72c85c2e397d4a58498e523050b7e1ad3b46ea3e495798ec04007-image.png" align="center" width="75%" border={true} />


On the Issue Refund page, choose to refund by line item or for the entire invoice.


<Image src="https://files.readme.io/56d53f7e6e5a4c528ea0f3aed6dcc7909686fb6bc00d62e10621ffa26bd5d24d-image.png" align="center" width="75%" border={true} />



<Image src="https://files.readme.io/f6a52be7f550e7850161b6873323e0c528f18232a9b9deca7059461e6c16696f-image.png" align="center" width="75%" border={true} />


Available refund methods:

- **Quantity:** Refund specific quantities on any line item
- **Specific amount:** Refund a specific dollar or cent amount on a line item or from the invoice total
- **Percentage:** Refund a percentage of a line item or the invoice total

<div class="rp-callout rp-callout-note">
  <div><strong><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Note</strong>Merchants without the "Only Bill What Changed" and "Credit Memos" features enabled can only refund by quantity (line items) or specific amount (entire invoices). Percentage-based and specific-amount line item refunds are not available without these features.</div>
</div>

<div class="rp-callout rp-callout-tip">
  <div><strong><i class="fa-solid fa-lightbulb" aria-hidden="true"></i> Good to know</strong>If you refund a line item by specific dollar amount or percentage, the quantity shown for that line item on the invoice will appear as "1." Only quantity-based refunds display specific quantity amounts.</div>
</div>

Invoice refunds are also supported in both versions of the Recurly API.

***

## Testing

Invoices created in a sandbox environment display a **TEST INVOICE** watermark. This watermark only appears on sandbox invoices and will not show up in production.

***

## Account hierarchy invoice display

Within an Account Hierarchy, invoices display **Primary Account** for the parent account and **Linked Account** for child accounts. This naming convention appears on the invoice PDF in customer emails, the Hosted Account Management invoice display, and the Recurly App Admin UI.

# FAQs

<Accordion title="Can I start my invoice numbering at a number other than 1000?">
  Yes. Contact [Recurly Support](https://support.recurly.com/) to customize your starting invoice number.
</Accordion>

<Accordion title="How do I add an entity prefix to my invoice numbers?">
  Go to **Business Entity → Invoice Settings → Invoice Number Settings: Entity Prefix**, then contact [support@recurly.com](mailto:support@recurly.com) to have the prefix added to your account.
</Accordion>

<Accordion title="What happens if a payment is declined on an automatic collection invoice?">
  The invoice enters Past Due status and the dunning cycle begins. Recurly will retry payment and send the **Payment Declined** email template based on your dunning settings.
</Accordion>

<Accordion title="Can I convert an invoice from automatic to manual collection?">
  No. It's not currently possible to convert a charge invoice from automatic to manual collection.
</Accordion>

<Accordion title="What happens when I stop collection on an invoice?">
  The invoice state changes to Failed, the amount is removed from the customer's account balance, and all dunning activity stops. If Credit Invoices are enabled, a write-off credit invoice is created to balance the failed invoice to zero. Failed invoices cannot be reopened.
</Accordion>

<Accordion title="Does failing an invoice cancel the subscription?">
  No. You need to cancel the subscription separately to stop future billing.
</Accordion>

<br />
