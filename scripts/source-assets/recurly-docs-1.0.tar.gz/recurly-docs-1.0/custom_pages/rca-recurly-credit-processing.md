---
title: 'RCA: Recurly Credit Processing'
fullscreen: false
hidden: true
metadata:
  title: ''
  description: ''
---
**Summary**\
On June 4, 2020 a bug was introduced into the Recurly platform which impacted specific flows involving the issuing of a credit during a mid-cycle subscription change event.  This resulted in some credits not being issued during a change of subscription.  This issue was detected on June 17, 2020 and a fix was deployed on June 18, 2020.  Immediately after fixing the issue, Recurly then began a detailed analysis of the potential impact of the bug.

**Timeline**

* 2020-06-04: Introduction of issue into the Recurly platform
* 2020-06-17: Root cause identified
* 2020-06-18: Code issue is corrected, detailed analysis of impact begins
* 2020-07-02: Corrective action scripts and resolution paths completed
* 2020-07-06: Customer outreach process begins

**Mitigation Steps**

* [COMPLETE] Deploy code fix to correct the issuing of credits in impacted flows.
* [COMPLETE] Perform detailed analysis of all potentially impacted accounts to determine which are potentially impacted.
* [IN PROGRESS] Develop monitoring on credit accuracy.
