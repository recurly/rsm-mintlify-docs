---
title: Analytics Dashboard UI Comparison
fullscreen: false
hidden: true
metadata:
  title: ''
  description: ''
---
Recurly has updated the look and feel of the analytics dashboards into new, modern versions. While the Modern versions have formatting, dashboard layouts, and color palette changes, they still retains the Classic version's  functionality.  However, there are new features too. 

This document includes the following two sections: 

* **Dashboard UI Features At-A-Glance** provides a short description of the changed/new features
* **Dashboard UI Features in Detail** provides a detailed description and screenshots of the changed/new features

# Dashboard UI Features At-A-Glance

The rows in the following table briefly identify the new UI features available in the modern enhanced versions of the Recurly Analytics dashboards. This table gives you a quick "look at-a-glance" at the features. These features greatly improve on those offered in the Classic versions and allow you to filter, organize, and access reliable details, pertinent to your business’s performance, faster and more efficiently.  An individual section that covers each of these UI features,  follows this table. Each topic provides details and screenshots that describe how to use each feature.

## Modern Analytics Dashboard UI/UX Changes

<Table align={["left","left","left"]}>
  <thead>
    <tr>
      <th style={{ textAlign: "left" }}>
        UI Features
      </th>

      <th style={{ textAlign: "left" }}>
        Modern Dashboards
      </th>

      <th style={{ textAlign: "left" }}>
        Classic Dashboards
      </th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td style={{ textAlign: "left" }}>
        Actions
      </td>

      <td style={{ textAlign: "left" }}>
        New Actions area has clear cache, refresh data, download data, and track completion time for refresh options
      </td>

      <td style={{ textAlign: "left" }}>
        Actions area was not available in the Classic version.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Clear Cache
      </td>

      <td style={{ textAlign: "left" }}>
        Request Clear Cache & Refresh:
        <ul>
        <li>Any time from Actions Area</li>
        <li>Any time from widget drop<br/>
        downs</li>
        </ul>
      </td>

      <td style={{ textAlign: "left" }}>
        Clear Cache & Refresh was available in the Classic version from the upper right corner of those dashboards..
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Currency Filters
      </td>

      <td style={{ textAlign: "left" }}>
        Currency Filters always appear, even if only one currency option is available.
      </td>

      <td style={{ textAlign: "left" }}>
        Currency Filters only displayed if more than one currency is available.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Date Range
      </td>

      <td style={{ textAlign: "left" }}>
        Specify Date Range:
        <ul>
        <li>Default to the last 12 months</li>
        <li>Sophisticated searches</li>
        <li>Granular filtering</li>
        </ul>
      </td>

      <td style={{ textAlign: "left" }}>
        Specify Date Range:
        <ul> 
        <li>Default to the last 18 months</li>
        <li>Simplistic setting &#x26; choices</li>
        </ul>
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Download Data
      </td>

      <td style={{ textAlign: "left" }}>
        Download Data in multiple formats:
        TXT, to Excel spreadsheet, CSV, JSON, HTML, Markdown, and PNG
      </td>

      <td style={{ textAlign: "left" }}>
        Download Data in one format:
        CSV
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Dunning Campaigns
      </td>

      <td style={{ textAlign: "left" }}>
        Dunning Effectiveness dashboard:
        <ul>
        <li>Select appropriate dunning version from views at the top of the dashboard.</li>
        <li>All Dunning Campaign views show summary of all campaign</li>
        <li>Individual Dunning Campaign views show details from individual campaigns</li>
        </ul>
      </td>

      <td style={{ textAlign: "left" }}>
        Dunning Effectiveness dashboard: Dunning version selection was localized to the chart component to which it applied.        Does not have campaigns
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Ellipses
      </td>

      <td style={{ textAlign: "left" }}>
        Ellipses in widgets provide drop down menu options, use:
        <ul>
        <li>Vertical Ellipses to Clear Cache and Refresh Data &#x26; to Download Data</li>
        <li>Horizontal Ellipses to drill into MRR Account Details</li>
        </ul>
      </td>

      <td style={{ textAlign: "left" }}>
        Ellipses with dropdown menu choices are not available in the Classic version.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Filters
      </td>

      <td style={{ textAlign: "left" }}>
        Filters are grouped at the top left area of all dashboards and multiple view dashboards.
      </td>

      <td style={{ textAlign: "left" }}>
        Filters related to specific sections of the dashboards are found at that location.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Hover Text
      </td>

      <td style={{ textAlign: "left" }}>
        Hover Text shows dates totals in individual messages for each selected segment of bar or line charts.
      </td>

      <td style={{ textAlign: "left" }}>
        Hover Text shows dates totals in one message for all segments of bar or line charts.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        KPIs
      </td>

      <td style={{ textAlign: "left" }}>
        Key Performance Indicators (KIPs) show:
         <ul>
        <li>Active Totals</li>
        <li>Last Month</li>
        <li>Previous Month</li>
        <li>3 Months Ago</li>
        <li>1 Year Ago</li>
        </ul>
      </td>

      <td style={{ textAlign: "left" }}>
        Key Performance Indicators (KIPs) show:
        <ul>
        <li>Active Totals</li>
        <li>Previous Month</li>
        <li>3 Months Ago</li>
        <li>1 Year Ago</li>
        </ul>
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        MRR Drill Down
      </td>

      <td style={{ textAlign: "left" }}>
        Monthly Recurring Revenue (MRR) Drill Down option lets you view the MRR Accounts Drill report.
      </td>

      <td style={{ textAlign: "left" }}>
        Monthly Recurring Revenue (MRR) Drill Down option is not available in the Classic version.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Multiple Daily Uploads
      </td>

      <td style={{ textAlign: "left" }}>
        Automatic Data Uploads occur multiple times a day. In addition, request a Clear Cache & Refresh from the Actions Area to start an upload.
      </td>

      <td style={{ textAlign: "left" }}>
        Data Uploads occurred once a day in the Classic version.
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Select Plans
      </td>

      <td style={{ textAlign: "left" }}>
        Ability to Select, contrast, compare more than 2 plans. Can compare up to 12 plans at a time.
      </td>

      <td style={{ textAlign: "left" }}>
        Data Uploads occurred once a day in the Classic version.
        Ability to Select and compare 2 Plan
      </td>
    </tr>

    <tr>
      <td style={{ textAlign: "left" }}>
        Sort Hide Data
      </td>

      <td style={{ textAlign: "left" }}>
        Sort details in widgets:
         <ul>
        <li>Show/Hide details on bar, line, and pie charts using the widget’s color-coded legends</li>
        <li>Sort details on tables in ascending or descending order.</li>
        </ul>
      </td>

      <td style={{ textAlign: "left" }}>
        Sort/Hide Data is not available in the Classic version.
      </td>
    </tr>
  </tbody>
</Table>

# Dashboard UI Feature in Detail

The following topics describe in detail, the new and enhanced UI features available in the modern enhanced versions of the Recurly Analytics dashboards. Each topic tell you exactly how to use the new features and  includes instructions and screenshots to help you located new areas on the dashboards.

## Actions

The Recurly enhanced dashboards provide you with a set of actions at the top right corner of the dashboards:

<Image title="analytics hide filters  option.png" alt={540} src="https://files.readme.io/5357e17-analytics_hide_filters_option.png">
  Actions Options Area
</Image>

The actions include the following features:

* Time from the last requested clear cache/refresh data beginning from 1m ago up to four hours.
* Reload action will track time from the last time you refreshed your data. It then resets the counter. This tells you how current your data is from the last refresh.
* Hide Filter action shown as three vertical lines that hide the Filters area that displays in the top left corner of the dashboard.
* Dashboard actions allow you to either clear the cache and refresh the data, view a popup Download Dashboard from where you can select a download format, page size, or specify how to arrange downloaded data, or reset filters to their default settings.
* Open Folders action all

## Clear Cache and Refresh Data

In addition to the regular updates performed by Recurly, you can poll for updates from multiple places on the dashboard using the Clear Cache and Refresh Data feature. 

Clear cache and refresh from:

* Actions area ->Dashboard Actions (vertical ellipse) -> requests  new Clear cache and refresh data. 

<Image title="download from actions.png" alt={598} src="https://files.readme.io/c82358e-download_from_actions.png">
  Clear Cache and Refresh from Actions Area
</Image>

   This action requests a full refresh of all data.

* Vertical ellipses in the top right corner of all widgets including charts, tables, and key performance indicators.

<Image title="download link from widgets.png" alt={448} src="https://files.readme.io/623c09d-download_link_from_widgets.png">
  Clear Cache and Refresh from a Widget
</Image>

```
This action updates the widget with the most current information available from the last clear cache.
```

## Date Range

The Recurly enhanced dashboards provide a more sophisticated option for selecting your date range settings. You still have the option to set your date range within an 18-month timeframe. However, there are two new dropdown menus that include more granular options that will make it easier for you to refine the date range that you select.

From the Filters area, select Date Range -> “Is in the last 18 months” and choose an option from the "Is in the last” dropdown. Then choose an option from the “months” dropdown. The default is: **In the last 18 months**. Modify the default to meet your needs and set another date range.  

<Image title="analytics comparison date range .png" alt={1606} src="https://files.readme.io/8706534-analytics_comparison_date_range_.png">
  Modern Date Range Filters
</Image>

## Download Data

You can download data from the modern versions of the Analytics dashboards in multiple formats:

<Image title="analytics dashboard download formats.png" alt={1660} src="https://files.readme.io/43fbcd1-analytics_dashboard_download_formats.png">
  Modern Dashboard Download Formats
</Image>

You can select a download format from all widgets on the dashboard including bar, line, or pie charts or Key Performance Indicators (KPI) widgets.

Note: Download data from the Classic (previous) versions of the Analytics dashboards were in CSV format only. These Download CSV links are still available and  located across from the dashboard’s section names.

## Dunning Campaigns

The modern enhanced version of the Dunning Effectiveness dashboard allows you to view a summary of invoice, revenue, or subscriptions data for either all dunning campaigns/plans by selecting from the widget on the left or for any individual dunning campaigns or a version of a campaign by selecting from the widget on the right as shown in the following screenshot. 

<Image title="analytics comparison of all and individual campaigns.png" alt={1724} src="https://files.readme.io/ef32113-analytics_comparison_of_all_and_individual_campaigns.png">
  Dunning Campaign Views
</Image>

Clicking any of the links shown at the top of the dashboard to display a new page with its own filters, widgets, and details specific to the selected campaign.

## Ellipses (Vertical/Horizontal)

You can use ellipses on the Recurly dashboards to access the following features:

**Vertical Ellipses** are shown in:

* Actions area to clear cache and refresh data, download data, and refresh filters
* Dashboard widgets to download data and clear cache and refresh data 
* Dashboard tables to download data, auto size all columns, resize all column widths, and clear cache and refresh data

The **Horizontal Ellipse** is shown in columns on the Monthly Recurring Revenue (MRR) dashboard. Use them to access the link to MRR Accounts Drill reports.

## Filters

In the modern version of the dashboards, filters have moved from embedded within individual widgets to a unique Filter area in the top left corner of the dashboards. 

### Use Filters

Filters specify the settings that will apply to the dashboard by clicking an option or using a dropdown menu, in the Filter area. For example, choosing Monthly as your Select Timeframe option and a Plans option from the Select Plans dropdown menu means that you want your Plans data to be calculated and display for each month in your specified timeframe. 

<Image title="analytics compair filter with dropdown.png" alt={1516} src="https://files.readme.io/97a043c-analytics_compair_filter_with_dropdown.png">
  Subscriptions Filtered by Plans
</Image>

### Hide Filters

The Hide filter option removes the Filter area of the top left corner of the dashboard.

1. View filters on the dashboard.

<Image title="analytics comaptison filters .png" alt={1528} src="https://files.readme.io/e864e53-analytics_comaptison_filters_.png">
  Filter Area
</Image>

2. If you do not want them to display, click the horizontal bar icon in the Actions area to select the Hide filters option.

<Image title="analytics hide filters  option.png" alt={540} src="https://files.readme.io/f6f6642-analytics_hide_filters_option.png">
  Action Area Shows Horizontal Bars
</Image>

3. Once you select Hide Filters, the Filter area will no longer be visible from the dashboard.

<Image title="analytics comaprison hidden filter area.png" alt={1560} src="https://files.readme.io/cabf880-analytics_comaprison_hidden_filter_area.png">
  Filter Area Hidden
</Image>

### Reset Filters

Use the Reset Filter option to return your filter choices to their default settings. To do this, go to the Actions area in the top right corner of the dashboard, click Download actions -> Reset Filters. 

<Image title="download from actions.png" alt={598} src="https://files.readme.io/6c1d039-download_from_actions.png">
  Reset Filters Option
</Image>

## Hover Text

The Recurly Hover text shows details for individual segments or points on charts that you hover over with your mouse. This includes bar, line, and pie charts. For example, if you hover over a specific segment on a bar chart as shown in the following screenshot, the hover text will display details for that selected plan in that specific date range. 

<Image title="analytics comparison sorted bar chart.png" alt={2538} src="https://files.readme.io/1a2895b-analytics_comparison_sorted_bar_chart.png">
  Segment of a Bar Chart with Hover Text
</Image>

### KPIs

The Key Performance Indicators (KPIs) are shown in a separate widget, usually at the top or side of the dashboard. This widget features values at a glance, for the current month to date compared to the last month, previous month, three months ago, up to one year ago. These values give you a better sense of how the indicators are trending. See following screenshot:

<Image title="billings totals overview.png" alt={2604} src="https://files.readme.io/33aa788-billings_totals_overview.png">
  Modern Dashboard Key Performance Indicators
</Image>

## MRR Drill Down

The Monthly Recurring Revenue (MRR) drill down feature allows you to view additional details about your accounts from the MRR dashboard widgets. This dashboard tracks totals for Monthly Recurring Revenue and Monthly Recurring Revenue Growth. 

1. Click the desired bar to select the See accounts option and then click “See accounts” to view that account’s MRR Accounts Drill

<Image title="analytics comparison mrr drill down bar chart.png" alt={2444} src="https://files.readme.io/4835115-analytics_comparison_mrr_drill_down_bar_chart.png">
  MRR Accounts Drill Down Option
</Image>

2. Click the horizontal ellipse, in the desired table cell, to display the See accounts option and then click “See accounts” to view that account’s MRR Accounts Drill.

<Image title="analytics comparison mrr drill down table.png" alt={608} src="https://files.readme.io/72499fd-analytics_comparison_mrr_drill_down_table.png">
  Horizontal Ellipse in Far right Column
</Image>

```
The MRR Accounts Drill displays account-level details such as: buckets, account codes, email addresses, date accounts were created, names, and either the Total MRR or Delta MRR.
```

## Multiple Uploads per Day

Recurly automatically updates your data during regular intervals, each day. Check the widget at the bottom of the dashboards to see the last time an update occurred.

<Image title="billings dat update widget.png" alt={642} src="https://files.readme.io/75ecb3a-billings_dat_update_widget.png">
  Widget Showing Latest Completed Upload
</Image>

Also, you can poll for an update clicking the Clear Cache and Refresh Data option from the Actions area ->Dashboard Actions dropdown in the top right corner of the dashboard. 

## Select Plans

Although you select/set up plans when you create your account, you can specify which plans you want to track in the dashboards by using the Select Plans filter.

<Image title="analytics compair filter with dropdown.png" alt={1516} src="https://files.readme.io/53ee4e6-analytics_compair_filter_with_dropdown.png">
  Select Top 5 Plans from Filter
</Image>

Making your choice in the Select Plans filter narrows the filter options available in the Plans filter. In the Plans filter dropdown menu, you can check the box for any plans in the preset plans list. For example, if you choose the Top 5 Plans option from the Select Plans dropdown menu, those five plans will be listed in the Plans filter dropdown menu as shown in the following screenshot:

<Image title="analytics comparison plans filter.png" alt={1330} src="https://files.readme.io/2a3a94c-analytics_comparison_plans_filter.png">
  Filtered Plans from Select Plans List
</Image>

You can then check the box next to the desired plans and Recurly will calculate the latest details. You can use these statistics to compare plans. You can either select two plans, a set of plans, or all plans. Recurly will provide comparison data for up to twelve plans. 

## Sort/Hide Data

The Recurly enhanced version of the Analytics dashboards provides two different ways for you to sort your data from within the dashboards. 

### Sort Data in Charts

Use the color-coded legend on the bar, pie, or line chart to hide or reveal data. For example, in the following screenshot you see a bar chart with corresponding colors for each bar segment in the legend at the bottom of the widget.

<Image title="analytics comparison unsorted bar chart.png" alt={2532} src="https://files.readme.io/1d11c32-analytics_comparison_unsorted_bar_chart.png">
  Bar Chart with Color-Coded Segments and Legends
</Image>

This bar chart shows the five top five plans that you selected in the Select Plans filter. You can compare or view any combination of these selected plans. For example, clicking the corresponding color in the legend will gray out that color in the legend and remove the color’s corresponding segment from the bar chart. In the following screenshot, three colors have been clicked and their corresponding data hidden, so you will only see the data for the two remaining colors (plans).

<Image title="analytics comparison sorted bar chart.png" alt={2538} src="https://files.readme.io/913170f-analytics_comparison_sorted_bar_chart.png">
  Grayed out Colors in Legend Hidden in Chart
</Image>

You need only reselect the colors to cause the data to reappear. This feature works the same way in line and pie charts.

### Sort Data in Tables

Use  arrow in the top right column of Details (tables) to view the data in a table in either the ascending or descending order. Click the up arrow over the right  column of the table to change the order.

<Image title="analytics comparison sort on a table.png" alt={730} src="https://files.readme.io/c83eeb2-analytics_comparison_sort_on_a_table.png">
  Changing the Ascending/Descending Order in Tables
</Image>