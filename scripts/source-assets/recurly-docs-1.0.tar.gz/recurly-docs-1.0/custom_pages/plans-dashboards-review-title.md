---
title: Plans Dashboards (REVIEW TITLE)
fullscreen: false
hidden: true
metadata:
  title: ''
  description: ''
---
The Plans Dashboard calculates the total number of subscriptions in each plan for a selected date range. This tells you which plans are most popular allowing you to make better business decisions about where to apply your efforts. 

* A subscription is counted in a plan if it is live on that plan during the selected date range, including in trial canceled (but not yet churned) or in a paused state. This count also includes $0 subscriptions and subscriptions purchased with a gift card.
* For weekly and monthly intervals, the total number of subscriptions in a plan are counted at the end of that interval.

For example, if a subscription is in Plan A from April 1st to May 20th, but then upgrades to Plan B before May 31st, the month interval will count 1 subscription in Plan A for April and 1 subscription in Plan B for May. The daily interval will show the exact date of subscription change.\
To maintain access to the most current information, you can use widgets on this dashboard to refresh the screen.  The data for this dashboard updates multiple times a day. You can verify the time the  last changes were uploaded by checking the widget at the bottom of the dashboard.

## Plans Dashboard

The Plans Dashboard is divided into three sections:key performance indicator view  at-a-glance, bar chart, and details table.\
The widgets on this dashboard’s user interface provide you with access to the following common features:\
**Actions** at the top right corner of the dashboard provide the following functionality:\
*Reload action tracks the last time you refreshed the data up to four hours. The counter then resets, beginning with 1m ago This tells you how current your data is from the last refresh.\
*Hide Filters action hides filters that display in the top left corner of the dashboard.

* Dashboard actions allow you to either clear the cache and refresh the data, view a Download Dashboard menu from where you select a download format, page size, or specify a downloaded data arrangement, or reset filters to the default value.\
  \*Open Folders action allows you to open/view folders from the dashboard.

**Filters** in the top left corner of the dashboard that provide the following options:\
*Select Timeframe filter allows you to select a daily, weekly, or monthly option for displaying data.\
*Month filter allows you to click dropdown menus where you can choose a timeframe and date range from within the last 18 months to determine the data that displays on the dashboard.\
*Select Plans filter allows you to click a dropdown menu to select a set of top plans or to select all plans. This filter is linked to the Plans filter. When you make your Select Plan Name choice, this narrows the filter options available from the Plans filter. For example, if you select Top 5 plans, the Plans filter will display a dropdown menu listing only your Top 5 plans.\
*Plans filter provides a list of all plans that are selected, based on your choice in the Select Plans filter.

**Clear Cache** options allow you to clear cache and refresh data in three places on this dashboard:\
*Click the vertical ellipse on any of the widgets, at the bottom of the dashboard to see the timestamp for the most current version of data on the dashboard.\
*Click the vertical ellipse on any of the widgets within the dashboard to update the selected widget with the most current data available during the session.\
\*Click the Actions widget -> vertical ellipse at top right corner of the dashboard to clear the cache and refresh the data. Recurly updates the data multiple times a day, so after a refresh, the most current data available will upload.

Vertical ellipses available on both widgets and tables, provide you with a dropdown menu where you can select the following options:\
*Click the vertical ellipse on a widget to download data or clear cache and refresh data for a selected widget.\
*Click the vertical ellipse on a column in a table to download data or clear the cache and refresh the data on display, but also to auto size or resize columns.

**Charts and legends** display data on this dashboard within widgets in bar, line, and pie charts. This data often includes customer, subscriber, subscription, plans, and revenue totals in increments specified by time and date ranges. If the information on one of these charts is color-coded, there will be a legend on the widget that identifies the value assigned to the color. For example, specific colors are assigned to specific plans or totals being tracked, to enable you to read the chart.\
*Click a point in a line chart or a specific color on a bar or pie chart to display the corresponding timeframe and value in hover text. For example, total number of subscribers for a corresponding month.\
*Click the corresponding color in the legend to hide that corresponding line, bar, or pie chart segment from the widget. Click on the color again, to restore the data.

## Subscriptions by Plans

The Plans Dashboard is divided into the following segments: subscriptions by plan key performance indicator, subscription by plans bar chart, and details table of plans data. 

**Subscriptions Key Performance Indicator**: shows a subscription totals at-a-glance view in a widget that includes the current Active Subscriptions by Plans totals, and totals for last month, previous month, three months ago, and one year ago. 

![2339](https://files.readme.io/21a7451-Subscriptions_by_Plan_totalts_.png "Subscriptions by Plan totalts .png")

The up arrow under each total indicates the difference between the additional timeframes and the Active Subscriptions total.

**Subscription By Plans**\
Shows the number of subscriptions for the filtered plans by the selected timeframe in a bar chart.\
*Click any bar in the bar chart to view the total number of subscriptions in hover text, for the selected timeframe.\
*Click one of the color-coded sections of any bar to view the plan totals for the selected timeframe in hover text. The color legend at the bottom of the chart corresponds to the selected plans.

![2538](https://files.readme.io/5e2564f-subscription_by_plan_bar_chart.png "subscription by plan bar chart.png")

**Subscriptions by Plans details chart**\
Shows the total amount of active subscriptions for the selected top plans compared to the total for all plans, by the selected timeframe.

![2538](https://files.readme.io/9df20da-subscription_by_plan_details.png "subscription by plan details.png")
