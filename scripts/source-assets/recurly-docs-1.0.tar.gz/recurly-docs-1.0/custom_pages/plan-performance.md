---
title: Plan Performance
fullscreen: false
hidden: true
metadata:
  title: ''
  description: ''
---
The Plan Performance Dashboard compares the performance of distinct plans across eight different performance metrics, such as trial conversion rates, churn rates, subscription totals, subscription growth, Monthly Recurring Revenue (MRR), MRR growth, plan movement (upgrades and downgrades), subscriber totals, and average Lifetime Value (LTV). 

The Plan Performance dashboard helps you:

* Evaluate the performance of a plan after pricing, plan length, or promotional changes to understand positive or negative impact
* Compare attributes of different plans, such as the use of a trial or plan length, to gauge which plan is most successful.

To maintain access to the most current information, you can use widgets on this dashboard to refresh the screen.  The data for this dashboard updates multiple times a day. You can verify the time the last changes were uploaded by checking the widget at the bottom of the dashboard.

# Plan Performance Dashboard

The Plan Performance Dashboard is divided into eight individual views that provide specific data about the performance of selected plans.

The widgets on this dashboard’s user interface provide you with access to the following common features:

**Actions** at the top right corner of the dashboard provide the following functionality:

* Reload action tracks the last time you refreshed the data up to four hours. The counter then resets, beginning with 1m ago This tells you how current your data is from the last refresh.
* Hide Filters action hides filters that display in the top left corner of the dashboard.
* Dashboard actions allow you to either clear the cache and refresh the data, view a Download Dashboard from where you can select a download format, page size, or specify downloaded data arrangements, or reset filters to the default values.
* Open Folders action allows you to open/view folders from the dashboard.

**Filters** in the top left corner of the dashboard provide the following options:

* Month filter allows you to click dropdown menus where you can choose a timeframe and date range from within the last 18 months to determine the data that displays on the dashboard.
* Select Plans filter allows you to click a dropdown menu to select a set of top plans or to select all plans. This filter is linked to the Plans filter. When you make your Select Plan Name choice, this narrows the filter options available from the Plans filter. For example, if you select Top 5 plans, the Plans filter will display a dropdown menu listing only your Top 5 plans.
* Plan Name filter provides a list of all plans that are selected, based on your choice in the Select Plans filter.
* Monthly Discount Rate filter provides a list of rate options for you to choose. Recurly default discount rate is 1%. 

**Multi-Currency support** is available in the Recurly Professional, Elite, and Enterprise plans. You may run transactions in more than one currency through one or more payment gateways that accept the currencies you want to collect. If you choose US dollars, this will be your Primary currency and the default choice. Totals on the dashboard will display in US dollars.

Once Multiple Currency support is enabled on your Recurly account, you can then specify which currencies you want to accept for your account. When a currency is added to your accepted list, you may then define pricing for your subscription plans and coupons using the new currency. Then, choose one of the enabled currencies for the dashboard.

* Sites that support more than one currency (the primary currency) will see a default view that shows the total payments, refunds, and net billings across all currencies, converted to their primary currency and summed.
* You can also view the payments, refunds and net billings processed in each individually supported currency.
* Conversion rates are updated daily (via [https://openexchangerates.org/](https://openexchangerates.org/)) Historical billings use the conversion rate at the time of transaction and do not change over time for current conversion rates.

**Clear Cache options** allow you to clear cache and refresh data in three places on this dashboard:

* Click the vertical ellipse on any of the widgets, at the bottom of the dashboard to see the timestamp for the most current version of data on the dashboard.
* Click the vertical ellipse on any of the widgets within the dashboard to update the selected widget with the most current data available during the session.
* Click the Actions widget -> vertical ellipse at top right corner of the dashboard to clear the cache and refresh the data. Recurly updates the data multiple times a day, so after a refresh, the most current data available will upload.

**Vertical ellipses** available on both widgets and tables, provide you with a dropdown menu where you can select the following options:

* Click the vertical ellipse on a widget to download data or clear cache and refresh data for a selected widget.
* Click the vertical ellipse on a column in a table to download data or clear the cache and refresh the data on display, but also to auto size or resize columns.

**Charts and legends** display data on this dashboard in bar, line, pie charts and status details. This data often includes customer, subscriber, subscription, plans, and revenue totals in increments specified by the time and date ranges. If the information on one of these charts is color-coded, there will be a legend on the widget that identifies the value assigned to the color. For example, specific colors are assigned to specific plans or totals being tracked, to enable you to read the chart. 

* Click a point on a line chart or a specific color on a bar or pie chart to display the corresponding timeframe and value in hover text. For example, total number of subscribers for a corresponding month.
* Click the corresponding color in the legend to hide that corresponding line, bar, or pie chart segment from the widget. Then, click the color again, to restore the data.

# Plan Performance

The Plan Performance Dashboard is divided into the following eight views. Click on any link to get to the corresponding dashboard views.

<Image title="plan performance views.png" alt={1624} src="https://files.readme.io/8065922-plan_performance_views.png">
  Plan Performance Views
</Image>

# Plan Performance & KPIs

This view includes the following two status details.

**Plan Performance Attributes** include details such as the plan name, plan code, pricing, trial length, current subscriptions, and current MRR. 

<Image title="pp kpi attributes.png" alt={2370} src="https://files.readme.io/f672bed-pp_kpi_attributes.png">
  Plan Performance Attributes
</Image>

**Plan Performance Indicators** status include details of the key performance indicators (KIPs) by plan.

<Image title="pp kpi key performance indicators detail.png" alt={2370} src="https://files.readme.io/f632b6d-pp_kpi_key_performance_indicators_detail.png">
  Plan Performance Indicators
</Image>

# Plan Performance Subscriptions

The Subscriptions view of the Plan Performance dashboard has one line chart that calculates subscription totals and three bar charts that calculate subscription growth.

**Total Subscriptions:** The following line chart shows the total number of live subscriptions in each plan (including trials, canceled, paused, or $0 subscriptions).

<Image title="pp subscription totals.png" alt={2372} src="https://files.readme.io/00cdb39-pp_subscription_totals.png">
  Plan Performance Subscription Totals
</Image>

**Subscription Growth:** The following three bar charts show the number of new subscriptions, churned subscriptions, and the net positive or negative change for each plan in the Subscription Breakout section of this view. Subscriptions moving from one plan to another are not considered churned.

1st Chart: Net Subscriptions

<Image title="pp subscriptions net subscriptions.png" alt={2372} src="https://files.readme.io/ac198dc-pp_subscriptions_net_subscriptions.png">
  Plan Performance Net Subscriptions
</Image>

2nd Chart: New Subscriptions

<Image title="pp subscriptions new subscriptions bar chart.png" alt={2376} src="https://files.readme.io/40199bb-pp_subscriptions_new_subscriptions_bar_chart.png">
  Plan Performance New Subscriptions
</Image>

3rd Chart: Churn Subscriptions

<Image title="pp subscriptions churn subscriptions.png" alt={2370} src="https://files.readme.io/7dac6f2-pp_subscriptions_churn_subscriptions.png">
  Plan Performance Churn Subscriptions
</Image>

# Plan Performance Subscription Churn

The Churn view of the Plan Performance dashboard includes three line charts that calculate total, voluntary, and involuntary churn.

**Subscription Churn:** The number of subscriptions that churned out of each plan over the selected time range. This is further broken down by voluntary vs. involuntary churn rates. Subscriptions moving from one plan to another are not considered churned. 

Note: The Average Churn rate for the entire selected time range is calculated by averaging the monthly churn rates for every month in that selected timeframe.

**Total Churn:** shown in the following line chat for the selected period

<Image title="pp subscription churn total churn line chart.png" alt={2372} src="https://files.readme.io/bb59a9a-pp_subscription_churn_total_churn_line_chart.png">
  Plan Performance Total Churn
</Image>

**Voluntary churn** reasons include: Non-renewing, Account Closed or Cancellation. 

<Image title="pp churn vouluntary churn line chart.png" alt={2368} src="https://files.readme.io/50bf2e3-pp_churn_vouluntary_churn_line_chart.png">
  Plan Performance Voluntary Churn
</Image>

**Involuntary churn** reasons include Non-Payment or Invalid Vat Location. 

<Image title="pp churn involuntary churn line chart.png" alt={2380} src="https://files.readme.io/29ece14-pp_churn_involuntary_churn_line_chart.png">
  Plan Performance Involuntary Churn
</Image>

# Plan Performance Subscription Trials

The Trials view of the Plan Performance dashboard includes two swimlane charts and one status chart in the Subscription Trials section and one line chart in the Trial Conversion Rate section.

**Subscription Trials**  section has two swimlane charts and one status detail and covers the:

* Number of trial subscriptions that converted to paid subscriptions
* Number that did not convert due to failed payment
* Number that did not convert due to cancellation
* Number that did not convert because their cardless trial ended and no billing information was added
* Number of subscriptions that are still "pending" (either still in trial or have finished trial but have not paid and have an invoice in dunning)

**Subscription Trials** swim lane chart tracks the % of trial subscriptions by status.

<Image title="pp subscription trial % of trials swim lane chart.png" alt={2370} src="https://files.readme.io/edd637d-pp_subscription_trial__of_trials_swim_lane_chart.png">
  Subscription Trials by Percentages
</Image>

**Subscription Trials** swim lane chart tracks the number of trial subscriptions by status.

<Image title="pp subscription trial # of trials swim lane chart.png" alt={2374} src="https://files.readme.io/c2384e2-pp_subscription_trial__of_trials_swim_lane_chart.png">
  Subscription Trials by Status
</Image>

**Trial Subscription Status** tracks the current state of subscriptions that started as trials during the selected date range.

<Image title="pp trial trial subscription details.png" alt={2372} src="https://files.readme.io/f47bb1a-pp_trial_trial_subscription_details.png">
  Trial Performance Subscription Status
</Image>

**Trial Conversion Rate** section has a line chart that calculates the conversion rate of the total subscriptions that started a trial for each plan over the selected time range. 

<Image title="pp trial conversion rate line chart.png" alt={2372} src="https://files.readme.io/cd6f5a5-pp_trial_conversion_rate_line_chart.png">
  Trial Performance Conversion Rate
</Image>

# Plan Performance Plan Movement

The Plan Movement view of the Plan Performance dashboard includes one trend chart in the Plan Movement section and two bar charts in the Plan Movement Breakout section.

**Plan Movement section** has one status detail

**Plan Movement Trend** shows the net movement for the top five plans for a selected timeframe:

<Image title="pp Plan Movement trend chart.png" alt={2408} src="https://files.readme.io/0651bdf-pp_Plan_Movement_trend_chart.png">
  Plan Movement Trend
</Image>

**Plan Movement Breakout** section calculates the movement of incoming and outgoing subscriptions. Entirely new subscriptions or subscriptions that have completely churned from the business are not included.

**Incoming Movement** displays the number of subscriptions moving into the selected plan from another plan.

<Image title="pp plan movement breakout incoming movement bar chart.png" alt={2372} src="https://files.readme.io/1c16ca7-pp_plan_movement_breakout_incoming_movement_bar_chart.png">
  Incoming Plan Movement
</Image>

**Outgoing Movement** displays the number of subscriptions moving out of the selected plan to another plan.

<Image title="pp plan movement breakout outgopig movement bar chart.png" alt={2376} src="https://files.readme.io/f61bee4-pp_plan_movement_breakout_outgopig_movement_bar_chart.png">
  Outgoing Plan Movement
</Image>

# Plan Performance MRR

The Monthly Recurring Revenue (MRR) view of the Plan Performance dashboard includes one totals line chart and a net MRR bar chart in the Monthly Recurring Revenue section and five bar charts in the MRR Growth Breakout section.

Note: The MRR Growth section on this dashboard is only available to merchants on Recurly’s Professional, Elite, and Enterprise Plans. Please contact Recurly Support if you are interested in access to this section.

**Monthly Recurring Revenue** section calculates revenue totals and net MRR.

**MRR Totals** calculate the monthly recurring revenue contributed by subscriptions for the selected top five plans during a selected timeframe. 

<Image title="pp mrr mrr total line chart.png" alt={2374} src="https://files.readme.io/208d49d-pp_mrr_mrr_total_line_chart.png">
  Plan Performance MRR Totals
</Image>

**Net MRR** =  (New MRR + Expansion MRR + Reactivation MRR) - (Churn MRR + Declined MRR).

<Image title="pp mrr net mrr.png" alt={2366} src="https://files.readme.io/fa15853-pp_mrr_net_mrr.png">
  Plan Performance Net MRR
</Image>

**MRR Growth Breakout** section calculates changes to MRR for each plan. The change is reflected as net positive MRR or net negative MRR and is calculated as: (New MRR + Expansion MRR + Declined MRR) - (Churn MRR + Contraction MRR). 

The Monthly Recurring Revenue (MRR) Growth dashboard measures changes to MRR, over a selected time period. This change is reflected as net positive MRR or net negative MRR and is calculated as: (New MRR + Expansion MRR + Reactivation MRR) - (Churned MRR + Declined MRR).

**New MRR** contributed by an account in this month when the account contributed $0 last month AND has never contributed MRR in the past.

<Image title="pp mrr growth breakout new bar chart.png" alt={2376} src="https://files.readme.io/809f414-pp_mrr_growth_breakout_new_bar_chart.png">
  Plan Performance New MRR
</Image>

**Expansion MRR** in the previous month. Common reasons for Expansion MRR include: subscription upgrade, a coupon or credit being exhausted that causes the total subscription amount being paid to increase or an account adding a second subscription.

<Image title="pp mrr breakout expansion bar chart.png" alt={2376} src="https://files.readme.io/be27aeb-pp_mrr_breakout_expansion_bar_chart.png">
  Plan Performance Expansion MRR
</Image>

**Reactivation MRR** contributed by an account this month when the account contributed $0 in recurring revenue last month BUT has contributed >$0 some time in previous to last month. There must be a gap of at least one month where the account had $0 MRR prior to the reactivation. If a subscription was not added back to the same account, Recurly will not be able to recognize it as "Reactivation."

<Image title="pp mrr mrr growth breakout reactivation bar chart.png" alt={2370} src="https://files.readme.io/b11118e-pp_mrr_mrr_growth_breakout_reactivation_bar_chart.png">
  Plan Performance Reactivation MRR
</Image>

**Churn MRR** that was contributed by an account LAST month when the account had now contributed $0 this month. This reflects the amount of MRR that was lost. Because Recurly will not know whether an account will contribute MRR or not until the END OF THE MONTH, Churned MRR will not show up until the current month is complete.

<Image title="pp mrr mrr growth breakout churn bar chart.png" alt={2374} src="https://files.readme.io/c8aa937-pp_mrr_mrr_growth_breakout_churn_bar_chart.png">
  Plan Performance Churn MRR
</Image>

**Contraction MRR** a negative change in an account's contribution to MRR when compared to the previous month. Common reasons for Contraction MRR include: subscription downgrade, a refund, coupon or credit being applied to bring the subscription amount paid down, or an account removing one of their multiple subscriptions.

<Image title="pp mrr mrr growth breakout contraction bar chart.png" alt={2348} src="https://files.readme.io/a9d44e9-pp_mrr_mrr_growth_breakout_contraction_bar_chart.png">
  Plan Performance Contraction MRR
</Image>

# Plan Performance LTV

The Lifetime Value (LTV) view of the Plan Performance dashboard includes one subscription total line chart and one detail chart includes the lifetime values for selected plans.

**Average LTV** is the average lifetime value of the subscriptions in the selected plans.

**Average Subscription LTV = ARPS (1 + d) / (d + subscription churn Rate)**

ARPS = Average revenue per subscription (MRR contributed by all subscriptions active at the end of the month/ number of active, subscriptions at the end of the month)

Subscription churn rate = Number of churned subscriptions/ number of subscriptions active at any time during that month.

d = discount rate. This constant is commonly used when looking at future revenue. It takes into account market, financial and other risks as well as the time value of money. 

Recurly uses a discount rate of 1%.

**Subscription Lifetime Value** section calculates the average lifetime values of your plans.

**Lifetime Value** line chart calculates the lifetime values of subscriptions for selected plans.

<Image title="pp subscription ltv line chart.png" alt={2374} src="https://files.readme.io/adf628d-pp_subscription_ltv_line_chart.png">
  Plan Performance Lifetime Value
</Image>

**Subscription Lifetime Values** detail chart with lifetime values for the selected top five plans by the selected timeframes.

<Image title="pp subscription ltv detail .png" alt={2376} src="https://files.readme.io/a75208a-pp_subscription_ltv_detail_.png">
  Plan Performance Subscription Lifetime Values
</Image>

# Plan Performance Subscriber Retention

The Subscriber Retention view of the Plan Performance dashboard includes one status chart and two detail charts in the Subscriber Retention section.

**Subscriber Retention** section tracks paying and active subscribers for the top five plans from the sign-up month and an active volume and churn volume.

**Subscriber Retention Status** chart

<Image title="pp subscriber retention detail .png" alt={2378} src="https://files.readme.io/2cc41f3-pp_subscriber_retention_detail_.png">
  Subscriber Retention Status Detail
</Image>

**Active Volumes** show the active volumes for subscribers on the Plan Performance dashboard.

<Image title="pp subscriber retention active volume detail.png" alt={2916} src="https://files.readme.io/3a26178-pp_subscriber_retention_active_volume_detail.png">
  Subscriber Retention Active Volumes
</Image>

**Churn Volumes** show the churn volumes for subscribers on the Plan Performance dashboard

<Image title="pp subscriber retention churned volume detail.png" alt={2918} src="https://files.readme.io/1df0737-pp_subscriber_retention_churned_volume_detail.png">
  Subscriber Retention Churn Volumes
</Image>
