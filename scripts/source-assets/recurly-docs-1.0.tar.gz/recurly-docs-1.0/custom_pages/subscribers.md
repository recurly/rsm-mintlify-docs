---
title: Subscribers
fullscreen: false
hidden: true
metadata:
  title: ''
  description: ''
---
The Subscribers Dashboard calculates the total number of active accounts and subscribers over a designated date range. It monitors the number of new, churned, returning, and net total subscribers over time to help you understand your subscriber growth trends. 

The subscriber account includes all open accounts with at least one active, canceled, or paused subscription. Accounts include all open accounts regardless of whether it has an active, canceled, or future subscription.

To maintain access to the most current information, you can use widgets on this dashboard to refresh the screen.  The data for this dashboard updates multiple times a day. You can verify the time the last changes were uploaded by checking the widget at the bottom of the dashboard.

# Subscribers Dashboard

The Subscribers Dashboard is divided into four sections: totals at-a-glance view, a line chart, a bar chart, and a details table. 

The widgets on this dashboard’s user interface provide you with access to the following common features:

**Actions** at the top right corner of the dashboard provide the following functionality:

* Reload action tracks the last time you refreshed your data up to four hours. The counter then resets, beginning with 1m ago This tells you how current your data is from the last refresh.
* Hide Filters action hides filters that display in the top left corner of the dashboard.
* Dashboard actions allow you to either clear the cache and refresh the data or view a Download Dashboard menu from where you can select a download format, page size, or choose how to arrange downloaded data or reset filters.
* Open Folders action allows you to open/close folders from the dashboard.

**Filters** in the top left corner of the dashboard provide the following options:

* Timeframe filter allows you to select a daily, weekly, or monthly option for displaying subscriber data.
* Date Range filter provides dropdown menus where you can choose a timeframe and date range from within the last 18 months to determine the data that displays on the dashboard.

**Clear Cache options** allow you to clear cache and refresh data in three places on this dashboard:

* Click the vertical ellipse on any of the widgets, at the bottom of the dashboard to see the timestamp for the most current version of data on the dashboard.
* Click the vertical ellipse on any of the widgets within the dashboard to update the selected widget with the most current data available during the session.
* Click the Actions widget -> vertical ellipse at top right corner of the dashboard to clear the cache and refresh the data. Recurly updates the data multiple times a day, so after a refresh, the most current data available will upload.

**Vertical ellipses** available on both widgets and tables, provide you with a dropdown menu where you can select the following options:

* Click the vertical ellipse on a widget to download data or clear cache and refresh data for a selected widget.
* Click the vertical ellipse on a column in a table to download data or clear the cache and refresh the data on display, but also to auto size or resize columns.

**Charts and legends** display data on this dashboard within widgets in bar, line, and pie charts. This data often includes customer, subscriber, subscription, plans, and revenue totals in increments specified by time and date ranges. If the information on one of these charts is color-coded, there will be a legend on the widget that identifies the value assigned to the color. For example, specific colors are assigned to specific plans or totals being tracked, to enable you to read the chart. 

* Click a point in a line chart or a specific color on a bar or pie chart to display the corresponding timeframe and value in hover text. For example, total number of subscribers for a corresponding month.
* Click the corresponding color in the legend to hide that corresponding line, bar, or pie chart segment from the widget. Click on the color again to restore the data.

# Subscribers Section

The Subscribers Dashboard is divided into the following sections: subscriber totals, two bar/line charts, and a table of subscriber details. 

**Subscriber Overview Totals:** shows a subscriber totals at-a-glance view in a widget that includes the current Active Subscriber totals, and total subscriber counts for last month, previous month, three months ago, and one year ago.

<Image title="subscriber dashboar overv.png" alt={2620} src="https://files.readme.io/7d8b746-subscriber_dashboar_overv.png">
  Subscriber Key Performance Indicators
</Image>

The up arrows under the totals indicate the difference between those indicated timeframes and the Active Subscriber total.

**Subscribers:** shows a bar/line chart that identifies the total number of active accounts and subscribers.

* Click any point on the line to view the total number of accounts in hover text, for the selected timeframe. 
* Click any bar in the bar chart to view the total number of subscribers for the selected timeframe in hover text. 

<Image title="Subscriber bar:line chart.png" alt={2940} src="https://files.readme.io/c9dbbdf-Subscriber_barline_chart.png">
  Subscriber Totals
</Image>

**Subscriber Growth:** shows a bar/line chart that calculates the net change of new, returning, and churned subscribers over a selected timeframe. On this dashboard, a subscriber is anyone with an active subscription.

<Image title="Subscriber growth bar:line chart.png" alt={2914} src="https://files.readme.io/53c0899-Subscriber_growth_barline_chart.png">
  Subscriber Growth
</Image>

* Click any point on the line to view the net subscriber totals for the selected timeframe in hover text. 
* Click one of the color-coded segments of any bar to view the totals for the selected timeframe in hover text. The totals correspond to the colors in the legend at the bottom of the chart. On the chart in this example, light blue depicts the new subscriber totals, dark blue depicts the returning subscriber totals, and yellow depicts the churned subscriber totals.

Note: The Subscriber Growth area is only available to sites on Recurly’s Professional, Elite, or Enterprise plans. Please contact Recurly Support if you are interested in access to this section.

**Subscriber Detail:** shows a chart that provides the following account and subscriber details:

* new accounts - closed accounts = net accounts (includes new total accounts)
* new subscribers + returning subscribers – churned subscribers = net subscribers (includes new total subscribers)

<Image title="Subscriber detail chart.png" alt={2914} src="https://files.readme.io/c9b0c22-Subscriber_detail_chart.png">
  Subscriber Growth Status
</Image>
